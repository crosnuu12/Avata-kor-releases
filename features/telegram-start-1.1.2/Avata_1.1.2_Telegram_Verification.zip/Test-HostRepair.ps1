﻿#requires -Version 5.1
param([string]$Root=$PSScriptRoot)
$ErrorActionPreference='Stop'
. (Join-Path $Root 'host/At58.Ops.ps1')
. (Join-Path $Root 'host/At58.Update.ps1')
$script:passed=0
function Check($condition,[string]$name){if(!$condition){throw ('FAILED: '+$name)};$script:passed++;'PASS '+$name}
Add-Type -TypeDefinition @'
using System;
using System.IO;
using System.Threading;
public class AvataTestReadLock : IDisposable {
 FileStream file; Thread worker;
 public AvataTestReadLock(string path,int ms) {
  file=File.Open(path,FileMode.Open,FileAccess.Read,FileShare.Read);
  worker=new Thread(()=>{Thread.Sleep(ms);file.Dispose();});worker.Start();
 }
 public void Dispose(){worker.Join();}
}
'@
$dir=Join-Path ([IO.Path]::GetTempPath()) ('avata-host-test-'+[guid]::NewGuid().ToString('N'))
[void][IO.Directory]::CreateDirectory($dir)
foreach($source in @('host/At58.Ops.ps1','bundle/At58.Ops.ps1')){
 . (Join-Path $Root $source)
 $file=Join-Path $dir 'status.json';Ops-WriteJson $file @{Sequence=1}
 $hold=[AvataTestReadLock]::new($file,180)
 try{Ops-WriteJson $file @{Sequence=2}}finally{$hold.Dispose()}
 Check ((Ops-ReadJson $file).Sequence -eq 2) ($source+' recovers a real Windows sharing violation')
 $hold=[IO.File]::Open($file,[IO.FileMode]::Open,[IO.FileAccess]::Read,[IO.FileShare]::Read)
 $failed=$false;$clock=[Diagnostics.Stopwatch]::StartNew()
 try{try{Ops-WriteJson $file @{Sequence=3}}catch{$failed=Ops-SharingViolation $_}}finally{$hold.Dispose();$clock.Stop()}
 Check ($failed -and $clock.Elapsed.TotalSeconds -lt 4) ($source+' persistent lock fails within bounded time')
 Check ((Ops-ReadJson $file).Sequence -eq 2 -and @(Get-ChildItem -LiteralPath $dir -Filter '*.tmp').Count -eq 0) ($source+' failure preserves old complete JSON and removes temporary file')
 $e=[IO.IOException]::new('synthetic non-sharing error');Check (!(Ops-SharingViolation ([Management.Automation.ErrorRecord]::new($e,'x','WriteError',$null)))) ($source+' does not retry generic IO errors')
 [IO.File]::SetAttributes($file,[IO.FileAttributes]::ReadOnly)
 $failed=$false;$clock.Restart()
 try{try{Ops-WriteJson $file @{Sequence=4}}catch{$failed=!(Ops-SharingViolation $_)}}finally{[IO.File]::SetAttributes($file,[IO.FileAttributes]::Normal);$clock.Stop()}
 Check ($failed -and $clock.Elapsed.TotalSeconds -lt 1) ($source+' permission failure is not hidden or retried')
 Ops-WriteJson $file @{Sequence=5};Check ((Ops-ReadJson $file).Sequence -eq 5) ($source+' later valid write succeeds')
}
try{throw [IO.IOException]::new('synthetic secret=DO_NOT_LOG account=123456789')}catch{$d=Up-HostFailure $_}
$json=$d|ConvertTo-Json -Compress
Check ($d.Code -ceq 'BUNDLE_ERROR' -and $d.ExceptionType -ceq 'System.IO.IOException' -and $d.Line -gt 0) 'host error records type, numeric code and source line'
Check ($json -notmatch 'DO_NOT_LOG|123456789|secret|account') 'host diagnostic excludes exception text and account data'
try{throw 'BUNDLE_MANIFEST_HASH'}catch{$d=Up-HostFailure $_}
Check ($d.Code -ceq 'BUNDLE_MANIFEST_HASH') 'known updater error codes remain unchanged'
try{throw [IO.IOException]::new('synthetic secret=DO_NOT_LOG')}catch{Up-WriteHostFailure $dir '58.17.8' 'synthetic-session' $_}
$remote=Ops-ReadJson (Join-Path $dir 'bundle-status.json')
Check ($remote.State -ceq 'HOST_ERROR' -and $remote.Stage -cmatch '^HOST_IOEXCEPTION_L[0-9]+_WIN32_[0-9]+$') 'existing remote relay receives host type, line and numeric error in Stage'
Check (($remote|ConvertTo-Json -Compress) -notmatch 'DO_NOT_LOG|secret') 'remote host record does not expose raw exception message'
'HOST REPAIR TESTS COMPLETE: '+$script:passed+' passed; isolated files only.'
