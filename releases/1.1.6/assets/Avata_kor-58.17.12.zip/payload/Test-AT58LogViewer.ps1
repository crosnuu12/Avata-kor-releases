﻿$ErrorActionPreference='Stop'

. (Join-Path $PSScriptRoot 'At58.Log.ps1')

$root=Join-Path $PSScriptRoot ('viewer-test-'+[guid]::NewGuid().ToString('N'));[void][IO.Directory]::CreateDirectory($root)

try{

 $r=[ordered]@{Schema='AT-DIRECT-STATUS-1';Version='58.0';Source='MERITZ_DIRECT';At='2026-11-01 23:59:59';Utc='2026-11-01T14:59:59.0000000Z';State='CLOSED';Code='OK';ApiCode='';Stage='COMPLETE';Failures=0;Sequence=1;Calls=9;LastSuccessUtc='2026-11-01T14:59:59.0000000Z';OrdersSent=0}

 $json=$r|ConvertTo-Json -Compress

 [IO.File]::WriteAllText((Join-Path $root 'status.json'),$json,[Text.Encoding]::UTF8)

 [IO.File]::WriteAllText((Join-Path $root 'read-20261101.jsonl'),($json+"`n"+'{"partial":'),[Text.Encoding]::UTF8)

 $v=Get-At58LogView $root ([datetime]::SpecifyKind([datetime]'2026-11-01T14:59:59',[DateTimeKind]::Utc))

 if($v.Rows.Count -ne 1 -or $v.Skipped -ne 1 -or $v.Age -ne 0){throw 'Partial record handling failed'}

 Write-Output 'PASS complete rows appear while partial trailing line is excluded'

 $v=Get-At58LogView $root ([datetime]::SpecifyKind([datetime]'2026-11-01T15:00:01',[DateTimeKind]::Utc))

 if($v.Day -ne '2026-11-02' -or $v.Rows.Count -ne 0 -or $v.Age -ne 2){throw 'KST date rollover failed'}

 Write-Output 'PASS KST midnight switches daily file and preserves last-status age'

 $r.Code='secret detail';if($null -ne (Convert-At58LogRecord ($r|ConvertTo-Json -Compress))){throw 'Unknown text leaked'}

 Write-Output 'PASS unexpected raw diagnostic text is excluded'

 $r.Code='OK';$r.Source='OTHER';if($null -ne (Convert-At58LogRecord ($r|ConvertTo-Json -Compress))){throw 'Wrong source accepted'}

 Write-Output 'PASS unrelated source is excluded'

 Write-Output 'AT58 LOG VIEWER TEST COMPLETE: 4 passed; no API or live-state writes.'

}finally{

 $resolved=[IO.Path]::GetFullPath($root);$parent=[IO.Path]::GetFullPath($PSScriptRoot).TrimEnd('\')+'\'

 if(!$resolved.StartsWith($parent,[StringComparison]::OrdinalIgnoreCase) -or [IO.Path]::GetFileName($resolved) -notmatch '^viewer-test-[a-f0-9]{32}$'){throw 'Unexpected cleanup path'}

 Remove-Item -LiteralPath $resolved -Recurse -Force

}

