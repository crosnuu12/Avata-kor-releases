﻿if(-not ('At58SheetsJwt' -as [type])) {Add-Type -TypeDefinition @'



using System;

using System.Text;

using System.Security.Cryptography;

public static class At58SheetsJwt {

 class Der {

  byte[] b; int p;

  public Der(byte[] bytes) { b=bytes; p=0; }

  public byte[] Read(int tag) {

   if(p>=b.Length || b[p++]!=tag) throw new Exception("Invalid key structure");

   if(p>=b.Length) throw new Exception("Invalid length");

   int n=b[p++];

   if((n&128)!=0) {

    int k=n&127; if(k==0||k>4) throw new Exception("Invalid length");

    n=0; for(int i=0;i<k;i++) {if(p>=b.Length) throw new Exception("Invalid length"); checked {n=(n<<8)|b[p++];}}

   }

   if(n<0||n>b.Length-p) throw new Exception("Invalid length");

   byte[] v=new byte[n]; Buffer.BlockCopy(b,p,v,0,n); p+=n; return v;

  }

  public byte[] Int() {

   byte[] v=Read(2); int i=0; while(i<v.Length-1 && v[i]==0) i++;

   byte[] x=new byte[v.Length-i]; Buffer.BlockCopy(v,i,x,0,x.Length); return x;

  }

  public bool End {get{return p==b.Length;}}

 }

 public static string B64(byte[] b) {return Convert.ToBase64String(b).TrimEnd('=').Replace('+','-').Replace('/','_');}

 static byte[] Pad(byte[] value,int size) {

  if(value.Length>size)throw new Exception("Invalid RSA field");

  if(value.Length==size)return value;

  byte[] b=new byte[size];Buffer.BlockCopy(value,0,b,size-value.Length,value.Length);return b;

 }

 public static string Sign(string unsigned, string pem) {

  string raw=pem.Replace("-----BEGIN PRIVATE KEY-----","").Replace("-----END PRIVATE KEY-----","").Replace("\r","").Replace("\n","").Trim();

  byte[] bytes=Convert.FromBase64String(raw);

  try {

   Der outer=new Der(bytes); Der pk8=new Der(outer.Read(48));

   if(!outer.End) throw new Exception("Trailing key data");

   byte[] version=pk8.Read(2); if(version.Length!=1||version[0]!=0)throw new Exception("Unsupported version");

   Der alg=new Der(pk8.Read(48));

   byte[] oid=alg.Read(6);

   if(Convert.ToBase64String(oid)!="KoZIhvcNAQEB")throw new Exception("RSA key required");

   if(!alg.End){if(alg.Read(5).Length!=0||!alg.End)throw new Exception("Invalid RSA algorithm");}

   Der keyOuter=new Der(pk8.Read(4)); if(!pk8.End)throw new Exception("Unsupported PKCS8 attributes");

   Der key=new Der(keyOuter.Read(48)); if(!keyOuter.End)throw new Exception("Invalid key");

   key.Read(2);

   RSAParameters r=new RSAParameters();

   r.Modulus=key.Int();r.Exponent=key.Int();r.D=key.Int();r.P=key.Int();r.Q=key.Int();r.DP=key.Int();r.DQ=key.Int();r.InverseQ=key.Int();

   if(!key.End)throw new Exception("Unsupported key");

   int half=(r.Modulus.Length+1)/2;

   r.D=Pad(r.D,r.Modulus.Length);r.P=Pad(r.P,half);r.Q=Pad(r.Q,half);r.DP=Pad(r.DP,half);r.DQ=Pad(r.DQ,half);r.InverseQ=Pad(r.InverseQ,half);

   using(RSACryptoServiceProvider rsa=new RSACryptoServiceProvider()) {

    rsa.PersistKeyInCsp=false; rsa.ImportParameters(r);

    return unsigned+"."+B64(rsa.SignData(Encoding.UTF8.GetBytes(unsigned),CryptoConfig.MapNameToOID("SHA256")));

   }

  } finally {Array.Clear(bytes,0,bytes.Length);}

 }

}



'@}

