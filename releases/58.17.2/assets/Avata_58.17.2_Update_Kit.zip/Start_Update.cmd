@echo off
setlocal DisableDelayedExpansion
cd /d "%~dp0"
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -STA -ExecutionPolicy RemoteSigned -File "%~dp0Start-Update.ps1"
set "AVATA_UPDATE_EXIT=%ERRORLEVEL%"
if not "%AVATA_UPDATE_EXIT%"=="0" (
  echo.
  echo Update checks did not complete. Keep the error and the logs folder.
  pause
)
exit /b %AVATA_UPDATE_EXIT%
