﻿#requires -Version 5.1
param([string]$LocalBase=([Environment]::GetFolderPath('LocalApplicationData')),[string]$ValidationFile='')
$ErrorActionPreference='Stop'
. (Join-Path $PSScriptRoot 'recovery/Verify_Cash_Interest.ps1')

function IP-Hash([string]$path){return (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant()}
function IP-Read([string]$path){return ([IO.File]::ReadAllText($path,[Text.Encoding]::UTF8)|ConvertFrom-Json)}
function IP-CheckPackage([string]$package){
 $m=IP-Read (Join-Path $package 'package.json')
 if($m.Schema -cne 'AVATA-ROLLOVER-1' -or $m.Version -cne '58.17.2'){throw 'PACKAGE_INVALID'}
 $seen=@{}
 foreach($f in $m.Files){
  $n=[string]$f.Name
  if($n -cnotmatch '^[A-Za-z0-9_./-]+$' -or $n.StartsWith('/') -or $n -match '(^|/)\.\.?(/|$)' -or $seen.ContainsKey($n)){throw 'PACKAGE_PATH'}
  $seen[$n]=$true;$p=Join-Path $package $n
  if(![IO.File]::Exists($p) -or ([IO.FileInfo]$p).Length -ne $f.Size -or (IP-Hash $p) -cne $f.Hash){throw 'PACKAGE_HASH'}
 }
 foreach($n in @('Install-Rollover.ps1','host/At58.Host.ps1','host/At58.Ops.ps1','host/At58.Update.ps1','recovery/Repair_Input_After_Transfer.ps1','bundle/release.json','offer.json','Start_Update.cmd','Start-Update.ps1','Run-Checks.ps1','Test-Rollover.ps1','Test-Installer.ps1','tests/original/At58.Host.ps1','tests/original/channel/ready.json','tests/Invoke-RolloverWorker.ps1','recovery/Verify_Cash_Interest.ps1','Test-CashInterest.ps1','tests/CashFixture.ps1')){if(!$seen.ContainsKey($n)){throw 'PACKAGE_INCOMPLETE'}}
 return $m
}
function IP-RequireValidation([string]$package,[string]$receiptPath){
 if(!$receiptPath -or ![IO.File]::Exists($receiptPath)){throw 'RUN_START_UPDATE_FIRST'}
 $r=IP-Read $receiptPath
 if($r.Schema -cne 'AVATA-PREFLIGHT-1' -or $r.Result -cne 'PASSED' -or $r.Engine -cne 'WindowsPowerShell-5.1' -or $r.Root -ine [IO.Path]::GetFullPath($package) -or $r.PackageHash -cne (IP-Hash (Join-Path $package 'package.json'))){throw 'PREFLIGHT_PACKAGE_MISMATCH'}
 $stamp=[datetime]::Parse($r.Utc,[Globalization.CultureInfo]::InvariantCulture,[Globalization.DateTimeStyles]::RoundtripKind)
 $age=([datetime]::UtcNow-$stamp.ToUniversalTime()).TotalSeconds
 if($age -lt -2 -or $age -gt 21600){throw 'PREFLIGHT_EXPIRED'}
 $logBase=[IO.Path]::GetFullPath((Join-Path $package 'logs')).TrimEnd('\')+'\'
 $logPath=[IO.Path]::GetFullPath($r.Log)
 if(!$logPath.StartsWith($logBase,[StringComparison]::OrdinalIgnoreCase) -or ![IO.File]::Exists($logPath) -or (IP-Hash $logPath) -cne $r.LogHash){throw 'PREFLIGHT_LOG_CHANGED'}
}
function IP-Paths([string]$localRoot){
 if(![IO.Path]::IsPathRooted($localRoot)){throw 'INSTALL_PATH'}
 $base=[IO.Path]::GetFullPath($localRoot).TrimEnd('\')
 return @{Base=$base;Host=(Join-Path $base 'esbada_AT_host');Manage=(Join-Path $base 'esbada_AT_manage');Data=(Join-Path $base 'esbada_AT_direct')}
}
function IP-WriteBytes([string]$path,[byte[]]$bytes){
 $tmp=$path+'.'+[guid]::NewGuid().ToString('N')+'.tmp'
 try{
  [IO.File]::WriteAllBytes($tmp,$bytes)
  if([IO.File]::Exists($path)){[IO.File]::Replace($tmp,$path,[Management.Automation.Language.NullString]::Value)}else{[IO.File]::Move($tmp,$path)}
 }finally{if([IO.File]::Exists($tmp)){[IO.File]::Delete($tmp)}}
}
function IP-Lock($paths){
 $locks=New-Object 'Collections.Generic.List[object]'
 try{
  foreach($v in @(@('Local\esbada-AT-host-',$paths.Host),@('Local\esbada-AT-manager-',$paths.Manage),@('Local\esbada-AT-direct-',$paths.Data))){
   $created=$false;$m=[Threading.Mutex]::new($true,($v[0]+(Ops-Key $v[1].ToLowerInvariant()).Substring(0,24)),[ref]$created)
   if(!$created){$m.Dispose();throw 'PROGRAM_RUNNING'}
   $locks.Add($m)
  }
  return ,$locks
 }catch{foreach($m in $locks){$m.ReleaseMutex();$m.Dispose()};throw}
}
function IP-Unlock($locks){foreach($m in $locks){$m.ReleaseMutex();$m.Dispose()}}
function IP-Checkpoint([string]$name){}
function IP-Inspect($paths,$package){
 $cfg=IP-Read (Join-Path $paths.Host 'settings.json')
 if($cfg.Schema -cne 'AT58-HOST-1' -or $cfg.HostProtocol -ne 2 -or !$cfg.Enabled){throw 'HOST_SETTINGS'}
 if([IO.Path]::GetFullPath($cfg.DataRoot) -ine $paths.Data -or [IO.Path]::GetFullPath($cfg.ManagementRoot) -ine $paths.Manage){throw 'HOST_PATHS'}
 if((Ops-Get $cfg 'FeedUrl' '') -cne 'https://github.com/crosnuu12/Avata-kor-releases/releases/latest/download/avata-update.json'){throw 'SIGNED_FEED_REQUIRED'}
 if([IO.Path]::GetFullPath($cfg.ChannelRoot) -ine (Join-Path $paths.Host 'remote-channel')){throw 'HOST_CHANNEL'}
 $active=IP-Read (Join-Path $paths.Host 'active.json')
 $offer=IP-Read (Join-Path $package 'offer.json')
 if($active.Version -ceq '58.17.2' -and $active.Id -ceq $offer.Id -and $active.ManifestHash -ceq $offer.ManifestHash){throw 'ALREADY_INSTALLED'}
 if($active.Version -cne '58.17.0' -or $active.Id -cne 'bundle-a1911e62f3f0341a1353e7b7' -or $active.ManifestHash -cne '972672bba0304b22dbad4cbef7cb77a130e7989eb25d8aae306a849fc1ad0efe'){throw 'INSTALLED_VERSION'}
 $null=Up-Validate (Ops-Inside $paths.Host (Join-Path $paths.Host ('bundles\'+$active.Id))) $active.ManifestHash
 $expected=@{'At58.Host.ps1'='101598fec8ed6719ac742f7be832c944497aded49b1d5a7663b16e3bcf3e34ab';'At58.Update.ps1'='b6c662070656820aa2331caabab196796063f4de23ac38732c4ad72b7b99823b';'At58.Ops.ps1'='42d6058e91b68e15e5fa14953bee6c129ee171c69f02dd5b9ed26cd1f3864a44'}
 foreach($n in $expected.Keys){if((IP-Hash (Ops-Inside $paths.Host (Join-Path $paths.Host $n))) -cne $expected[$n]){throw 'INSTALLED_HOST_CHANGED'}}
 $trial=Ops-ReadJson (Join-Path $paths.Host 'trial.json')
 if($trial -and $trial.Phase -cin @('PENDING','ROLLING_BACK')){throw 'UPDATE_TRIAL_ACTIVE'}
 $state=Ops-ReadJson (Join-Path $paths.Host 'state.json')
 if($state -and $offer.Id -cin @($state.Rejected)){throw 'CANDIDATE_PREVIOUSLY_REJECTED'}
 $runtime=IP-Read (Join-Path $paths.Manage 'runtime.json')
 $status=IP-Read (Join-Path $paths.Data 'status.json')
 $now=Ops-Now;$live=Ops-LiveStatus $runtime $status $runtime.RunId $now
 $age=($now-(Ops-Utc $runtime.Utc)).TotalSeconds
 if(!$live -or $age -lt -2 -or $age -gt 90 -or $runtime.ExitReason -cne 'USER_CLOSE' -or (Ops-Get $runtime 'ExecutionEnabled' $true) -ne $false -or (Ops-Get $runtime 'LiveCommandPending' $true) -ne $false -or $live.State -cne 'DISARMED' -or $live.ExecutionEnabled -or $live.OpenOrders -ne 0 -or $live.UncertainOrders -ne 0){throw 'STOP_RECONCILE_CLOSE_REQUIRED'}
 if(!$live.Reconciled -or $live.Confirmations -lt 2){
  if((Ops-Get $live 'Code' '') -cne 'LIVE_CASH_WAIT'){throw 'STOP_RECONCILE_CLOSE_REQUIRED'}
  if((IP-VerifyInterestRecovery $paths $package) -ne $true){throw 'CASH_RECOVERY_NOT_VERIFIED'}
 }
 return @{Config=$cfg;Active=$active;Offer=$offer}
}
function IP-Restore($paths,[string]$backup){
 $receipt=IP-Read (Join-Path $backup 'receipt.json')
 if($receipt.Schema -cne 'AVATA-ROLLOVER-BACKUP-1' -or $receipt.Host -ine $paths.Host){throw 'BACKUP_INVALID'}
 $active=IP-Read (Join-Path $paths.Host 'active.json')
 if($active.Id -cne $receipt.Active.Id -or $active.ManifestHash -cne $receipt.Active.ManifestHash){throw 'RESTORE_AFTER_START_BLOCKED'}
 foreach($name in @('At58.Host.ps1','settings.json')){
  $saved=Ops-Inside $backup (Join-Path $backup $name)
  $old=[string](Ops-Get $receipt.OriginalHashes $name '')
  $next=[string](Ops-Get $receipt.NewHashes $name '')
  $target=Ops-Inside $paths.Host (Join-Path $paths.Host $name)
  if((IP-Hash $saved) -cne $old -or (IP-Hash $target) -cnotin @($old,$next)){throw 'BACKUP_OR_TARGET_CHANGED'}
 }
 $ready=Ops-Inside $paths.Host (Join-Path $paths.Host 'local-upgrade\ready.json')
 if([IO.File]::Exists($ready) -and (IP-Hash $ready) -cne $receipt.OfferHash){throw 'QUEUED_OFFER_CHANGED'}
 if([IO.File]::Exists($ready)){[IO.File]::Delete($ready)}
 foreach($name in @('settings.json','At58.Host.ps1')){IP-WriteBytes (Join-Path $paths.Host $name) ([IO.File]::ReadAllBytes((Join-Path $backup $name)))}
 $receipt.Phase='RESTORED';Ops-WriteJson (Join-Path $backup 'receipt.json') $receipt
}
function IP-Apply([string]$localRoot,[string]$package){
 $null=IP-CheckPackage $package
 . (Join-Path $package 'host/At58.Ops.ps1')
 . (Join-Path $package 'host/At58.Update.ps1')
 $paths=IP-Paths $localRoot;$locks=IP-Lock $paths
 $backup='';$changed=$false
 try{
  $pending=Ops-ReadJson (Join-Path $paths.Host 'rollover-install.json')
  if($pending -and $pending.Phase -cin @('PREPARED','APPLIED')){throw 'INSTALL_ALREADY_STAGED'}
  $info=IP-Inspect $paths $package
  $offer=$info.Offer;$null=Up-Validate (Join-Path $package 'bundle') $offer.ManifestHash
  $localChannel=Ops-Inside $paths.Host (Join-Path $paths.Host 'local-upgrade')
  $ready=Ops-Inside $paths.Host (Join-Path $localChannel 'ready.json')
  if([IO.File]::Exists($ready)){throw 'ANOTHER_UPDATE_QUEUED'}
  $dest=Ops-Inside $paths.Host (Join-Path $localChannel ('releases\'+$offer.Id))
  if([IO.Directory]::Exists($dest)){$null=Up-Validate $dest $offer.ManifestHash}else{
   [void][IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($dest))
   Copy-Item -LiteralPath (Join-Path $package 'bundle') -Destination $dest -Recurse
   $null=Up-Validate $dest $offer.ManifestHash
  }
  $backup=Ops-Inside $paths.Host (Join-Path $paths.Host ('rollover-backups\'+[guid]::NewGuid().ToString('N')))
  [void][IO.Directory]::CreateDirectory($backup)
  $oldHashes=@{}
  foreach($n in @('At58.Host.ps1','settings.json')){Copy-Item -LiteralPath (Join-Path $paths.Host $n) -Destination (Join-Path $backup $n);$oldHashes[$n]=IP-Hash (Join-Path $backup $n)}
  $cfg=$info.Config;$cfg|Add-Member NoteProperty ManualWhenRunning $false -Force;$cfg|Add-Member NoteProperty ResumeOnce $true -Force
  Ops-WriteJson (Join-Path $backup 'settings.new.json') $cfg
  $newHashes=@{'At58.Host.ps1'=(IP-Hash (Join-Path $package 'host/At58.Host.ps1'));'settings.json'=(IP-Hash (Join-Path $backup 'settings.new.json'))}
  $receipt=@{Schema='AVATA-ROLLOVER-BACKUP-1';Phase='PREPARED';Host=$paths.Host;Active=$info.Active;OriginalHashes=$oldHashes;NewHashes=$newHashes;OfferHash=(IP-Hash (Join-Path $package 'offer.json'))}
  Ops-WriteJson (Join-Path $backup 'receipt.json') $receipt
  Ops-WriteJson (Join-Path $paths.Host 'rollover-install.json') @{Phase='PREPARED';Backup=$backup;Candidate=$offer.Id}
  $changed=$true;IP-Checkpoint 'BEFORE_HOST'
  IP-WriteBytes (Join-Path $paths.Host 'At58.Host.ps1') ([IO.File]::ReadAllBytes((Join-Path $package 'host/At58.Host.ps1')))
  IP-Checkpoint 'AFTER_HOST'
  IP-WriteBytes (Join-Path $paths.Host 'settings.json') ([IO.File]::ReadAllBytes((Join-Path $backup 'settings.new.json')))
  IP-Checkpoint 'AFTER_SETTINGS'
  IP-WriteBytes $ready ([IO.File]::ReadAllBytes((Join-Path $package 'offer.json')))
  IP-Checkpoint 'AFTER_OFFER'
  $receipt.Phase='APPLIED';Ops-WriteJson (Join-Path $backup 'receipt.json') $receipt
  Ops-WriteJson (Join-Path $paths.Host 'rollover-install.json') @{Phase='APPLIED';Backup=$backup;Candidate=$offer.Id}
  return 'UPDATE_STAGED'
 }catch{
  $failure=$_
  if($changed){try{IP-Restore $paths $backup;Ops-WriteJson (Join-Path $paths.Host 'rollover-install.json') @{Phase='RESTORED';Backup=$backup}}catch{throw 'INSTALL_ROLLBACK_REQUIRES_REVIEW'}}
  throw $failure
 }finally{IP-Unlock $locks}
}
function IP-Cancel([string]$localRoot,[string]$package){
 $null=IP-CheckPackage $package
 . (Join-Path $package 'host/At58.Ops.ps1')
 $paths=IP-Paths $localRoot;$locks=IP-Lock $paths
 try{
  $p=IP-Read (Join-Path $paths.Host 'rollover-install.json')
  if($p.Phase -cnotin @('PREPARED','APPLIED')){throw 'NO_PENDING_INSTALL'}
  $backup=Ops-Inside (Join-Path $paths.Host 'rollover-backups') $p.Backup
  IP-Restore $paths $backup
  Ops-WriteJson (Join-Path $paths.Host 'rollover-install.json') @{Phase='RESTORED';Backup=$backup}
  return 'UPDATE_CANCELLED'
 }finally{IP-Unlock $locks}
}
function IP-Recover([string]$localRoot,[string]$package){
 $null=IP-CheckPackage $package
 . (Join-Path $package 'recovery/Repair_Input_After_Transfer.ps1')
 return (RI-Repair $localRoot)
}
if($MyInvocation.InvocationName -eq '.'){return}
$null=IP-CheckPackage $PSScriptRoot
IP-RequireValidation $PSScriptRoot $ValidationFile
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
$form=[Windows.Forms.Form]::new();$form.Text='Avata 58.17.2 적용 준비';$form.ClientSize=[Drawing.Size]::new(650,325);$form.StartPosition='CenterScreen'
$label=[Windows.Forms.Label]::new();$label.SetBounds(18,18,615,115)
$label.Text="1. 실주문 꺼짐(DISARMED)을 확인하세요. 입력 오류일 때만 입력 복구를 누르세요.`r`n2. 조회가 정상(READ_OK)이면 X로 정상 종료하세요. 이자 차이는 적용 시 대조합니다.`r`n3. 종료 직후 [수정본 적용]을 누르세요. 이자 대조에는 잠시 시간이 걸립니다.`r`n4. 적용 완료 후 아바타를 다시 실행하세요. 새 버전 계좌 조회부터 확인합니다.`r`n`r`n실주문 재개는 아바타에서 사용자가 별도로 승인해야 합니다."
$form.Controls.Add($label)
$status=[Windows.Forms.Label]::new();$status.SetBounds(18,225,615,85);$status.Text='자동 검사 통과. 현재 이 도구를 실행한 PC에 적용합니다. 실주문은 꺼둔 상태로 진행하세요.';$form.Controls.Add($status)
$recover=[Windows.Forms.Button]::new();$recover.SetBounds(18,150,195,46);$recover.Text='1. 입력 연결 복구';$form.Controls.Add($recover)
$apply=[Windows.Forms.Button]::new();$apply.SetBounds(227,150,195,46);$apply.Text='2. 수정본 적용';$form.Controls.Add($apply)
$cancel=[Windows.Forms.Button]::new();$cancel.SetBounds(437,150,195,46);$cancel.Text='적용 예약 취소';$form.Controls.Add($cancel)
function IP-ShowError($e){
 $code=[string]$e.Exception.Message;if($code -cnotmatch '^[A-Z][A-Z0-9_]{1,70}$'){$code='INSTALL_ERROR'}
 $status.Text='완료하지 못했습니다. 진단 코드: '+$code
 if($code -ceq 'PROGRAM_RUNNING'){$status.Text+=' / 아바타를 정상 종료한 뒤 다시 누르세요.'}
 if($code -ceq 'STOP_RECONCILE_CLOSE_REQUIRED'){$status.Text+=' / 정지와 계좌 대조를 완료한 뒤 정상 종료가 필요합니다.'}
 if($code -like 'PREFLIGHT_*' -or $code -ceq 'RUN_START_UPDATE_FIRST'){$status.Text+=' / 창을 닫고 Start_Update.cmd를 다시 실행하세요.'}
 if($code -ceq 'INSTALL_ALREADY_STAGED'){$status.Text+=' / 이미 적용 예약이 있습니다. 아바타를 실행하거나 예약을 취소하세요.'}
}
$recover.Add_Click({$recover.Enabled=$false;$apply.Enabled=$false;$cancel.Enabled=$false;try{IP-RequireValidation $PSScriptRoot $ValidationFile;$status.Text='오늘 입력을 읽는 중...';$form.Refresh();$r=IP-Recover $LocalBase $PSScriptRoot;$status.Text='입력 복구 완료. 아바타의 DISARMED / 계좌 대조 완료를 확인하고 정상 종료하세요.'}catch{IP-ShowError $_}finally{$recover.Enabled=$true;$apply.Enabled=$true;$cancel.Enabled=$true}})
$apply.Add_Click({$recover.Enabled=$false;$apply.Enabled=$false;$cancel.Enabled=$false;try{IP-RequireValidation $PSScriptRoot $ValidationFile;$status.Text='검증 및 백업 중... 이자 차이가 있으면 증권사 조회로 두 번 대조합니다.';$form.Refresh();$null=IP-Apply $LocalBase $PSScriptRoot;$status.Text='적용 예약 완료. 이 창을 닫고 아바타를 다시 실행하세요. 58.17.2 / 정상 조회를 확인한 후 실주문은 별도로 승인하세요.'}catch{IP-ShowError $_}finally{$recover.Enabled=$true;$apply.Enabled=$true;$cancel.Enabled=$true}})
$cancel.Add_Click({$recover.Enabled=$false;$apply.Enabled=$false;$cancel.Enabled=$false;try{$null=IP-Cancel $LocalBase $PSScriptRoot;$status.Text='적용 예약을 취소하고 이전 프로그램 및 업데이트 설정을 복원했습니다.'}catch{IP-ShowError $_}finally{$recover.Enabled=$true;$apply.Enabled=$true;$cancel.Enabled=$true}})
[void]$form.ShowDialog();$form.Dispose()
