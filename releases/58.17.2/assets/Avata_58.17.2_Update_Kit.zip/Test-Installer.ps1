﻿param([string]$Root='',[Parameter(Mandatory=$true)][string]$OriginalRoot)
$ErrorActionPreference='Stop'
if([string]::IsNullOrWhiteSpace($Root)){$Root=Split-Path -Parent $MyInvocation.MyCommand.Path}
. (Join-Path $Root 'Install-Rollover.ps1')
. (Join-Path $Root 'host/At58.Ops.ps1')
. (Join-Path $Root 'host/At58.Update.ps1')
$script:passed=0
function Check($condition,[string]$name){if(!$condition){throw ('FAILED: '+$name)};$script:passed++;Write-Output ('PASS '+$name)}
function Reject($action,[string]$code,[string]$name){$actual='';try{& $action|Out-Null}catch{$actual=$_.Exception.Message};Check ($actual -ceq $code) ($name+' ['+$actual+']')}
$work=Join-Path ([IO.Path]::GetTempPath()) ('AIT-'+[guid]::NewGuid().ToString('N').Substring(0,12))
if([IO.Directory]::Exists($work)){throw 'TEST_DIRECTORY_COLLISION'}
$null=[IO.Directory]::CreateDirectory($work)
$script:fixtureId=0
function Fixture([string]$name){
 $script:fixtureId++;$base=Join-Path $work ('f'+$script:fixtureId);$p=IP-Paths $base
 foreach($d in @($p.Host,$p.Manage,$p.Data)){[void][IO.Directory]::CreateDirectory($d)}
 foreach($n in @('At58.Host.ps1','At58.Ops.ps1','At58.Update.ps1')){Copy-Item -LiteralPath (Join-Path $OriginalRoot $n) -Destination (Join-Path $p.Host $n)}
 $offer=IP-Read (Join-Path $OriginalRoot 'channel/ready.json')
 $bundles=Join-Path $p.Host 'bundles';[void][IO.Directory]::CreateDirectory($bundles)
 Copy-Item -LiteralPath (Join-Path $OriginalRoot ('channel/releases/'+$offer.Id)) -Destination (Join-Path $bundles $offer.Id) -Recurse
 Ops-WriteJson (Join-Path $p.Host 'active.json') @{Id=$offer.Id;Version=$offer.Version;ManifestHash=$offer.ManifestHash}
 Ops-WriteJson (Join-Path $p.Host 'settings.json') @{Schema='AT58-HOST-1';HostProtocol=2;Enabled=$true;DataRoot=$p.Data;ManagementRoot=$p.Manage;ChannelRoot=(Join-Path $p.Host 'remote-channel');FeedUrl='https://github.com/crosnuu12/Avata-kor-releases/releases/latest/download/avata-update.json';ManualWhenRunning=$true;ResumeOnce=$false;PreserveMe='synthetic'}
 $id=[guid]::NewGuid().ToString();$stamp=[datetime]::UtcNow.ToString('o')
 $live=@{Schema='AT-LIVE-STATUS-1';HostProtocol=2;RunId=$id;Utc=$stamp;State='DISARMED';ExecutionEnabled=$false;OrdersSent=0;OpenOrders=0;UncertainOrders=0;Reconciled=$true;Confirmations=2;TestOnly=$false}
 Ops-WriteJson (Join-Path $p.Data 'status.json') @{HostProtocol=2;RunId=$id;Utc=$stamp;Live=$live;ExecutionEnabled=$false;OrdersSent=0;Code='OK'}
 Ops-WriteJson (Join-Path $p.Manage 'runtime.json') @{HostProtocol=2;RunId=$id;Utc=$stamp;LiveMode='LIVE';ExitReason='USER_CLOSE';ExecutionEnabled=$false;LiveCommandPending=$false}
 [IO.File]::WriteAllText((Join-Path $p.Data 'protected-ledger-marker.txt'),'DO NOT CHANGE')
 return $p
}
try{
 # The user-facing installer must reject missing, stale or changed preflight results.
 $gate=Join-Path $work 'gate';$gateLogs=Join-Path $gate 'logs';[void][IO.Directory]::CreateDirectory($gateLogs)
 [IO.File]::WriteAllText((Join-Path $gate 'package.json'),'synthetic-manifest')
 $gateLog=Join-Path $gateLogs 'test.txt';[IO.File]::WriteAllText($gateLog,'synthetic passing output')
 $gateReceipt=Join-Path $gateLogs 'receipt.json'
 $receipt=@{Schema='AVATA-PREFLIGHT-1';Result='PASSED';Engine='WindowsPowerShell-5.1';Root=$gate;PackageHash=(IP-Hash (Join-Path $gate 'package.json'));Utc=[datetime]::UtcNow.ToString('o');Log=$gateLog;LogHash=(IP-Hash $gateLog)}
 Ops-WriteJson $gateReceipt $receipt
 Reject {IP-RequireValidation $gate ''} 'RUN_START_UPDATE_FIRST' 'direct installer entry requires tests first'
 IP-RequireValidation $gate $gateReceipt;Check $true 'matching current preflight accepted'
 $receipt.Utc=[datetime]::UtcNow.AddHours(-7).ToString('o');Ops-WriteJson $gateReceipt $receipt
 Reject {IP-RequireValidation $gate $gateReceipt} 'PREFLIGHT_EXPIRED' 'old tests cannot authorize new application'
 $receipt.Utc=[datetime]::UtcNow.ToString('o');Ops-WriteJson $gateReceipt $receipt
 [IO.File]::AppendAllText((Join-Path $gate 'package.json'),'changed')
 Reject {IP-RequireValidation $gate $gateReceipt} 'PREFLIGHT_PACKAGE_MISMATCH' 'changed package requires fresh tests'
 $receipt.PackageHash=IP-Hash (Join-Path $gate 'package.json');Ops-WriteJson $gateReceipt $receipt
 [IO.File]::AppendAllText($gateLog,'changed')
 Reject {IP-RequireValidation $gate $gateReceipt} 'PREFLIGHT_LOG_CHANGED' 'changed test record rejected'
 $m=IP-CheckPackage $Root
 Check ($m.Version -ceq '58.17.2') 'package hashes and expected scripts verified'
 $offer=IP-Read (Join-Path $Root 'offer.json')
 $release=Up-Validate (Join-Path $Root 'bundle') $offer.ManifestHash
 Check ($release.Version -ceq '58.17.2' -and $release.HostProtocol -eq 2) 'actual updater accepts candidate bundle'
 $p=Fixture 'normal';$oldHost=IP-Hash (Join-Path $p.Host 'At58.Host.ps1');$oldSettings=IP-Hash (Join-Path $p.Host 'settings.json');$oldActive=IP-Hash (Join-Path $p.Host 'active.json')
 Check ((IP-Apply $p.Base $Root) -ceq 'UPDATE_STAGED') 'installer stages update while all app processes are closed'
 Check ((IP-Hash (Join-Path $p.Host 'active.json')) -ceq $oldActive) 'installer leaves active bundle pointer unchanged'
 $cfg=IP-Read (Join-Path $p.Host 'settings.json')
 Check ($cfg.ManualWhenRunning -eq $false -and $cfg.ResumeOnce -eq $true -and $cfg.PreserveMe -ceq 'synthetic') 'automatic application enabled while unrelated settings preserved'
 $queued=Up-Offer (Join-Path $p.Host 'local-upgrade')
 Check ($queued.Id -ceq $offer.Id) 'real updater validates locally queued offer'
 Check ([IO.File]::ReadAllText((Join-Path $p.Data 'protected-ledger-marker.txt')) -ceq 'DO NOT CHANGE') 'installer leaves account data untouched'
 Reject {IP-Apply $p.Base $Root} 'INSTALL_ALREADY_STAGED' 'repeat apply cannot create a second transaction'
 Check ((IP-Cancel $p.Base $Root) -ceq 'UPDATE_CANCELLED') 'staged application can be cancelled before restart'
 Check ((IP-Hash (Join-Path $p.Host 'At58.Host.ps1')) -ceq $oldHost -and (IP-Hash (Join-Path $p.Host 'settings.json')) -ceq $oldSettings) 'cancellation restores original host and settings byte for byte'
 Check (!(Test-Path -LiteralPath (Join-Path $p.Host 'local-upgrade/ready.json'))) 'cancellation removes queued offer'
 foreach($point in @('BEFORE_HOST','AFTER_HOST','AFTER_SETTINGS','AFTER_OFFER')){
  $p=Fixture ('fault-'+$point);$h=IP-Hash (Join-Path $p.Host 'At58.Host.ps1');$s=IP-Hash (Join-Path $p.Host 'settings.json')
  $script:failAt=$point
  function IP-Checkpoint([string]$name){if($name -ceq $script:failAt){throw 'TEST_INJECTED_FAILURE'}}
  Reject {IP-Apply $p.Base $Root} 'TEST_INJECTED_FAILURE' ('injected interruption at '+$point)
  Check ((IP-Hash (Join-Path $p.Host 'At58.Host.ps1')) -ceq $h -and (IP-Hash (Join-Path $p.Host 'settings.json')) -ceq $s -and !(Test-Path -LiteralPath (Join-Path $p.Host 'local-upgrade/ready.json'))) ('transaction rollback at '+$point)
 }
 function IP-Checkpoint([string]$name){}
 foreach($lockKind in @('host','manager','direct')){
  $p=Fixture ('mutex-'+$lockKind);$target=@{host=$p.Host;manager=$p.Manage;direct=$p.Data}[$lockKind]
  $created=$false;$lock=[Threading.Mutex]::new($true,('Local\esbada-AT-'+$lockKind+'-'+(Ops-Key $target.ToLowerInvariant()).Substring(0,24)),[ref]$created)
  try{Reject {IP-Apply $p.Base $Root} 'PROGRAM_RUNNING' ('running '+$lockKind+' blocks installation')}finally{$lock.ReleaseMutex();$lock.Dispose()}
 }
 foreach($case in @('ARMED','STOPPING','UNCERTAIN','UNRECONCILED','OLD_STATUS','PENDING_COMMAND')){
  $p=Fixture $case;$s=IP-Read (Join-Path $p.Data 'status.json');$r=IP-Read (Join-Path $p.Manage 'runtime.json')
  switch($case){
   'ARMED' {$s.Live.State='ARMED'}
   'STOPPING' {$s.Live.State='STOPPING'}
   'UNCERTAIN' {$s.Live.UncertainOrders=1}
   'UNRECONCILED' {$s.Live.Reconciled=$false}
   'OLD_STATUS' {$r.Utc=[datetime]::UtcNow.AddMinutes(-2).ToString('o')}
   'PENDING_COMMAND' {$r.LiveCommandPending=$true}
  }
  Ops-WriteJson (Join-Path $p.Data 'status.json') $s;Ops-WriteJson (Join-Path $p.Manage 'runtime.json') $r
  Reject {IP-Apply $p.Base $Root} 'STOP_RECONCILE_CLOSE_REQUIRED' ('unsafe state rejected: '+$case)
 }
 # The installer may proceed from CASH_WAIT only after the dedicated read-only
 # verifier supplies its quorum. Broker verification itself is tested separately.
 $script:proofCalls=0;$script:proofResult=$true
 function IP-VerifyInterestRecovery($paths,$package){$script:proofCalls++;return $script:proofResult}
 $p=Fixture 'interest-proved';$s=IP-Read (Join-Path $p.Data 'status.json');$s.Live.Reconciled=$false;$s.Live.Confirmations=0;$s.Live|Add-Member Code 'LIVE_CASH_WAIT' -Force;Ops-WriteJson (Join-Path $p.Data 'status.json') $s
 $statusHash=IP-Hash (Join-Path $p.Data 'status.json')
 Check ((IP-Apply $p.Base $Root) -ceq 'UPDATE_STAGED' -and $script:proofCalls -eq 1) 'stopped interest mismatch requires successful independent cash verifier'
 Check ((IP-Hash (Join-Path $p.Data 'status.json')) -ceq $statusHash) 'interest recovery does not fabricate reconciled runtime status'
 $p=Fixture 'interest-unproved';$s=IP-Read (Join-Path $p.Data 'status.json');$s.Live.Reconciled=$false;$s.Live|Add-Member Code 'LIVE_CASH_WAIT' -Force;Ops-WriteJson (Join-Path $p.Data 'status.json') $s
 $script:proofResult=$false;$hostHash=IP-Hash (Join-Path $p.Host 'At58.Host.ps1')
 Reject {IP-Apply $p.Base $Root} 'CASH_RECOVERY_NOT_VERIFIED' 'cash-wait label alone cannot authorize an update'
 Check ((IP-Hash (Join-Path $p.Host 'At58.Host.ps1')) -ceq $hostHash -and !(Test-Path -LiteralPath (Join-Path $p.Host 'local-upgrade/ready.json'))) 'failed cash verification leaves installation and queued update untouched'
 $script:proofResult=$true;$p=Fixture 'interest-open';$s=IP-Read (Join-Path $p.Data 'status.json');$s.Live.Reconciled=$false;$s.Live.OpenOrders=1;$s.Live|Add-Member Code 'LIVE_CASH_WAIT' -Force;Ops-WriteJson (Join-Path $p.Data 'status.json') $s;$before=$script:proofCalls
 Reject {IP-Apply $p.Base $Root} 'STOP_RECONCILE_CLOSE_REQUIRED' 'interest code cannot bypass open-order guard'
 Check ($script:proofCalls -eq $before) 'unsafe execution state is rejected before cash verification'
 $p=Fixture 'wrong-version';$a=IP-Read (Join-Path $p.Host 'active.json');$a.Version='58.16.0';Ops-WriteJson (Join-Path $p.Host 'active.json') $a
 Reject {IP-Apply $p.Base $Root} 'INSTALLED_VERSION' 'unknown version rejected'
 $p=Fixture 'tampered-host';[IO.File]::AppendAllText((Join-Path $p.Host 'At58.Host.ps1'),'# synthetic local edit')
 Reject {IP-Apply $p.Base $Root} 'INSTALLED_HOST_CHANGED' 'local host modifications are not overwritten'
 $p=Fixture 'changed-after-stage';$null=IP-Apply $p.Base $Root
 $a=IP-Read (Join-Path $p.Host 'active.json');$a.Id=$offer.Id;$a.ManifestHash=$offer.ManifestHash;$a.Version=$offer.Version;Ops-WriteJson (Join-Path $p.Host 'active.json') $a
 Reject {IP-Cancel $p.Base $Root} 'RESTORE_AFTER_START_BLOCKED' 'manual rollback cannot silently replace active newer app'
 Write-Output ('INSTALLER TESTS COMPLETE: '+$script:passed+' passed; synthetic local state only; no network or orders.')
}finally{
 $safe=[IO.Path]::GetFullPath($work);$temp=[IO.Path]::GetFullPath([IO.Path]::GetTempPath()).TrimEnd('\')+'\'
 if(!$safe.StartsWith($temp,[StringComparison]::OrdinalIgnoreCase) -or [IO.Path]::GetFileName($safe) -cnotmatch '^AIT-[a-f0-9]{12}$'){throw 'TEST_CLEANUP_PATH'}
 if(Test-Path -LiteralPath $work){Remove-Item -LiteralPath $safe -Recurse -Force}
}
