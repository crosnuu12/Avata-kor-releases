﻿#requires -Version 5.1
param([string]$OriginalRoot=(Join-Path $PSScriptRoot 'tests/original'))
$ErrorActionPreference='Stop'
if($PSVersionTable.PSVersion.Major -ne 5 -or $PSVersionTable.PSVersion.Minor -ne 1 -or [Environment]::OSVersion.Platform -ne [PlatformID]::Win32NT){throw 'WINDOWS_POWERSHELL_51_REQUIRED'}
foreach($file in Get-ChildItem -LiteralPath $PSScriptRoot -Filter '*.ps1' -Recurse){
 $tokens=$null;$errors=$null;$null=[Management.Automation.Language.Parser]::ParseFile($file.FullName,[ref]$tokens,[ref]$errors)
 if($errors.Count){$errors|ForEach-Object {Write-Output $_.Message};throw ('SYNTAX: '+$file.Name)}
}
$exe=Join-Path $env:SystemRoot 'System32/WindowsPowerShell/v1.0/powershell.exe'
foreach($path in @('bundle/payload/Test-AT58.ps1','bundle/payload/Test-AT58LogViewer.ps1','Test-Rollover.ps1','Test-CashInterest.ps1')){
 Write-Output ('RUN '+$path)
 & $exe -NoProfile -NonInteractive -ExecutionPolicy RemoteSigned -File (Join-Path $PSScriptRoot $path)
 if($LASTEXITCODE -ne 0){throw ('TEST FAILED: '+$path)}
}
Write-Output 'RUN Test-Installer.ps1'
& $exe -NoProfile -NonInteractive -ExecutionPolicy RemoteSigned -File (Join-Path $PSScriptRoot 'Test-Installer.ps1') -OriginalRoot $OriginalRoot
if($LASTEXITCODE -ne 0){throw 'TEST FAILED: Test-Installer.ps1'}
Write-Output 'ALL CHECKS PASSED on Windows PowerShell 5.1'
