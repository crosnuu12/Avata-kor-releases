﻿#requires -Version 5.1
param([switch]$ChecksOnly)
$ErrorActionPreference='Stop'
$log='';$transcribing=$false;$receiptPath=''
try{
 if($PSVersionTable.PSVersion.Major -ne 5 -or $PSVersionTable.PSVersion.Minor -ne 1 -or [Environment]::OSVersion.Platform -ne [PlatformID]::Win32NT){throw 'WINDOWS_POWERSHELL_51_REQUIRED'}
 . (Join-Path $PSScriptRoot 'Install-Rollover.ps1')
 $null=IP-CheckPackage $PSScriptRoot
 $packageHash=IP-Hash (Join-Path $PSScriptRoot 'package.json')
 $logRoot=Join-Path $PSScriptRoot 'logs';[void][IO.Directory]::CreateDirectory($logRoot)
 $run=[datetime]::Now.ToString('yyyyMMdd-HHmmss')+'-'+[guid]::NewGuid().ToString('N').Substring(0,8)
 $log=Join-Path $logRoot ($run+'-checks.txt');$receiptPath=Join-Path $logRoot ($run+'-passed.json')
 $null=Start-Transcript -LiteralPath $log;$transcribing=$true
 Write-Host 'Avata 58.17.2 - 적용 전 자동 검사' -ForegroundColor Cyan
 Write-Host '가상 계좌 데이터로 검사합니다. 검사 중 설치된 아바타나 실계좌는 변경하지 않습니다.'
 Write-Host '모든 검사가 통과하면 입력 복구 / 수정본 적용 창이 열립니다.'
 $exe=Join-Path $env:SystemRoot 'System32/WindowsPowerShell/v1.0/powershell.exe'
 & $exe -NoProfile -NonInteractive -ExecutionPolicy RemoteSigned -File (Join-Path $PSScriptRoot 'Run-Checks.ps1')
 if($LASTEXITCODE -ne 0){throw 'PREFLIGHT_FAILED'}
 $null=IP-CheckPackage $PSScriptRoot
 if((IP-Hash (Join-Path $PSScriptRoot 'package.json')) -cne $packageHash){throw 'PACKAGE_CHANGED_DURING_CHECK'}
 Write-Host '자동 검사 통과.' -ForegroundColor Green
 $null=Stop-Transcript;$transcribing=$false
 $receipt=@{Schema='AVATA-PREFLIGHT-1';Result='PASSED';PackageHash=$packageHash;Root=[IO.Path]::GetFullPath($PSScriptRoot);Utc=[datetime]::UtcNow.ToString('o');Engine='WindowsPowerShell-5.1';Log=$log;LogHash=(IP-Hash $log)}
 [IO.File]::WriteAllText($receiptPath,($receipt|ConvertTo-Json -Compress),[Text.UTF8Encoding]::new($false))
 if($ChecksOnly){Write-Output ('PREFLIGHT_ONLY_PASSED: '+$receiptPath);exit 0}
 & $exe -NoProfile -STA -ExecutionPolicy RemoteSigned -File (Join-Path $PSScriptRoot 'Install-Rollover.ps1') -ValidationFile $receiptPath
 if($LASTEXITCODE -ne 0){throw 'INSTALL_WINDOW_FAILED'}
 exit 0
}catch{
 $code=[string]$_.Exception.Message
 if($code -cnotmatch '^[A-Z][A-Z0-9_]{1,70}$'){$code='UPDATE_CHECK_ERROR'}
 Write-Host ('준비를 완료하지 못했습니다. 코드: '+$code) -ForegroundColor Red
 if($transcribing){try{$null=Stop-Transcript}catch{};$transcribing=$false}
 if($log){Write-Host ('검사 기록: '+$log)}
 Write-Host '적용 완료가 확인되지 않았습니다. 이 화면과 logs 폴더의 검사 기록을 보관하세요.'
 exit 1
}
