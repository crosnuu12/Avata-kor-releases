﻿param([string]$Root=$PSScriptRoot)
$ErrorActionPreference='Stop';Set-StrictMode -Version 2
. (Join-Path $Root 'bundle/At58.Ops.ps1')
. (Join-Path $Root 'bundle/At58.Sheets.ps1')
. (Join-Path $Root 'bundle/payload/At58.Core.ps1')
. (Join-Path $Root 'tests/CashFixture.ps1')
$script:checks=0;$script:network=0
function Check($ok,[string]$name){if(!$ok){throw ('FAILED: '+$name)};$script:checks++;Write-Output ('PASS '+$name)}
function Invoke-RestMethod {$script:network++;throw 'TEST_NETWORK_FORBIDDEN'}
function At58T-Wire {$script:network++;throw 'TEST_ORDER_FORBIDDEN'}
function At58-Http {$script:network++;throw 'TEST_NETWORK_FORBIDDEN'}
$work=Join-Path ([IO.Path]::GetTempPath()) ('AvataAutoTest-'+[guid]::NewGuid().ToString('N'))
[void][IO.Directory]::CreateDirectory($work)
try{
 $f=Cash-Fixture (Join-Path $work 'account');$owner=$f.Owner;$owner.Version='58.17.6';$owner.ManagementRoot=Join-Path $work 'manage'
 $script:cashClock=[datetime]::UtcNow;$now=$script:cashClock;$script:sourceForAuto=$f.Source
 function At58X-Input($owner){return @{Source=$script:sourceForAuto}}
 function Fresh {
  $box=At58X-Mailbox $owner.RunId;$box.Mode='LIVE';$box.SourceHash=$f.Source.Hash;$box.LastUtc=$now.ToString('o');$box.UiUtc=$now.ToString('o')
  $box.Last=[pscustomobject]@{Schema='AT-LIVE-STATUS-1';HostProtocol=2;RunId=$owner.RunId;Utc=$now.ToString('o');State='DISARMED';ExecutionEnabled=$false;Reconciled=$true;Confirmations=2;OpenOrders=0;UncertainOrders=0;TestOnly=$false}
  $b=[pscustomobject]@{Version='58.17.6';State='CURRENT';HostSession='synthetic-host';Utc=$now.ToString('o')}
  $m=[pscustomobject]@{BundleVersion='58.17.6';State='HEALTHY';HostSession='synthetic-host';RunId=$owner.RunId;Utc=$now.ToString('o');CircuitOpen=$false;RepairRunning=$false;RepairTransaction=$false}
  return @{Box=$box;Bundle=$b;Manager=$m}
 }
 function Save-Host($v){Ops-WriteJson (Join-Path $owner.ManagementRoot 'bundle-status.json') $v.Bundle;Ops-WriteJson (Join-Path $owner.ManagementRoot 'manager-status.json') $v.Manager}
 function Ready($v){return (At58AS-Ready $v.Box $v.Bundle $v.Manager $now '58.17.6')}
 Check (!(At58AS-Load $owner).Enabled) 'new installation defaults off'
 $v=Fresh;$off=At58AS-NewRun (At58AS-Load $owner) $owner.RunId
 Check (!(At58AS-TryQueue $off $v.Box $v.Bundle $v.Manager $now '58.17.6') -and !$v.Box.Command) 'update or startup without local consent cannot queue activation'
 $pref=At58AS-Save $owner $true;$pref=At58AS-Load $owner
 Check ($pref.Enabled -and $pref.ConsentId.Length -eq 32) 'explicit local preference survives encrypted round trip'
 $cipher=[IO.File]::ReadAllText((At58AS-Path $owner))
 Check (!$cipher.Contains($owner.Scope) -and !$cipher.Contains('Enabled')) 'preference contains no plaintext account identifier'
 $other=@{};foreach($k in $owner.Keys){$other[$k]=$owner[$k]};$other.Scope='f'*64
 Check (!(At58AS-Load $other).Enabled) 'different account cannot inherit approval'
 $other.Scope=$owner.Scope;$other.Symbol='000001'
 Check (!(At58AS-Load $other).Enabled) 'different symbol cannot inherit approval'
 $other.Symbol=$owner.Symbol;$other.LiveTestMode=$true
 Check (!(At58AS-Load $other).Enabled) 'test and real preferences cannot cross modes'
 $other.LiveTestMode=$false;$other.Root=Join-Path $work 'copied';[void][IO.Directory]::CreateDirectory($other.Root);[IO.File]::WriteAllText((At58AS-Path $other),$cipher)
 Check (!(At58AS-Load $other).Enabled) 'copied settings in another data directory cannot activate'
 [IO.File]::WriteAllText((At58AS-Path $owner),'corrupt')
 Check (!(At58AS-Load $owner).Enabled) 'corrupt preference fails closed'
 [IO.File]::WriteAllText((At58AS-Path $owner),$cipher)
 Check ((Ready (Fresh)) -ceq 'READY') 'fresh reconciled installed bundle is ready'
 $cases=@(
  @{Name='missing ledger';Change={$args[0].Box.Mode='PAPER'}},
  @{Name='one reconciliation';Change={$args[0].Box.Last.Confirmations=1}},
  @{Name='malformed confirmation count';Change={$args[0].Box.Last.Confirmations='two'}},
  @{Name='malformed manager flag';Change={$args[0].Manager.RepairRunning='false'}},
  @{Name='cash mismatch';Change={$args[0].Box.Last.Reconciled=$false}},
  @{Name='open orders';Change={$args[0].Box.Last.OpenOrders=1}},
  @{Name='uncertain orders';Change={$args[0].Box.Last.UncertainOrders=1}},
  @{Name='stale account result';Change={$args[0].Box.Last.Utc=$now.AddSeconds(-31).ToString('o')}},
  @{Name='future account result';Change={$args[0].Box.Last.Utc=$now.AddSeconds(3).ToString('o')}},
  @{Name='stale completion';Change={$args[0].Box.LastUtc=$now.AddSeconds(-31).ToString('o')}},
  @{Name='wrong result process';Change={$args[0].Box.Last.RunId=[guid]::NewGuid().ToString()}},
  @{Name='execution already enabled';Change={$args[0].Box.Last.ExecutionEnabled=$true}},
  @{Name='busy worker';Change={$args[0].Box.Busy=$true}},
  @{Name='pending command';Change={$args[0].Box.Command=[pscustomobject]@{Action='STOP'}}},
  @{Name='operator stop';Change={$args[0].Box.StopRequested=$true}},
  @{Name='review state';Change={$args[0].Box.State='REVIEW'}},
  @{Name='stopping state';Change={$args[0].Box.State='STOPPING'}},
  @{Name='already armed';Change={$args[0].Box.State='ARMED'}},
  @{Name='previous command error';Change={$args[0].Box.CommandError='LIVE_SOURCE_CHANGED'}},
  @{Name='missing source identity';Change={$args[0].Box.SourceHash=''}},
  @{Name='old installed version';Change={$args[0].Bundle.Version='58.17.2'}},
  @{Name='trial verification';Change={$args[0].Bundle.State='VERIFYING'}},
  @{Name='rejected release';Change={$args[0].Bundle.State='REJECTED'}},
  @{Name='stale installation status';Change={$args[0].Bundle.Utc=$now.AddSeconds(-21).ToString('o')}},
  @{Name='different host session';Change={$args[0].Manager.HostSession='other'}},
  @{Name='different manager process';Change={$args[0].Manager.RunId=[guid]::NewGuid().ToString()}},
  @{Name='stale manager';Change={$args[0].Manager.Utc=$now.AddSeconds(-21).ToString('o')}},
  @{Name='repair running';Change={$args[0].Manager.RepairRunning=$true}},
  @{Name='repair transaction';Change={$args[0].Manager.RepairTransaction=$true}},
  @{Name='circuit open';Change={$args[0].Manager.CircuitOpen=$true}},
  @{Name='unhealthy manager';Change={$args[0].Manager.State='PERSISTENT_ERROR'}}
 )
 foreach($case in $cases){$v=Fresh;& $case.Change $v;$a=At58AS-NewRun $pref $owner.RunId;Check (!(At58AS-TryQueue $a $v.Box $v.Bundle $v.Manager $now '58.17.6')) ('automatic activation waits: '+$case.Name)}
 $v=Fresh;$a=At58AS-NewRun $pref $owner.RunId;$v.Box.Last.Confirmations=1
 $null=At58AS-TryQueue $a $v.Box $v.Bundle $v.Manager $now '58.17.6';$v.Box.Last.Confirmations=2
 Check ((At58AS-TryQueue $a $v.Box $v.Bundle $v.Manager $now '58.17.6') -and $v.Box.Command.Action -ceq 'ARM_AUTO') 'readiness transition queues one consent-bound request'
 $id=$v.Box.Command.Id
 Check (!(At58AS-TryQueue $a $v.Box $v.Bundle $v.Manager $now '58.17.6') -and $v.Box.Command.Id -ceq $id) 'repeated timer ticks cannot queue duplicate activation'
 Save-Host $v;$v.Box.Busy=$true;At58X-Commands $owner $v.Box
 Check ($v.Box.CommandError -ceq '' -and $owner.LiveSession.State -ceq 'ARMED') 'worker accepts valid synthetic consent through existing authorization path'
 Check ($script:network -eq 0) 'authorization itself made no network request or order'
 $owner.Remove('LiveSession')
 $v=Fresh;Save-Host $v;$a=At58AS-NewRun $pref $owner.RunId;$null=At58AS-TryQueue $a $v.Box $v.Bundle $v.Manager $now '58.17.6'
 $null=At58AS-Save $owner $false;At58X-Commands $owner $v.Box
 Check ($v.Box.CommandError -ceq 'LIVE_AUTO_CONSENT' -and !$owner.ContainsKey('LiveSession')) 'revocation while queued is checked by worker'
 $pref=At58AS-Save $owner $true;$pref=At58AS-Load $owner
 $v=Fresh;Save-Host $v;At58X-Queue $v.Box 'ARM_AUTO' $v.Box.SourceHash (At58D-Limits) $now ('0'*32);At58X-Commands $owner $v.Box
 Check ($v.Box.CommandError -ceq 'LIVE_AUTO_CONSENT') 'unknown consent identifier is rejected'
 $v=Fresh;Save-Host $v;$a=At58AS-NewRun $pref $owner.RunId;$null=At58AS-TryQueue $a $v.Box $v.Bundle $v.Manager $now '58.17.6';$v.Box.StopRequested=$true;At58X-Commands $owner $v.Box
 Check ($v.Box.CommandError -ceq 'LIVE_AUTO_STOPPED') 'stop wins against a queued automatic start'
 $v=Fresh;Save-Host $v;$a=At58AS-NewRun $pref $owner.RunId;$null=At58AS-TryQueue $a $v.Box $v.Bundle $v.Manager $now '58.17.6';$v.Manager.RepairRunning=$true;Save-Host $v;At58X-Commands $owner $v.Box
 Check ($v.Box.CommandError -ceq 'LIVE_AUTO_WAIT_MANAGER') 'worker rechecks repair race before authorization'
 $v=Fresh;Save-Host $v;$a=At58AS-NewRun $pref $owner.RunId;$null=At58AS-TryQueue $a $v.Box $v.Bundle $v.Manager $now '58.17.6';$script:sourceForAuto=At58S-Clone $f.Source;$script:sourceForAuto.Hash='b'*64;At58X-Commands $owner $v.Box
 Check ($v.Box.CommandError -ceq 'LIVE_SOURCE_CHANGED') 'strategy changes between queue and execution are rejected'
 $script:sourceForAuto=$f.Source
 $v=Fresh;Save-Host $v;$a=At58AS-NewRun $pref $owner.RunId;$a.Suspended=$true
 Check (!(At58AS-TryQueue $a $v.Box $v.Bundle $v.Manager $now '58.17.6')) 'closing or pausing cancels this process automatic attempt'
 $v=Fresh;Save-Host $v;$a=At58AS-NewRun $pref ([guid]::NewGuid().ToString())
 Check (!(At58AS-TryQueue $a $v.Box $v.Bundle $v.Manager $now '58.17.6') -and $a.Suspended) 'automatic run state cannot cross process identity'
 $null=At58AS-Save $owner $false;$v=Fresh;Save-Host $v
 At58X-Queue $v.Box 'ARM' $v.Box.SourceHash (At58D-Limits) $now;At58X-Commands $owner $v.Box
 Check ($v.Box.CommandError -ceq '' -and $owner.LiveSession.State -ceq 'ARMED') 'existing explicit manual start remains available with auto option off'
 Check (!(At58AS-Load $owner).Enabled) 'manual start does not silently enable persistent auto option'
 Check (At58Window-LoadTray $owner.Root) 'first update and launch default to tray without requiring an old preference'
 At58Window-SaveTray $owner.Root
 Check (At58Window-LoadTray $owner.Root) 'minimize preference persists for subsequent launches and updates'
 [IO.File]::WriteAllText((Join-Path $owner.Root 'window-preferences.json'),'broken')
 Check (At58Window-LoadTray $owner.Root) 'damaged existing tray preference stays hidden'
 Add-Type -AssemblyName System.Windows.Forms;Add-Type -AssemblyName System.Drawing
 At58Window-Native
 Add-Type -TypeDefinition 'using System; using System.Runtime.InteropServices; public static class AvataFocusProbe { [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow(); }'
 $window=[AvataTrayWindow]::new();$window.TrayHidden=$true;$window.ShowInTaskbar=$false
 try{
  $before=[AvataFocusProbe]::GetForegroundWindow();$window.Show();[Windows.Forms.Application]::DoEvents()
  Check (!$window.Visible -and !$window.ShowInTaskbar -and $window.IsHandleCreated) 'hidden startup creates message-loop handle without a visible window'
  Check ([AvataFocusProbe]::GetForegroundWindow() -eq $before) 'hidden startup does not steal foreground focus'
  $window.Show();$window.BringToFront();[Windows.Forms.Application]::DoEvents()
  Check (!$window.Visible -and [AvataFocusProbe]::GetForegroundWindow() -eq $before) 'unsolicited show or bring-to-front cannot expose a tray-hidden window'
  $window.EnterTray();Check ($window.TrayHidden -and !$window.Visible -and !$window.ShowInTaskbar) 'minimize path hides window and taskbar entry'
 }finally{$window.Dispose()}
 Check ($script:network -eq 0) 'all feature checks completed without network or broker orders'
 Write-Output ('AUTO START AND TRAY TESTS COMPLETE: '+$script:checks+' passed; synthetic isolated data only.')
}finally{
 $safe=[IO.Path]::GetFullPath($work);$temp=[IO.Path]::GetFullPath([IO.Path]::GetTempPath()).TrimEnd('\')+'\'
 if(!$safe.StartsWith($temp,[StringComparison]::OrdinalIgnoreCase) -or [IO.Path]::GetFileName($safe) -cnotmatch '^AvataAutoTest-[a-f0-9]{32}$'){throw 'TEST_CLEANUP_PATH'}
 if([IO.Directory]::Exists($safe)){Remove-Item -LiteralPath $safe -Recurse -Force}
}
