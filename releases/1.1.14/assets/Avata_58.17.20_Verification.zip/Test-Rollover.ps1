﻿param([string]$Root=$PSScriptRoot)
$ErrorActionPreference='Stop'
Set-StrictMode -Version 2
. (Join-Path $Root 'bundle/At58.Ops.ps1')
. (Join-Path $Root 'bundle/At58.Sheets.ps1')
. (Join-Path $Root 'bundle/payload/At58.Core.ps1')
. (Join-Path $Root 'host/At58.Update.ps1')
. (Join-Path $Root 'recovery/Repair_Input_After_Transfer.ps1')
$script:passed=0
function Check($condition,[string]$name){if(!$condition){throw ('FAILED: '+$name)};$script:passed++;Write-Output ('PASS '+$name)}
function Reject($action,[string]$code,[string]$name){$actual='';try{& $action|Out-Null}catch{$actual=$_.Exception.Message};Check ($actual -ceq $code) $name}
function Matrix([int]$rows,[int]$cols){$v=New-Object 'Collections.Generic.List[object]';for($i=0;$i -lt $rows;$i++){$r=New-Object object[] $cols;for($j=0;$j -lt $cols;$j++){$r[$j]=''};$v.Add($r)};return ,$v.ToArray()}
$work=Join-Path ([IO.Path]::GetTempPath()) ('AvataRolloverTest-'+[guid]::NewGuid().ToString('N'))
$data=Join-Path $work 'data';$manage=Join-Path $work 'manage'
$null=[IO.Directory]::CreateDirectory($data);$null=[IO.Directory]::CreateDirectory($manage)
try{
 $now=[datetime]::UtcNow;$kst=At58-Kst $now;$today=$kst.ToString('yyyyMMdd');$yesterday=$kst.AddDays(-1).ToString('yyyyMMdd')
 $owner=At58-Context $data '0210A0' ([pscustomobject]@{AppKey='synthetic-app-key';AppSecret='synthetic-secret'})
 $owner.LiveHostProtocol=2
 $params=Matrix 28 5;$params[0][0]='항목'
 foreach($v in @(@(1,.01),@(2,.02),@(3,30),@(4,1),@(5,2),@(6,.25),@(7,.5),@(8,1),@(9,.8),@(10,.001),@(11,3),@(13,.001))){$params[[int]$v[0]][1]=$v[1]}
 foreach($v in @(@(19,1000000),@(20,.2),@(21,.9),@(22,.1),@(23,5),@(24,6000))){$params[[int]$v[0]][4]=$v[1]}
 $settings=Matrix 27 3
 foreach($v in @(@(0,'설정 항목',''),@(1,'종목코드','KRX:0210A0'),@(2,'수익 재투자','미사용'),@(3,'단기 이동평균 기간',5),@(4,'중기 이동평균 기간',20),@(5,'급등·급락 기준 배수',2),@(6,'변동성 계산 기간',20),@(8,'시장 상태',''))){$settings[[int]$v[0]][0]=$v[1];$settings[[int]$v[0]][1]=$v[2]}
 $regimes=@('급등','상승','하락','급락')
 for($i=0;$i -lt 4;$i++){$params[15+$i]=@($regimes[$i],1,1,1,1);$settings[9+$i]=@($regimes[$i],'허용','')}
 $params[27]=@('보합',.5,1,1,.5);$settings[13]=@('보합','허용','')
 $labels=@('보합 계산 기간','보합 추세효율 상한','보합 평균이격 배수','보합 매수구간','보합 매도구간','보합 일일 매수한도','보합 현금 유지비율','보합 비용 안전여유','보합 밴드 배수')
 $values=@(20,.2,.5,.25,.75,2,.3,.01,2)
 for($i=0;$i -lt 9;$i++){$settings[18+$i]=@($labels[$i],$values[$i],'')}
 $cycles=@(@('차수','기준','상태','종목'),@(1,6000,'운영중','0210A0'))
 $ledger=,@('날짜','차수','구분(매수/매도)','체결단가','수량','체결금액','AT 체결키')
 $raw=[pscustomobject]@{Schema='AT-STRATEGY-INPUT-1';Utc=$now.ToString('o');Scope=$owner.Scope;Symbol=$owner.Symbol;Day=$yesterday;Params=$params;Cycles=$cycles;Ledger=$ledger;Settings=(Sheet-ImportSettings $settings)}
 $seed=At58S-Import $raw
 $state=[pscustomobject]@{Schema='AT-LIVE-STATE-1';Scope=$owner.Scope;Symbol=$owner.Symbol;TestOnly=$false;SourceHash=$seed.Hash;Seed=$seed;StartDay=$yesterday}
 At58X-Save $owner $state
 $book=At58T-Load (At58X-Context $owner)
 $snapshot=[pscustomobject]@{Scope=$owner.Scope;Symbol=$owner.Symbol;Day=$yesterday;ExecutionEnabled=$false;StrategyEnabled=$true;Live=[pscustomobject]@{Mode='LIVE_CONTROL';TestOnly=$false;ExecutionEnabled=$false;State='ARMED';OrdersSent=8}}
 $catalog=Sheet-JournalContext $snapshot $data
 Check ($catalog.State.SourceHash -ceq $seed.Hash) 'live ledger verified directly'
 $plainSnapshot=[pscustomobject]@{Scope=$owner.Scope;Symbol=$owner.Symbol;Day=$yesterday}
 $plainCatalog=Sheet-JournalContext $plainSnapshot $data
 Check ($plainCatalog.State.SourceHash -ceq $seed.Hash) 'imported ledger works before first live snapshot'
 $emptyData=Join-Path $work 'empty';$null=[IO.Directory]::CreateDirectory($emptyData)
 Check ($null -eq (Sheet-JournalContext $plainSnapshot $emptyData)) 'paper-only install has no live journal'
 Reject {Sheet-JournalContext $snapshot $emptyData} 'SHEET_JOURNAL_IDENTITY' 'missing live ledger still rejected'
 $bad=At58S-Clone $snapshot;$bad.Live.TestOnly=$true
 Reject {Sheet-JournalContext $bad $data} 'SHEET_JOURNAL_IDENTITY' 'test snapshot cannot become live evidence'
 At58-Atomic (Join-Path $data 'strategy-input.dpapi') (At58-Protect ($raw|ConvertTo-Json -Depth 30 -Compress) 'AT58-STRATEGY-INPUT-1')
 $actual='';try{$null=At58X-Input $owner}catch{$actual=(At58-Error $_).Code}
 Check ($actual -ceq 'LIVE_INPUT_WAIT') 'previous-day input reproduces midnight wait'
 $run=[guid]::NewGuid().ToString()
 $live=[pscustomobject]@{Schema='AT-LIVE-STATUS-1';HostProtocol=2;RunId=$run;Utc=$now.ToString('o');Mode='LIVE_CONTROL';Code='LIVE_INPUT_WAIT';State='ARMED';ExecutionEnabled=$false;OrdersSent=0;OpenOrders=0;UncertainOrders=0;Reconciled=$false;Confirmations=0;TestOnly=$false}
 $status=[pscustomobject]@{HostProtocol=2;RunId=$run;Utc=$now.ToString('o');Code='LIVE_INPUT_WAIT';ExecutionEnabled=$false;OrdersSent=0;Live=$live}
 Ops-WriteJson (Join-Path $data 'status.json') $status
 Ops-WriteJson (Join-Path $manage 'manager-status.json') @{RunId=$run;HostProtocol=2;Utc=$now.ToString('o')}
 $snapshotCipher=At58-Protect ($snapshot|ConvertTo-Json -Depth 30 -Compress)
 At58-Atomic (Join-Path $data 'snapshot.dpapi') $snapshotCipher
 $keyPath=Join-Path $work 'synthetic-key.json'
 $key=@{type='service_account';client_email='synthetic@test.iam.gserviceaccount.com';private_key='-----BEGIN PRIVATE KEY-----synthetic-not-a-real-key'}|ConvertTo-Json -Compress
 [IO.File]::WriteAllText($keyPath,$key,[Text.UTF8Encoding]::new($false))
 Ops-WriteJson (Join-Path $manage 'sheets.json') @{Enabled=$true;SheetId='SYNTHETIC_SPREADSHEET_ONLY';KeyPath=$keyPath}
 $cache=@{Key=(Ops-Key $key);Token='synthetic-cached-token';Until=$now.AddHours(1).ToString('o')}|ConvertTo-Json -Compress
 [IO.File]::WriteAllText((Join-Path $manage 'sheets-token.dpapi'),(At58-Protect $cache 'AT58-SHEET-TOKEN-1'))
 $sheets=New-Object 'Collections.Generic.List[object]'
 foreach($v in @(@('메인',2026110201,28,13),@('자동매매현황',2026110101,30,8),@('AT주문내역',2026110102,1005,12),@('매매기준',2026102807,28,5),@('사이클관리',2026102806,100,5),@('매매일지',1136811970,1000,7),@('운영설정',2026110202,27,3))){$sheets.Add(@{properties=@{title=$v[0];sheetId=$v[1];gridProperties=@{rowCount=$v[2];columnCount=$v[3]}}})}
 $fixture=@{Meta=@{sheets=$sheets.ToArray()};Rows=@{valueRanges=@(@{values=$params},@{values=$cycles},@{values=$ledger})};Settings=@{values=$settings}}
 $fixturePath=Join-Path $work 'fixture.json';Ops-WriteJson $fixturePath $fixture
 $wrapper=Join-Path $Root 'tests/Invoke-RolloverWorker.ps1'
 $exe=Join-Path $env:SystemRoot 'System32/WindowsPowerShell/v1.0/powershell.exe'
 & $exe -NoProfile -NonInteractive -ExecutionPolicy RemoteSigned -File $wrapper -Root $Root -Data $data -Manage $manage -Fixture $fixturePath
 $workerExit=$LASTEXITCODE
 $workerState=Ops-ReadJson (Join-Path $manage 'sheets-status.json')
 Write-Output ('WORKER RESULT: exit='+$workerExit+' status='+($workerState|ConvertTo-Json -Compress))
 Check ($null -ne $workerState) 'worker writes a diagnostic result before exit is evaluated'
 Check ($workerExit -eq 1) 'worker reports presentation mismatch without writing stale report'
 $sheetStatus=Ops-ReadJson (Join-Path $manage 'sheets-status.json')
 Check ($sheetStatus.Code -ceq 'SHEET_LIVE_STATUS') ('expected display error: '+$sheetStatus.Code)
 $input=At58X-Input $owner
 Check ($input.Source.Day -ceq $today) 'actual worker refreshes input despite mismatched old snapshot'
 Check ($input.Source.Hash -ceq $seed.Hash) 'rollover preserves strategy identity'
 Check ([IO.File]::ReadAllText((Join-Path $data 'snapshot.dpapi')) -ceq $snapshotCipher) 'recovery does not forge a new account snapshot'
 Check ((At58X-Load $owner).SourceHash -ceq $seed.Hash) 'live ledger baseline preserved'
 Check (!$owner.ContainsKey('LiveSession')) 'input refresh does not grant order approval'
 $r=Ops-ReadJson (Join-Path $data 'strategy-input-status.json')
 Check ($r.Code -ceq 'OK') 'input freshness is reported separately'
 # The same read-only guard must support the original PC without a transfer report.
 $recoveryRuntime=[pscustomobject]@{RunId=$run;HostProtocol=2;Utc=[datetime]::UtcNow.ToString('o');ExecutionEnabled=$false;LiveCommandPending=$false;LiveState='DISARMED'}
 Ops-WriteJson (Join-Path $manage 'runtime.json') $recoveryRuntime
 $status.Live.State='DISARMED';$status.Utc=[datetime]::UtcNow.ToString('o');$status.Live.Utc=$status.Utc
 Ops-WriteJson (Join-Path $data 'status.json') $status
 Check ((RI-Guard $owner $manage).State.SourceHash -ceq $seed.Hash) 'recovery accepts verified native ledger without transfer report'
 $status.Live.State='ARMED';Ops-WriteJson (Join-Path $data 'status.json') $status
 Reject {RI-Guard $owner $manage} 'RECOVERY_STATE_UNSUITABLE' 'recovery rejects armed state'
 $status.Live.State='DISARMED';Ops-WriteJson (Join-Path $data 'status.json') $status
 $recoveryRuntime.ExecutionEnabled=$true;Ops-WriteJson (Join-Path $manage 'runtime.json') $recoveryRuntime
 Reject {RI-Guard $owner $manage} 'RECOVERY_STATE_UNSUITABLE' 'recovery rejects pending execution intent'
 $recoveryRuntime.ExecutionEnabled=$false;$recoveryRuntime.LiveCommandPending=$true;Ops-WriteJson (Join-Path $manage 'runtime.json') $recoveryRuntime
 Reject {RI-Guard $owner $manage} 'RECOVERY_STATE_UNSUITABLE' 'recovery rejects pending user command'
 $recoveryRuntime.LiveCommandPending=$false;Ops-WriteJson (Join-Path $manage 'runtime.json') $recoveryRuntime
 $status.Live.UncertainOrders=1;Ops-WriteJson (Join-Path $data 'status.json') $status
 Reject {RI-Guard $owner $manage} 'RECOVERY_STATE_UNSUITABLE' 'recovery rejects uncertain orders'
 $status.Live.UncertainOrders=0;$status.Live.State='STOPPING';$recoveryRuntime.LiveState='STOPPING';$recoveryRuntime.ExecutionEnabled=$true
 Ops-WriteJson (Join-Path $data 'status.json') $status;Ops-WriteJson (Join-Path $manage 'runtime.json') $recoveryRuntime
 Check ((RI-Guard $owner $manage).State.SourceHash -ceq $seed.Hash) 'recovery lets explicit stopping state reconcile with execution disabled'
 $recoveryRuntime.LiveState='ARMED';Ops-WriteJson (Join-Path $manage 'runtime.json') $recoveryRuntime
 Reject {RI-Guard $owner $manage} 'RECOVERY_STATE_UNSUITABLE' 'recovery rejects mismatched runtime state'
 $status.Live.State='ARMED'
 # Readiness of automatic updates must retain the real-order guard.
 $manager=[pscustomobject]@{HostSession='test-host';RunId=$run;Utc=[datetime]::UtcNow.ToString('o')}
 $runtime=[pscustomobject]@{RunId=$run;Utc=[datetime]::UtcNow.ToString('o');HostProtocol=2;LiveMode='LIVE';ExecutionEnabled=$true;LiveCommandPending=$false;DesiredRunning=$true;ExitReason=''}
 $status.Live.Utc=[datetime]::UtcNow.ToString('o')
 Check ((Up-Observe (Up-NewProbe) $manager $runtime $status 'test-host' $now.AddMinutes(-1) ([datetime]::UtcNow)) -ceq 'LIVE_HOLD') 'automatic update blocked while armed or unreconciled'
 $runtime.ExecutionEnabled=$false;$status.Live.State='DISARMED';$status.Live.Reconciled=$true;$status.Live.Confirmations=2
 Check ((Up-Observe (Up-NewProbe) $manager $runtime $status 'test-host' $now.AddMinutes(-1) ([datetime]::UtcNow)) -ceq 'READY') 'automatic update allowed after stop and reconciliation'
 $status.Live.UncertainOrders=1
 Check ((Up-Observe (Up-NewProbe) $manager $runtime $status 'test-host' $now.AddMinutes(-1) ([datetime]::UtcNow)) -ceq 'LIVE_HOLD') 'uncertain orders block automatic update'
$status.Live.State='DISARMED';$status.Live.UncertainOrders=0;$status.Live.OpenOrders=0;$status.Live.Reconciled=$true;$status.Live.Confirmations=2;$status.Live.Code='LIVE_ORDER_REJECTED'
Check ((Up-Observe (Up-NewProbe) $manager $runtime $status 'test-host' $now.AddMinutes(-1) ([datetime]::UtcNow)) -ceq 'READY') 'terminal rejected order is reported but does not block update after quiescent reconciliation'
 Write-Output ('ROLLOVER TESTS COMPLETE: '+$script:passed+' passed; synthetic local state only; no real network or orders.')
}finally{
 $safe=[IO.Path]::GetFullPath($work);$temp=[IO.Path]::GetFullPath([IO.Path]::GetTempPath()).TrimEnd('\')+'\'
 if(!$safe.StartsWith($temp,[StringComparison]::OrdinalIgnoreCase) -or [IO.Path]::GetFileName($safe) -cnotmatch '^AvataRolloverTest-[a-f0-9]{32}$'){throw 'TEST_CLEANUP_PATH'}
 if(Test-Path -LiteralPath $work){Remove-Item -LiteralPath $safe -Recurse -Force}
}
