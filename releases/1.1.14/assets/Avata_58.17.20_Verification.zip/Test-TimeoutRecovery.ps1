﻿#requires -Version 5.1
param([string]$Root=$PSScriptRoot)
$ErrorActionPreference='Stop';Set-StrictMode -Version 2
. (Join-Path $Root 'bundle/At58.Ops.ps1')
. (Join-Path $Root 'bundle/At58.Sheets.ps1')
. (Join-Path $Root 'bundle/payload/At58.Core.ps1')
. (Join-Path $Root 'tests/CashFixture.ps1')
$script:checks=0;$script:httpTimeouts=0;$script:orderWire=0;$script:simulatedPosts=0;$script:timeout=$false;$script:duplicate=$false
function Check($ok,[string]$name){if(!$ok){throw ('FAILED: '+$name)};$script:checks++;Write-Output ('PASS '+$name)}
function Reject($action,[string]$code,[string]$name){$found='';try{& $action|Out-Null}catch{$found=(At58-Error $_).Code};Check ($found -ceq $code) ($name+' ['+$found+']')}
# Only synthetic temporary files are used. Native Windows runs use real DPAPI.
$portable=($env:OS -cne 'Windows_NT')
if($portable){
 function At58-Protect([string]$plain,[string]$purpose=''){return [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($purpose+"`n"+$plain))}
 function At58-Unprotect([string]$cipher,[string]$purpose=''){$plain=[Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($cipher));$prefix=$purpose+"`n";if(!$plain.StartsWith($prefix)){throw 'TEST_PURPOSE'};return $plain.Substring($prefix.Length)}
}
function Invoke-RestMethod {$script:httpTimeouts++;throw [Net.WebException]::new('SYNTHETIC_TIMEOUT',[Net.WebExceptionStatus]::Timeout)}
function At58T-Wire {$script:orderWire++;throw 'REAL_ORDER_FORBIDDEN'}
function At58I-Read($owner,$from,$to){return [pscustomobject]@{Schema='AT-CASH-INTEREST-1';Scope=$owner.Scope;From=$from;To=$to;Utc=$script:cashClock.ToString('o');Rows=@()}}
function At58X-Costs {return @()}
function At58-List {return @()}
function At58E-Run {return [pscustomobject]@{Connected=$true;ReceiptAck=$true;FillAck=$true;Pending=0;Gaps=0}}
function At58S-Market {return [pscustomobject]@{Name='하락'}}
function At58-ReadSnapshot($owner){
 # Exercise the real GET transport error mapper and actual live cycle catch.
 if($script:timeout){return (At58-Wire $owner 'GET' '/accounts/v1/me/deposit' @{})}
 $s=At58S-Clone $script:fixture.Snapshot
 $s.CompletedUtc=$(if($script:duplicate){$script:duplicateStamp}else{$script:cashClock.ToString('o')})
 $s.Quote.ReceivedUtc=$s.CompletedUtc;$s.PSObject.Properties.Remove('Execution');$s|Add-Member ExecutionEnabled $false -Force
 return $s
}
function Save-Input($f){$f.Raw.Utc=$script:cashClock.ToString('o');At58-Atomic (Join-Path $f.Owner.Root 'strategy-input.dpapi') (At58-Protect ($f.Raw|ConvertTo-Json -Depth 30 -Compress) 'AT58-STRATEGY-INPUT-1')}
function Poll($f,[int]$advance=5){
 $script:fixture=$f;$script:cashClock=$script:cashClock.AddSeconds($advance);Save-Input $f;$f.Box.UiUtc=$script:cashClock.ToString('o')
 $runtime=[pscustomobject]@{HostProtocol=2;RunId=$f.Owner.RunId;Utc=$script:cashClock.ToString('o');Running=$true;DesiredRunning=$true;Fault='';LiveMode='LIVE';ExecutionEnabled=$false}
 Ops-WriteJson (Join-Path $f.Owner.ManagementRoot 'runtime.json') $runtime;$f.Runtime=$runtime
 $result=At58X-ManagedCycle $f.Owner $f.Box;$f.Last=$result;return $result
}
function Start-Fixture($f){
 $f.Owner.ManagementRoot=Join-Path $f.Owner.Root 'manage';$f.Owner.Transport=$null;$f.Owner.NoWait=$true
 $f.Box=At58X-Mailbox $f.Owner.RunId;$f.Box.Mode='LIVE';$f.Last=$null;$f.Runtime=$null
 $limits=[pscustomobject]@{MaxOrderQty=100;MaxOrderAmount=1000000;DailyBuyAmount=1000000;DailySubmissions=20}
 $session=At58X-NewSession $f.Owner $f.Source.Hash $limits;At58X-Authorize $f.Owner $session $f.Source.Hash
}
$work=Join-Path ([IO.Path]::GetTempPath()) ('AvataTimeoutTest-'+[guid]::NewGuid().ToString('N'))
[void][IO.Directory]::CreateDirectory($work)
try{
 $f=Cash-Fixture (Join-Path $work 'read');Start-Fixture $f
 $null=Poll $f;$ready=Poll $f
 Check ($ready.Ok -and $ready.Status.Live.State -ceq 'ARMED' -and $ready.Status.Live.Reconciled -and $ready.Status.Live.Confirmations -eq 2) 'existing operator approval has two independent account confirmations'
 $watch=[pscustomobject]@{};$run=$f.Owner.RunId;$script:timeout=$true
 for($i=1;$i -le 3;$i++){
  $failed=Poll $f
  Check (!$failed.Ok -and $failed.Status.Code -ceq 'TIMEOUT' -and $failed.Status.Stage -ceq '/accounts/v1/me/deposit' -and $failed.Status.Failures -eq $i) ('GET timeout '+$i+' retains safe endpoint and consecutive failure count')
  Check ($failed.Status.Live.State -ceq 'ARMED' -and !$failed.Status.ExecutionEnabled -and !$failed.Status.Live.Reconciled -and $failed.Status.Live.Confirmations -eq 0 -and $failed.RetrySeconds -eq 5) ('timeout '+$i+' preserves intent but blocks execution and resets reconciliation')
  $saved=At58X-Load $f.Owner
  Check ($saved.Confirmations -eq 0 -and $saved.Proof -ceq '') ('timeout '+$i+' also clears persisted account proof')
  $kind=Ops-Classify $f.Runtime $failed.Status $run $script:cashClock.AddMinutes(-10) $false $script:cashClock
  Check ($kind -ceq $(if($i -lt 3){'RETRYING'}else{'PERSISTENT_ERROR'})) ('manager classifies failed cycle '+$i+' without terminating operator intent')
 }
 Check ((Ops-LiveAlert $watch $failed.Status $run $script:cashClock).Event -ceq 'FAULT') 'live timeout raises a diagnostic fault'
 Check ($script:orderWire -eq 0 -and $script:simulatedPosts -eq 0 -and (At58T-Load (At58X-Context $f.Owner)).Orders.Count -eq 0) 'read failures never submit or create an order'
 $script:timeout=$false;$first=Poll $f
 Check ($first.Ok -and $first.Status.Failures -eq 0 -and $first.Status.Live.State -ceq 'ARMED' -and $first.Status.Live.Confirmations -eq 1 -and !$first.Status.Live.Reconciled) 'first successful fresh account read resets failure count but rebuilds only one confirmation'
 Check ($first.Status.Live.Code -ceq 'LIVE_MARKET_WAIT' -and !$first.Status.ExecutionEnabled -and $f.Owner.RunId -ceq $run) 'same process returns to off-hours wait without submitting or reauthorizing'
 $script:duplicateStamp=$first.Snapshot.CompletedUtc;$script:duplicate=$true;$duplicate=Poll $f
 Check ($duplicate.Status.Live.Code -ceq 'LIVE_DUPLICATE_SNAPSHOT' -and $duplicate.Status.Live.Confirmations -eq 1 -and !$duplicate.Status.Live.Reconciled) 'reusing a successful snapshot does not satisfy the second confirmation'
 $script:duplicate=$false;$second=Poll $f
 Check ($second.Ok -and $second.Status.Live.Confirmations -eq 2 -and $second.Status.Live.Reconciled -and $second.Status.Live.Code -ceq 'LIVE_MARKET_WAIT') 'second distinct successful account read restores verified market wait'
 Check ((Ops-Classify $f.Runtime $second.Status $run $script:cashClock.AddMinutes(-10) $false $script:cashClock) -ceq 'HEALTHY') 'manager classifies the recovered reader as healthy'
 Check ((Ops-LiveAlert $watch $second.Status $run $script:cashClock).Event -ceq 'RECOVERED') 'successful recovery emits a recovery transition'
 Check ($script:httpTimeouts -eq 3 -and $script:orderWire -eq 0 -and $script:simulatedPosts -eq 0) 'all three HTTP failures were local mocks and no order transport was invoked'

 # A separate simulation-only account exercises the real submit journal and
 # controller after an ambiguous POST; it must never reuse the read retry path.
 $script:baseContext=${function:At58-Context}
 function At58-Context([string]$root,[string]$symbol='0210A0',$credential=$null){$ctx=& $script:baseContext $root $symbol $credential;$ctx.LiveTestMode=$true;return $ctx}
 $g=Cash-Fixture (Join-Path $work 'ambiguous');Start-Fixture $g
 $g.Owner.LiveTestTransport={param($packet) $script:simulatedPosts++;throw 'SYNTHETIC_POST_TIMEOUT'}
 $g.Snapshot.Quote.Price=3000D;$null=Poll $g;$null=Poll $g
 $g.Snapshot.Session.Live=$true;$g.Snapshot.Quote.Mode='LIVE_REST'
 $ambiguous=Poll $g;$ctx=At58X-Context $g.Owner;$book=At58T-Load $ctx
 Check ($script:simulatedPosts -eq 1 -and $book.Orders.Count -eq 1 -and $book.Orders[0].State -ceq 'UNKNOWN' -and $book.Orders[0].Issue -ceq 'TRADE_RESPONSE_UNKNOWN') 'an ambiguous synthetic POST is durably recorded as UNKNOWN after exactly one attempt'
 Check ($g.Owner.LiveSession.State -ceq 'REVIEW' -and $g.Owner.LiveSession.StopReason -ceq 'ORDER_UNCERTAIN') 'ambiguous submission revokes automatic trading into review'
 $review=Poll $g
 Check ($review.Status.Live.State -ceq 'REVIEW' -and $review.Status.Live.Code -ceq 'LIVE_ORDER_REVIEW' -and $review.Status.Live.UncertainOrders -eq 1 -and !$review.Status.ExecutionEnabled -and $script:simulatedPosts -eq 1) 'subsequent successful reads never retry an ambiguous POST'
 $intent=$book.Orders[0].Intent;$decision=At58-Hash ($g.Source.Hash+'|'+$intent.GoalId+'|0')
 Reject {At58T-Submit $ctx $g.Last.Snapshot $intent 'NEW' $decision '' $g.Owner.LiveTestTransport} 'TRADE_NO_RESEND' 'the same decision is rejected before any second transport attempt'
 Check ($script:simulatedPosts -eq 1 -and $script:orderWire -eq 0) 'ambiguous-order regression used one simulation callback and zero real order calls'
 Write-Output ('TIMEOUT RECOVERY TESTS COMPLETE: '+$script:checks+' passed; PortableProtection='+$portable+'; no real network or orders.')
}finally{
 $safe=[IO.Path]::GetFullPath($work);$parent=[IO.Path]::GetFullPath([IO.Path]::GetTempPath()).TrimEnd([IO.Path]::DirectorySeparatorChar,[IO.Path]::AltDirectorySeparatorChar)
 if([IO.Path]::GetDirectoryName($safe) -cne $parent -or [IO.Path]::GetFileName($safe) -cnotmatch '^AvataTimeoutTest-[a-f0-9]{32}$'){throw 'TEST_CLEANUP_PATH'}
 if([IO.Directory]::Exists($safe)){Remove-Item -LiteralPath $safe -Recurse -Force}
}
