﻿#requires -Version 5.1
param([string]$Root=$PSScriptRoot)
$ErrorActionPreference='Stop';Set-StrictMode -Version 2
. (Join-Path $Root 'bundle/At58.Ops.ps1')
. (Join-Path $Root 'host/At58.Update.ps1')
. (Join-Path $Root 'bundle/At58.Sheets.ps1')
. (Join-Path $Root 'bundle/payload/At58.Core.ps1')
. (Join-Path $Root 'tests/CashFixture.ps1')
$script:checks=0;$script:network=0;$script:dispatches=0;$script:failSave=$false;$script:inputWrites=0;$script:duplicate='';$script:stale=$false;$script:feedBad=$false;$script:receiptBad=$false;$script:receiptPending=0;$script:receiptGaps=0;$script:readFail=$false
function Check($ok,[string]$name){if(!$ok){throw ('FAILED: '+$name)};$script:checks++;Write-Host ('PASS '+$name)}
if($env:OS -cne 'Windows_NT'){
 function At58-Protect([string]$plain,[string]$purpose=''){return [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($purpose+"`n"+$plain))}
 function At58-Unprotect([string]$cipher,[string]$purpose=''){$plain=[Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($cipher));$prefix=$purpose+"`n";if(!$plain.StartsWith($prefix)){throw 'TEST_PURPOSE'};return $plain.Substring($prefix.Length)}
 # The production websocket class depends on Windows .NET Framework; injected
 # transport never uses it. Receipt file/decode/reconcile logic remains real.
 function At58E-Init {}
}
function Invoke-RestMethod {$script:network++;throw 'TEST_NETWORK_FORBIDDEN'}
function At58T-Wire {$script:network++;throw 'TEST_ORDER_FORBIDDEN'}
function At58X-Dispatch($owner,$state,$snapshot,$intent,[string]$action,[string]$decision,[string]$parent=''){
 # Boundary-only observation; no transport or fabricated successful order.
 $script:dispatches++;$script:lastAction=$action;$script:lastParent=$parent
 if($action -cne 'CANCEL'){throw 'NEW_ORDER_FORBIDDEN'}
}
function At58I-Read($owner,$from,$to){return [pscustomobject]@{Schema='AT-CASH-INTEREST-1';Scope=$owner.Scope;From=$from;To=$to;Utc=$script:cashClock.ToString('o');Rows=@()}}
function At58X-Costs {return @()}
function At58-List {return @()}
$script:receiptRunner=${function:At58E-Run}
function At58E-Run {return [pscustomobject]@{Code=$(if($script:feedBad){'FEED_DISCONNECTED'}else{'LISTENING'});Connected=(!$script:feedBad);ReceiptAck=(!$script:feedBad);FillAck=(!$script:feedBad);ReceiptProofComplete=(!$script:receiptBad);Pending=$script:receiptPending;Gaps=$script:receiptGaps}}
function At58S-Market {return [pscustomobject]@{Name='하락'}}
function At58-ReadSnapshot($owner){
 if($script:readFail){At58-Fail 'TIMEOUT' '/accounts/v1/me/deposit'}
 $script:cashClock=$script:cashClock.AddSeconds(1)
 $s=At58S-Clone $script:fixture.Snapshot
 $s.CompletedUtc=if($script:duplicate){$script:duplicate}elseif($script:stale){$script:cashClock.AddSeconds(-16).ToString('o')}else{$script:cashClock.ToString('o')}
 $s.Quote.ReceivedUtc=$s.CompletedUtc;$s.PSObject.Properties.Remove('Execution');$s|Add-Member ExecutionEnabled $false -Force
 return $s
}
$script:saveStatus=${function:At58-SaveStatus}
function At58-SaveStatus($owner,$status){if($script:failSave){throw [IO.IOException]::new('SYNTHETIC_WORKER_FAILURE')}; & $script:saveStatus $owner $status}
function Save-Input($f){$f.Raw.Utc=$script:cashClock.ToString('o');At58-Atomic (Join-Path $f.Owner.Root 'strategy-input.dpapi') (At58-Protect ($f.Raw|ConvertTo-Json -Depth 30 -Compress) 'AT58-STRATEGY-INPUT-1');$script:inputWrites++}
function Poll($f,[bool]$refresh=$true){
 $script:fixture=$f;$script:cashClock=$script:cashClock.AddSeconds(5);if($refresh){Save-Input $f};$f.Box.UiUtc=$script:cashClock.ToString('o')
 $r=At58X-ManagedCycle $f.Owner $f.Box;$f.Last=$r;return $r
}
function New-Fixture([string]$name){
 $f=Cash-Fixture (Join-Path $work $name);$f.Box=At58X-Mailbox $f.Owner.RunId;$f.Box.Mode='LIVE';$f.Last=$null;$f.Snapshot.Quote.Price=3000D
 $session=At58X-NewSession $f.Owner $f.Source.Hash (At58D-Limits);At58X-Authorize $f.Owner $session $f.Source.Hash
 $null=Poll $f;$null=Poll $f;return $f
}
function Stop-Fixture($f){At58X-Queue $f.Box 'STOP' '' $null $script:cashClock}
function Fail-Worker($f){$script:failSave=$true;try{try{$null=Poll $f;throw 'EXPECTED_FAILURE'}catch{if($_.Exception.Message -cne 'SYNTHETIC_WORKER_FAILURE'){throw}}}finally{$script:failSave=$false}}
function Maintenance($f,$r){
 $rt=[pscustomobject]@{HostProtocol=2;RunId=$f.Owner.RunId;Utc=$script:cashClock.ToString('o');LiveMode='LIVE';LiveCommandPending=($null -ne $f.Box.Command);ExecutionEnabled=($f.Box.State -cin @('ARMED','STOPPING'))}
 return (Ops-LiveMaintenance $rt $r.Status $f.Owner.RunId $script:cashClock)
}
function Host-Decision($f,$r){
 $rt=[pscustomobject]@{HostProtocol=2;RunId=$f.Owner.RunId;Utc=$script:cashClock.ToString('o');LiveMode='LIVE';LiveCommandPending=($null -ne $f.Box.Command);ExecutionEnabled=($f.Box.State -cin @('ARMED','STOPPING'));ExitReason='';DesiredRunning=$true}
 $manager=[pscustomobject]@{HostSession='test-host';RunId=$f.Owner.RunId;Utc=$script:cashClock.ToString('o');State='HEALTHY'}
 return (Up-Observe (Up-NewProbe) $manager $rt $r.Status 'test-host' $script:cashClock.AddHours(-1) $script:cashClock)
}
function Add-Order($f,[string]$state){
 $ctx=At58X-Context $f.Owner;$book=At58T-Load $ctx;$intent=At58S-Clone $f.Last.Snapshot.Live.Plan.Intent
 if(!$intent){throw 'TEST_NO_INTENT'}
 $key=At58-Hash ('test-'+$state+'-'+$f.Owner.Root)
 $node=[pscustomobject]@{Key=$key;RootKey=$key;ParentKey='';ParentId='';Day=$f.Snapshot.Day;Action='NEW';Intent=$intent;BrokerId=$(if($state -ceq 'UNKNOWN'){''}else{'1001'});State=$state;CreatedUtc=$script:cashClock.ToString('o');HistoryUtc='';Filled=0D;Amount=0D;Remaining=$(if($state -ceq 'REJECTED'){0D}else{[decimal]$intent.Qty});Response='0001';Issue='';FeeStatus='UNCONFIRMED'}
 $book.Orders+=,$node;$book.Revision++;At58T-Save $ctx $book
 if($node.BrokerId){$row=[pscustomobject]@{Id=$node.BrokerId;Day=$node.Day;Symbol=$intent.Symbol;Side=$(if($intent.Side -ceq '매수'){'2'}else{'1'});Qty=$intent.Qty;Price=$intent.Price;Filled=0D;Remaining=$node.Remaining;Kind='1';Original='';Status=$(if($state -ceq 'REJECTED'){'3'}else{'2'});Reject=$(if($state -ceq 'REJECTED'){'1234'}else{'0'})};$f.Snapshot.OrdersToday=@($row);$f.Snapshot.OpenOrdersToday=@($f.Snapshot.OrdersToday|Where-Object Remaining -gt 0)}
 return $node
}
$work=Join-Path ([IO.Path]::GetTempPath()) ('AvataUpdateQuiescence-'+[guid]::NewGuid().ToString('N'))
try{
 $f=New-Fixture 'worker-review';Fail-Worker $f
 Check ($f.Box.State -ceq 'REVIEW' -and $f.Owner.LiveSession.State -ceq 'REVIEW' -and $f.Box.CommandError -ceq 'UNEXPECTED') 'actual managed worker failure enters the reported REVIEW state'
 $script:cashClock=$script:cashClock.AddMinutes(3);Stop-Fixture $f
 $inputBefore=[IO.File]::ReadAllText((Join-Path $f.Owner.Root 'strategy-input.dpapi'));$writes=$script:inputWrites
 $first=Poll $f $false
 Check ($first.Ok -and $first.Status.Live.State -ceq 'REVIEW' -and !$first.Status.Live.Reconciled -and $first.Status.Live.Confirmations -eq 1 -and $f.Box.StopRequested) 'first new account proof keeps REVIEW and explicit STOP intent'
 $second=Poll $f $false
 Check ($second.Status.Live.State -ceq 'DISARMED' -and $second.Status.Live.Reconciled -and $second.Status.Live.Confirmations -eq 2 -and !$f.Box.StopRequested -and (Maintenance $f $second) -ceq 'QUIESCENT') 'second new account proof permits quiescent update without an order'
 Check ((Host-Decision $f $second) -ceq 'READY') 'real host observation permits update after verified non-test quiescence'
 Check ($script:inputWrites -eq $writes -and [IO.File]::ReadAllText((Join-Path $f.Owner.Root 'strategy-input.dpapi')) -ceq $inputBefore) 'expired strategy input is never refreshed modified or substituted during stop'
 $script:cashClock=$script:cashClock.AddMinutes(4);$latched=Poll $f $false
 Check ($latched.Status.Live.Code -ceq 'LIVE_STOPPED' -and (Maintenance $f $latched) -ceq 'QUIESCENT' -and $f.Owner.MaintenanceStop.Complete) 'completed maintenance stays latched through later expired-input polls'
 Check ($script:network -eq 0 -and $script:dispatches -eq 0) 'review maintenance performs no outgoing order action'

 $g=New-Fixture 'duplicate';Fail-Worker $g;Stop-Fixture $g;$a=Poll $g
 $script:duplicate=$a.Snapshot.CompletedUtc;$same=Poll $g;$script:duplicate=''
 Check ($same.Status.Live.Confirmations -eq 1 -and !$same.Status.Live.Reconciled -and $same.Status.Live.State -ceq 'REVIEW') 'duplicate completed snapshot cannot satisfy the second proof'
 $script:readFail=$true;$bad=Poll $g;$script:readFail=$false
 Check ($bad.Status.Live.Confirmations -eq 0 -and !$bad.Status.Live.Reconciled -and $g.Owner.MaintenanceStop.Confirmations -eq 0) 'intervening failed read invalidates the entire stop quorum'
 $one=Poll $g;$two=Poll $g
 Check ($one.Status.Live.Confirmations -eq 1 -and $two.Status.Live.Confirmations -eq 2 -and (Maintenance $g $two) -ceq 'QUIESCENT') 'two new reads are required again after failed account access'

 $normalFail=New-Fixture 'normal-first-failure';Stop-Fixture $normalFail;$normalFail.Snapshot.TargetQty=1D;$failedStop=Poll $normalFail
 Check ($normalFail.Box.StopRequested -and !$failedStop.Status.Live.Reconciled -and $normalFail.Owner.MaintenanceStop.Confirmations -eq 0) 'normal STOP failure cannot clear its flag using old completed proofs'
 At58X-Queue $normalFail.Box 'ARM' $normalFail.Source.Hash (At58D-Limits) $script:cashClock;At58X-Commands $normalFail.Owner $normalFail.Box
 Check ($normalFail.Box.CommandError -ceq 'LIVE_STOP_REQUESTED' -and $normalFail.Owner.LiveSession.State -cne 'ARMED') 'ARM cannot bypass incomplete explicit stop after account failure'
 At58X-Queue $normalFail.Box 'PREPARE' '' $null $script:cashClock;At58X-Commands $normalFail.Owner $normalFail.Box
 Check ($normalFail.Box.StopRequested -and $normalFail.Owner.MaintenanceStop -and $normalFail.Box.CommandError -ceq 'LIVE_STOP_ACCOUNT_WAIT') 'PREPARE cannot erase an incomplete maintenance intent'

 foreach($kind in @('STALE','PRESTOP','QUANTITY','SCOPE','RECEIPT','PENDING','GAPS','EXTERNAL','PRIOR','BASELINE','UNKNOWN','SOURCE')){
  $h=New-Fixture ('blocked-'+$kind)
  if($kind -ceq 'UNKNOWN'){$null=Add-Order $h 'UNKNOWN'}
  Fail-Worker $h;Stop-Fixture $h
  switch($kind){
   'STALE' {$script:stale=$true}
   'PRESTOP' {$script:duplicate=$h.Last.Snapshot.CompletedUtc}
   'QUANTITY' {$h.Snapshot.TargetQty=1D}
   'SCOPE' {$h.Snapshot.Scope='wrong-scope'}
   'RECEIPT' {$script:receiptBad=$true}
   'PENDING' {$script:receiptPending=1}
   'GAPS' {$script:receiptGaps=1}
   'EXTERNAL' {$h.Snapshot.OpenOrdersToday=@([pscustomobject]@{Remaining=1})}
   'PRIOR' {$h.Snapshot.PriorOrders=@([pscustomobject]@{Id='9999';Day=$h.Snapshot.PriorDay;Symbol=$h.Owner.Symbol;Side='2';Qty=1D;Price=3000D;Filled=0D;Remaining=1D;Kind='1';Original='';Status='2';Reject='0'})}
   'BASELINE' {[IO.File]::Delete((At58X-Path $h.Owner))}
   'SOURCE' {$state=At58X-Load $h.Owner;$state.SourceHash='a'*64;$state.Seed.Hash=$state.SourceHash;At58X-Save $h.Owner $state}
  }
  $blocked=Poll $h;$script:stale=$false;$script:duplicate='';$script:receiptBad=$false;$script:receiptPending=0;$script:receiptGaps=0
  Check ((Maintenance $h $blocked) -cne 'QUIESCENT' -and !$blocked.Status.Live.Reconciled -and $blocked.Status.Live.Confirmations -eq 0 -and $h.Box.StopRequested) ($kind+' cannot satisfy quiescence or clear STOP')
  if($kind -ceq 'BASELINE'){Check (![IO.File]::Exists((At58X-Path $h.Owner))) 'stop never creates a replacement missing baseline'}
 }

 $offline=New-Fixture 'offline-feed';Fail-Worker $offline;Stop-Fixture $offline;$script:feedBad=$true
 $null=Poll $offline;$offlineReady=Poll $offline;$script:feedBad=$false
 Check ((Maintenance $offline $offlineReady) -ceq 'QUIESCENT') 'closed feed transport does not block complete fresh REST and receipt-book shutdown proof'

 $empty=New-Fixture 'missing-session';$empty.Owner.LiveSession=$null;$empty.Box.SourceHash='';Stop-Fixture $empty
 $null=Poll $empty;$ready=Poll $empty
 Check ((Maintenance $empty $ready) -ceq 'QUIESCENT' -and $empty.Owner.MaintenanceStop.SourceHash -ceq $empty.Source.Hash) 'verified existing baseline supplies identity when session and UI hash are absent'

 $rej=New-Fixture 'terminal-reject';$node=Add-Order $rej 'REJECTED';Fail-Worker $rej;Stop-Fixture $rej
 $before=(At58T-Load (At58X-Context $rej.Owner)).Orders.Count;$null=Poll $rej;$safe=Poll $rej
 Check ((Maintenance $rej $safe) -ceq 'QUIESCENT' -and $safe.Status.Live.RecoveryCode -ceq 'LIVE_RECOVERY_REQUIRED' -and !$safe.Status.Live.RecoveryReady -and $safe.Status.Live.RecoveryCount -eq 1) 'terminal rejection can stop safely but still requires separate recovery consent'
 Check ((At58T-Load (At58X-Context $rej.Owner)).Orders.Count -eq $before -and ![IO.File]::Exists((At58X-RecoveryPath $rej.Owner))) 'maintenance preserves rejected journal and creates no recovery approval'
 Save-Input $rej;At58X-Queue $rej.Box 'ARM' $rej.Source.Hash (At58D-Limits) $script:cashClock;At58X-Commands $rej.Owner $rej.Box
 Check ($rej.Box.CommandError -ceq 'LIVE_RECOVERY_REQUIRED' -and $rej.Owner.LiveSession.State -ceq 'DISARMED') 'ordinary ARM still refuses unacknowledged rejected orders after maintenance'

 $active=New-Fixture 'review-active';$node=Add-Order $active 'OPEN';Fail-Worker $active;Stop-Fixture $active;$active.Snapshot.Session.Live=$true;$active.Snapshot.Quote.Mode='LIVE_REST'
 $held=Poll $active
 Check ($held.Status.Live.State -ceq 'REVIEW' -and $held.Status.Live.OpenOrders -eq 1 -and !$held.Status.Live.Reconciled -and $script:dispatches -eq 0) 'REVIEW with owned outstanding order never dispatches even a cancellation'
 $ordinary=New-Fixture 'normal-cancel';$node=Add-Order $ordinary 'OPEN';Stop-Fixture $ordinary;$ordinary.Snapshot.Session.Live=$true;$ordinary.Snapshot.Quote.Mode='LIVE_REST'
 $cancel=Poll $ordinary
 Check ($script:dispatches -eq 1 -and $script:lastAction -ceq 'CANCEL' -and $script:lastParent -ceq $node.Key -and $cancel.Status.Live.State -ceq 'STOPPING' -and !$cancel.Status.Live.Reconciled) 'normal explicit STOP retains only the known owned cancellation path'
 $ordinary.Snapshot.TargetQty=1D;$mismatch=Poll $ordinary
 Check ($script:dispatches -eq 1 -and !$mismatch.Status.Live.Reconciled) 'account mismatch blocks further maintenance cancellation'

 # Real receipt reconciliation, bounded inbox processing and protected storage.
 # Transport stays injected, so no websocket is opened by these tests.
 $receipt=New-Fixture 'receipt-proof';$receiptRoot=$receipt.Owner.Root
 $emptyProof=& $script:receiptRunner $receipt.Owner $receipt.Snapshot
 Check ($emptyProof.ReceiptProofComplete -and !$emptyProof.Pending -and !$emptyProof.Gaps) 'real receipt runner marks a fully reconciled empty inbox complete'
 $bookPath=Join-Path $receiptRoot 'receipt-book.dpapi';[IO.File]::WriteAllText($bookPath,'invalid-protected-book')
 $badProof=& $script:receiptRunner $receipt.Owner $receipt.Snapshot
 Check (!$badProof.ReceiptProofComplete -and $badProof.Code -ceq 'RECEIPT_BOOK_STORAGE') 'real receipt storage failure cannot advertise default zero counters as proof'
 [IO.File]::Delete($bookPath)
 $inbox=Join-Path $receiptRoot 'receipt-inbox';[void][IO.Directory]::CreateDirectory($inbox)
 $raw=[pscustomobject]@{Schema='AT-RECEIPT-RAW-1';Scope=$receipt.Owner.Scope;ReceivedUtc=$script:cashClock.ToString('o');Message=@{header=@{tr_cd='ohhts_cntg_infr';tr_key='test-user'};body=@{user_id='test-user';acno='12345678';asno='01';oder_date=$receipt.Snapshot.Day;mbcr_oder_time='100000000';oder_no='1001';orgl_oder_no='';deal_cls_code='2';stnd_iscd='KR7005930003';aspr_prc='3000';tlms_aspr_qty='1';rctf_cncl_cls_code='1';aspr_rfus_reas_code='';svc_id='TEST';pros_srno='1'}}}
 $cipher=At58-Protect ($raw|ConvertTo-Json -Depth 8 -Compress) 'AT58-RECEIPT-RAW-1'
 foreach($n in 1..201){[IO.File]::WriteAllText((Join-Path $inbox ($n.ToString('D4')+'.dpapi')),$cipher)}
 $partial=& $script:receiptRunner $receipt.Owner $receipt.Snapshot
 Check (!$partial.ReceiptProofComplete -and @([IO.Directory]::EnumerateFiles($inbox,'*.dpapi')).Count -eq 1) 'a real 201-item receipt backlog cannot claim complete proof after its first 200-item batch'
 $drained=& $script:receiptRunner $receipt.Owner $receipt.Snapshot
 Check ($drained.ReceiptProofComplete -and $drained.Pending -eq 1 -and @([IO.Directory]::EnumerateFiles($inbox,'*.dpapi')).Count -eq 0) 'drained receipt inbox still exposes unresolved receipt evidence separately'

 $tok=$null;$err=$null;$ast=[Management.Automation.Language.Parser]::ParseFile((Join-Path $Root 'bundle/payload/At58.Core.ps1'),[ref]$tok,[ref]$err)
 Check (!$err.Count) 'production core parses with maintenance branch'
 $stop=@($ast.FindAll({param($x) $x -is [Management.Automation.Language.FunctionDefinitionAst] -and $x.Name -ceq 'At58X-StopStep'},$true))[0]
 Check ($stop.Extent.Text -notmatch 'At58R-LimitGoals|At58L-Candidate|At58X-Authorize|ARM_AUTO|ARM_TELEGRAM') 'maintenance has no planning goal-cap mutation or activation path'
 Check ($script:network -eq 0) 'all test broker access was synthetic and no real order transport was called'
 'UPDATE QUIESCENCE TESTS COMPLETE: '+$script:checks+' passed; synthetic local account snapshots and isolated files only.'
}finally{
 $safe=[IO.Path]::GetFullPath($work);$parent=[IO.Path]::GetFullPath([IO.Path]::GetTempPath()).TrimEnd([IO.Path]::DirectorySeparatorChar,[IO.Path]::AltDirectorySeparatorChar)
 if([IO.Path]::GetDirectoryName($safe) -cne $parent -or [IO.Path]::GetFileName($safe) -cnotmatch '^AvataUpdateQuiescence-[a-f0-9]{32}$'){throw 'TEST_CLEANUP_PATH'}
 if([IO.Directory]::Exists($safe)){Remove-Item -LiteralPath $safe -Recurse -Force}
}
