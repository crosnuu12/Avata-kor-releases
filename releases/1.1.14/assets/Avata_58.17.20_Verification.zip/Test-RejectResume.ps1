﻿#requires -Version 5.1
param([string]$Root=$PSScriptRoot)
$ErrorActionPreference='Stop';Set-StrictMode -Version 2
. (Join-Path $Root 'bundle/At58.Ops.ps1')
. (Join-Path $Root 'bundle/At58.Sheets.ps1')
. (Join-Path $Root 'bundle/payload/At58.Core.ps1')
. (Join-Path $Root 'tests/CashFixture.ps1')
$script:checks=0;$script:network=0;$script:posts=0;$script:cancels=0;$script:lastCancel=$null;$script:fixtures=@{}
function Check($ok,[string]$name){if(!$ok){throw ('FAILED: '+$name)};$script:checks++;Write-Output ('PASS '+$name)}
function Reject($body,[string]$code,[string]$name){$found='';try{& $body|Out-Null}catch{$found=(At58-Error $_).Code};Check ($found -ceq $code) ($name+' ['+$found+']')}
function Invoke-RestMethod {$script:network++;throw 'NETWORK_FORBIDDEN'}
function At58T-Wire {$script:network++;throw 'ORDER_FORBIDDEN'}
# Linux validation substitutes only protection of synthetic test files. Windows
# executes the same fixture with real CurrentUser DPAPI. No installed data is read.
$portable=($env:OS -cne 'Windows_NT')
if($portable){
 function At58-Protect([string]$plain,[string]$purpose=''){return [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($purpose+"`n"+$plain))}
 function At58-Unprotect([string]$cipher,[string]$purpose=''){$plain=[Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($cipher));$prefix=$purpose+"`n";if(!$plain.StartsWith($prefix)){throw 'TEST_PURPOSE'};return $plain.Substring($prefix.Length)}
}
$script:baseContext=${function:At58-Context}
function At58-Context([string]$root,[string]$symbol='0210A0',$credential=$null){$ctx=& $script:baseContext $root $symbol $credential;$ctx.LiveTestMode=$true;return $ctx}
$work=Join-Path ([IO.Path]::GetTempPath()) ('AvataRejectTest-'+[guid]::NewGuid().ToString('N'))
[void][IO.Directory]::CreateDirectory($work)
function Save-Input($f){$f.Raw.Day=$f.Snapshot.Day;$f.Raw.Utc=$script:cashClock.ToString('o');At58-Atomic (Join-Path $f.Owner.Root 'strategy-input.dpapi') (At58-Protect ($f.Raw|ConvertTo-Json -Depth 30 -Compress) 'AT58-STRATEGY-INPUT-1')}
function Test-History($node){return [pscustomobject]@{Id=$node.BrokerId;Day=$node.Day;Symbol=$node.Intent.Symbol;Side=$(if($node.Intent.Side -ceq '매수'){'2'}else{'1'});Qty=$node.Intent.Qty;Price=$node.Intent.Price;Filled=$node.Filled;Remaining=$node.Remaining;Kind=$(if($node.Action -ceq 'CANCEL'){'3'}else{'1'});Original=$node.ParentId;Status=$(if($node.State -ceq 'REJECTED'){'3'}else{'2'});Reject=$(if($node.State -ceq 'REJECTED'){'1234'}else{'0'})}}
function Add-Node($f,$intent,[string]$state='REJECTED'){
 $ctx=At58X-Context $f.Owner;$book=At58T-Load $ctx;$key=At58-Hash ('synthetic-'+$f.Owner.Root+'|'+$book.Orders.Count)
 $node=[pscustomobject]@{Key=$key;RootKey=$key;ParentKey='';ParentId='';Day=$f.Snapshot.Day;Action='NEW';Intent=(At58S-Clone $intent);BrokerId=([string](1000+$book.Orders.Count));State=$state;CreatedUtc=$script:cashClock.ToString('o');HistoryUtc='';Filled=0D;Amount=0D;Remaining=$(if($state -ceq 'REJECTED'){0D}else{[decimal]$intent.Qty});Response='0001';Issue='';FeeStatus='UNCONFIRMED'}
 $book.Orders+=,$node;$book.Revision++;At58T-Save $ctx $book;$f.Rows+=,(Test-History $node);return $node
}
function New-Fixture([string]$name){
 $f=Cash-Fixture (Join-Path $work $name);$f.Rows=@();$f.Last=$null;$f.Owner.ManagementRoot=Join-Path $f.Owner.Root 'manage'
 $script:cashClock=([datetimeoffset]'2026-11-06T14:00:00Z').UtcDateTime
 $f.Snapshot.Day='20261106';$f.Snapshot.Quote.BasisDay='20261106';$f.Snapshot.Quote.Price=3000D;$f.Snapshot.Session.Close=[datetime]'2026-11-06T15:30:00'
 $f.Snapshot|Add-Member HistoryDays @('20261106') -Force
 $view=At58S-Clone $f.Book;$view.Mode='LIVE_TEST';$p=At58X-Replay $f.Source $view $f.Snapshot.Day
 $intent=(At58L-Candidate $f.Source $p $f.Snapshot '하락' $f.Book).Intent
 if(!$intent){throw 'TEST_NO_INTENT'}
 $f.Rejected=Add-Node $f $intent;$script:fixtures[$f.Owner.Root]=$f
 Save-Input $f;return $f
}
function Poll($f,[int]$advance=2){
 $script:cashClock=$script:cashClock.AddSeconds($advance);$s=$f.Snapshot;$s.CompletedUtc=$script:cashClock.ToString('o');$s.Quote.ReceivedUtc=$s.CompletedUtc
 $s.OrdersToday=@($f.Rows|Where-Object Day -ceq $s.Day);$s.PriorOrders=@($f.Rows|Where-Object Day -cne $s.Day)
 $s.HistoryDays=@($s.Day)+@($f.Rows|Select-Object -ExpandProperty Day -Unique)
 if(At58-Value $f.Owner 'LiveMailbox'){$f.Owner.LiveMailbox.UiUtc=$s.CompletedUtc}
 $f.Last=At58X-Step $f.Owner $f.Source $s @() $null '하락' '허용';return $f.Last
}
function Start-Manual($f,[string]$action='ARM'){
 Save-Input $f;$box=At58X-Mailbox $f.Owner.RunId;$box.Mode='LIVE';$box.SourceHash=$f.Source.Hash;$box.Last=$f.Last;$box.LastUtc=$script:cashClock.ToString('o');$box.UiUtc=$script:cashClock.ToString('o')
 At58X-Queue $box $action $f.Source.Hash (At58D-Limits) $script:cashClock
 At58X-Commands $f.Owner $box;$f.Box=$box;return $box
}
function Request-Recovery($f,[string]$consent='MANUAL_ACCOUNT_AND_SHEET_CHECKED'){
 $lastStamp=At58S-Utc $f.Snapshot.CompletedUtc;if($script:cashClock -lt $lastStamp){$script:cashClock=$lastStamp}
 Save-Input $f;$box=At58X-Mailbox $f.Owner.RunId;$box.Mode='LIVE';$box.SourceHash=$f.Source.Hash;$box.Last=$f.Last;$box.LastUtc=$script:cashClock.ToString('o');$box.UiUtc=$script:cashClock.ToString('o')
 At58X-Queue $box 'RECOVER' $f.Source.Hash $null $script:cashClock $consent
 At58X-Commands $f.Owner $box;$f.Box=$box;return $box
}
function Write-JournalReceipt($f,$changes=@{},[string[]]$remove=@()){
 $book=At58T-Load (At58X-Context $f.Owner)
 $receipt=@{Code='OK';Pending=0;Scope=$f.Owner.Scope;Symbol=$f.Owner.Symbol;SourceHash=$f.Source.Hash;FillProof=(At58X-FillProof $book);FillCount=@($book.Fills).Count;Utc=$script:cashClock.ToString('o')}
 foreach($key in $changes.Keys){$receipt[$key]=$changes[$key]}
 foreach($key in $remove){$receipt.Remove($key)}
 Ops-WriteJson (Join-Path $f.Owner.ManagementRoot 'journal-status.json') $receipt
}
function Recover-Fixture($f){
 $b=Request-Recovery $f;if($b.CommandError){throw ('TEST_RECOVERY_COMMAND: '+$b.CommandError)}
 Write-JournalReceipt $f;$null=Poll $f;$r=Poll $f
 if(!$r.RecoveryReady -or $r.RecoveryPending -or $r.State -cne 'DISARMED'){throw ('TEST_RECOVERY_RESULT: '+$r.RecoveryCode)}
 return $r
}
# The state machine chooses whether to dispatch. The test boundary records that
# choice as an acknowledged synthetic order; no broker or financial action exists.
function At58X-Dispatch($owner,$state,$snapshot,$intent,[string]$action,[string]$decision,[string]$parent=''){
 At58X-ManagedGate $owner $action
 $f=$script:fixtures[$owner.Root]
 if($action -ceq 'NEW'){$script:posts++;return (Add-Node $f $intent 'ACKNOWLEDGED')}
 if($action -cne 'CANCEL'){throw 'UNEXPECTED_TEST_ACTION'}
 $ctx=At58X-Context $owner;$book=At58T-Load $ctx;$parents=@($book.Orders|Where-Object Key -ceq $parent)
 if($parents.Count -ne 1 -or $parents[0].State -cne 'OPEN' -or $intent.Qty -ne $parents[0].Remaining){throw 'TEST_CANCEL_PARENT'}
 $original=$parents[0];$key=At58-Hash ('synthetic-cancel-'+$owner.Root+'|'+$book.Orders.Count)
 $node=[pscustomobject]@{Key=$key;RootKey=$original.RootKey;ParentKey=$original.Key;ParentId=$original.BrokerId;Day=$snapshot.Day;Action='CANCEL';Intent=(At58S-Clone $intent);BrokerId=([string](1000+$book.Orders.Count));State='ACKNOWLEDGED';CreatedUtc=$script:cashClock.ToString('o');HistoryUtc='';Filled=0D;Amount=0D;Remaining=0D;Response='0001';Issue='';FeeStatus='UNCONFIRMED'}
 $book.Orders+=,$node;$book.Revision++;At58T-Save $ctx $book
 # The subsequent real reconciliation must verify BOTH parent and cancellation
 # rows before clearing STOPPING. This boundary supplies only synthetic evidence.
 foreach($row in $f.Rows){if($row.Day -ceq $original.Day -and $row.Id -ceq $original.BrokerId){$row.Remaining=0D}}
 $f.Rows+=,(Test-History $node);$script:cancels++;$script:lastCancel=$node;return $node
}
try{
 $f=New-Fixture 'manual';$null=Poll $f;$before=Poll $f
 Check ($before.Reconciled -and $before.Code -ceq 'LIVE_ORDER_REJECTED' -and $before.State -ceq 'DISARMED') 'confirmed rejection is visible before any new operator start'
 $ctx=At58X-Context $f.Owner;$beforeOrders=(At58T-Load $ctx).Orders|ConvertTo-Json -Depth 20 -Compress
 $denied=Start-Manual $f
 Check ($denied.CommandError -ceq 'LIVE_RECOVERY_REQUIRED' -and $script:posts -eq 0) 'manual start cannot implicitly acknowledge rejected history before recovery'
 $box=Request-Recovery $f
 Check (!$box.CommandError -and $script:posts -eq 0) 'explicit confirmed recovery command queues account and sheet verification without trading'
 Write-JournalReceipt $f;$recoverFirst=Poll $f
 Check ($recoverFirst.RecoveryPending -and !$recoverFirst.RecoveryReady -and $recoverFirst.State -ceq 'DISARMED' -and $recoverFirst.Confirmations -eq 1 -and $script:posts -eq 0) 'recovery stays disarmed after the first new account proof'
 $recovered=Poll $f
 Check ($recovered.RecoveryReady -and !$recovered.RecoveryPending -and $recovered.RecoveryCode -ceq 'LIVE_RECOVERY_READY' -and $recovered.State -ceq 'DISARMED' -and $script:posts -eq 0) 'verified account and matching sheet receipt complete recovery without starting'
 $box=Start-Manual $f
 Check (!$box.CommandError -and $f.Owner.LiveSession.State -ceq 'ARMED') 'separate manual ARM consumes the saved recovery proof in the same process'
 $first=Poll $f
 Check ($first.State -ceq 'ARMED' -and $first.Code -ceq 'LIVE_MARKET_WAIT' -and $first.Confirmations -eq 1 -and !$first.Reconciled -and $script:posts -eq 0) 'manual restart waits off-hours and requires first fresh account proof'
 $second=Poll $f
 Check ($second.State -ceq 'ARMED' -and $second.Code -ceq 'LIVE_MARKET_WAIT' -and $second.Reconciled -and $second.Plan.Intent -and $script:posts -eq 0) 'second fresh off-hours read keeps approval and restores candidate calculation without sending'
 Check ((@($f.Owner.LiveSession.AcknowledgedRejections).Count -eq 1) -and ((At58T-Load $ctx).Orders|ConvertTo-Json -Depth 20 -Compress) -ceq $beforeOrders) 'session uses approved proofs and leaves rejected order history intact'
 $script:cashClock=([datetimeoffset]'2026-11-08T14:59:50Z').UtcDateTime;$f.Snapshot.Day='20261108';$f.Snapshot.PriorDay='20261106';$f.Snapshot.Session.Close=[datetime]'2026-11-08T15:30:00'
 $sunday=Poll $f
 Check ($sunday.State -ceq 'ARMED' -and $sunday.Code -ceq 'LIVE_MARKET_WAIT' -and $sunday.Confirmations -eq 1 -and $script:posts -eq 0) 'Sunday date rollover preserves approval but rebuilds account evidence'
 $script:cashClock=([datetimeoffset]'2026-11-09T00:00:00Z').UtcDateTime;$f.Snapshot.Day='20261109';$f.Snapshot.Session.Live=$true;$f.Snapshot.Session.Close=[datetime]'2026-11-09T15:30:00';$f.Snapshot.Quote.Mode='LIVE_REST'
 $monday1=Poll $f
 Check ($monday1.State -ceq 'ARMED' -and $monday1.Confirmations -eq 1 -and $script:posts -eq 0) 'Monday opening cannot submit on the first new-day account proof'
 $monday2=Poll $f
 Check ($monday2.Code -ceq 'LIVE_ORDER_SENT' -and $script:posts -eq 1 -and $monday2.Orders.Count -eq 2) 'Monday second fresh proof permits one new synthetic intent'
 Check ($monday2.Orders[1].Key -cne $f.Rejected.Key -and $monday2.Orders[1].Intent.GoalId -cne $f.Rejected.Intent.GoalId) 'new decision retains the old rejected record and uses distinct order and goal identities'
 $after=Poll $f
 Check ($script:posts -eq 1 -and $after.Orders.Count -eq 2 -and $after.State -ceq 'ARMED') 'acknowledged order blocks duplicate submission on the next poll'
 Check ($after.Orders[1].State -ceq 'OPEN') 'the accepted new order is independently reconciled as open'
 At58X-Queue $f.Box 'STOP' '' $null $script:cashClock;At58X-Commands $f.Owner $f.Box;$cancel=Poll $f
 Check ($cancel.State -ceq 'STOPPING' -and $cancel.Code -ceq 'LIVE_CANCEL_SENT' -and $script:cancels -eq 1 -and $script:posts -eq 1 -and $script:lastCancel.ParentKey -ceq $after.Orders[1].Key -and $script:lastCancel.Intent.Qty -eq $after.Orders[1].Remaining) 'STOP dispatches one cancellation for the open order despite acknowledged historical rejection'
 $cancelled=Poll $f
 Check ($cancelled.State -ceq 'DISARMED' -and $cancelled.Code -ceq 'LIVE_STOPPED' -and $cancelled.Orders[1].State -ceq 'CANCELLED' -and $cancelled.Orders[2].State -ceq 'CANCELLED') 'fresh parent and child history confirms cancellation before stop completes'
 $idle=Poll $f
 Check ($idle.State -ceq 'DISARMED' -and $script:cancels -eq 1 -and $script:posts -eq 1) 'completed stop cannot repeat cancellation or submit another new order'

 $g=New-Fixture 'new-rejection';$null=Poll $g;$null=Poll $g;$null=Recover-Fixture $g;$null=Start-Manual $g;$null=Poll $g;$ready=Poll $g
 $new=Add-Node $g $ready.Plan.Intent;$blocked=Poll $g
 Check ($blocked.State -ceq 'DISARMED' -and $blocked.Code -ceq 'LIVE_ORDER_REJECTED' -and !$blocked.Plan.Intent -and $script:posts -eq 1) 'new rejection is not covered by an earlier acknowledgment and stops execution'
 $still=Poll $g
 Check ($still.State -ceq 'DISARMED' -and $script:posts -eq 1) 'new rejection does not silently reauthorize or repeatedly retry'

 $h=New-Fixture 'stop';$null=Poll $h;$null=Poll $h;$null=Recover-Fixture $h;$null=Start-Manual $h;$null=Poll $h;$null=Poll $h
 At58X-Queue $h.Box 'STOP' '' $null $script:cashClock;At58X-Commands $h.Owner $h.Box;$stopped=Poll $h
 Check ($stopped.State -ceq 'DISARMED' -and $stopped.Code -ceq 'LIVE_STOPPED' -and $script:posts -eq 1) 'operator STOP still clears a resumed waiting session'

 foreach($action in @('ARM_AUTO','ARM_TELEGRAM')){
  $a=New-Fixture $action;$null=Poll $a;$null=Poll $a
  # Origin routing is tested after a successful consent guard. Guards themselves
  # have independent existing test suites; no external Telegram call is made.
  function At58AS-Guard {}
  function At58TG-Guard {}
  $b=Start-Manual $a $action;$r=Poll $a
  Check ($b.CommandError -ceq 'LIVE_RECOVERY_MANUAL_START' -and $r.State -ceq 'DISARMED' -and $r.Code -ceq 'LIVE_ORDER_REJECTED') ($action+' cannot acknowledge rejected history through manual-only consent')
 }
 foreach($badState in @('UNKNOWN','SUBMITTING','WARNING_REVIEW','REVIEW')){
  $u=New-Fixture ('unsafe-'+$badState);$book=At58T-Load (At58X-Context $u.Owner);$book.Orders[0].State=$badState;At58T-Save (At58X-Context $u.Owner) $book
  $session=At58X-NewSession $u.Owner $u.Source.Hash (At58D-Limits)
  Reject {At58X-Authorize $u.Owner $session $u.Source.Hash $true} 'LIVE_ORDER_REVIEW' ($badState+' remains blocked by the actual authorization gate')
 }
 $p=New-Fixture 'proof';$null=Poll $p;$null=Poll $p;$null=Recover-Fixture $p;$null=Start-Manual $p
 $book=At58T-Load (At58X-Context $p.Owner);$view=At58S-Clone $book;$view.Mode='LIVE_TEST';$portfolio=At58X-Replay $p.Source $view $p.Snapshot.Day
 foreach($case in @('partial','missing-id','remaining','issue','changed-intent','review')){
  $v=At58S-Clone $portfolio;$session=At58S-Clone $p.Owner.LiveSession
  switch($case){
   'partial'{$v.Goals[0].Filled=1D;$v.Goals[0].Amount=6000D}
   'missing-id'{$v.Goals[0].Nodes[0].BrokerId=''}
   'remaining'{$v.Goals[0].Nodes[0].Remaining=1D}
   'issue'{$v.Goals[0].Nodes[0].Issue='TRADE_REJECT_WITH_FILL'}
   'changed-intent'{$v.Goals[0].Nodes[0].Intent.Price+=5D}
   'review'{$session.State='REVIEW'}
  }
  $terminal=At58X-HandleTerminalReject $v $session
  Check ($terminal -and $v.Code -ceq 'SIM_ORDER_REJECTED' -and $session.State -ceq $(if($case -ceq 'review'){'REVIEW'}else{'DISARMED'})) ($case+' cannot reuse a prior rejection acknowledgment')
 }
 # A second confirmed reject is recoverable by the same command; no code release
 # or ledger rewrite is needed after the operator repeats the real-world checks.
 $again=Recover-Fixture $g
 Check ($again.RecoveryReady -and $again.State -ceq 'DISARMED' -and $again.RecoveryCount -ge 2) 'a later rejection is independently recoverable with the same installed recovery flow'
 $againStart=Start-Manual $g;$againWait=Poll $g
 Check (!$againStart.CommandError -and $againWait.State -ceq 'ARMED' -and $againWait.Code -ceq 'LIVE_MARKET_WAIT') 'repeat recovery still requires and accepts a separate manual start'

 $persist=New-Fixture 'restart-persistence';$null=Poll $persist;$null=Poll $persist;$done=Recover-Fixture $persist
 $recoveryPath=Join-Path (At58X-Context $persist.Owner).Root 'reject-recovery.dpapi'
 Check ([IO.File]::Exists($recoveryPath)) 'completed recovery has an encrypted durable record'
 $cipher=[IO.File]::ReadAllText($recoveryPath)
 Check (!$cipher.Contains('"Proofs"') -and !$cipher.Contains($persist.Rejected.BrokerId+'"')) 'durable approval is not stored as plaintext order history'
 $persist.Owner.RunId=[guid]::NewGuid().ToString();$persist.Owner.LiveSession=$null
 foreach($key in @($persist.Owner.Keys|Where-Object {$_ -like '*Recovery*' -or $_ -ceq 'LiveMailbox'})){$persist.Owner.Remove($key)}
 $null=Poll $persist;$reloaded=Poll $persist
 Check ($reloaded.RecoveryReady -and $reloaded.State -ceq 'DISARMED' -and !$reloaded.ExecutionEnabled) 'fresh process restores completed recovery while leaving trading off'
 $restart=Start-Manual $persist;$restartWait=Poll $persist
 Check (!$restart.CommandError -and $restartWait.State -ceq 'ARMED' -and $restartWait.Code -ceq 'LIVE_MARKET_WAIT') 'manual start after process restart reuses only the saved verified rejection set'

 $missing=New-Fixture 'receipt-missing';$null=Poll $missing;$null=Poll $missing;$null=Request-Recovery $missing;$null=Poll $missing;$waiting=Poll $missing
 Check ($waiting.RecoveryPending -and !$waiting.RecoveryReady -and $waiting.RecoveryCode -ceq 'LIVE_RECOVERY_SHEET_WAIT' -and $waiting.State -ceq 'DISARMED') 'account quorum alone cannot recover without a sheet verification receipt'
 $null=Write-JournalReceipt $missing;$fixed=Poll $missing
 Check ($fixed.RecoveryReady -and $fixed.State -ceq 'DISARMED') 'a matching current sheet verification completes an already waiting request'

 $badReceipts=@(
  @{Name='wrong-scope';Changes=@{Scope='different-account'}},
  @{Name='wrong-symbol';Changes=@{Symbol='000000'}},
  @{Name='wrong-source';Changes=@{SourceHash=('e'*64)}},
  @{Name='wrong-fill-proof';Changes=@{FillProof=('f'*64)}},
  @{Name='missing-fill-proof';Changes=@{};Remove=@('FillProof')},
  @{Name='missing-fill-count';Changes=@{};Remove=@('FillCount')},
  @{Name='null-fill-count';Changes=@{FillCount=$null}},
  @{Name='string-fill-count';Changes=@{FillCount='0'}},
  @{Name='missing-pending';Changes=@{};Remove=@('Pending')},
  @{Name='null-pending';Changes=@{Pending=$null}},
  @{Name='string-pending';Changes=@{Pending='0'}},
  @{Name='pending-writes';Changes=@{Pending=1}},
  @{Name='failed-write';Changes=@{Code='SHEET_JOURNAL_VERIFY'}},
  @{Name='stale-receipt';Changes=@{Utc='2026-11-06T13:59:59Z'}},
  @{Name='future-receipt';Changes=@{Utc='2026-11-06T14:10:00Z'}}
 )
 foreach($case in $badReceipts){
  $bad=New-Fixture ('receipt-'+$case.Name);$null=Poll $bad;$null=Poll $bad;$null=Request-Recovery $bad
  $remove=if($case.ContainsKey('Remove')){$case['Remove']}else{@()}
  Write-JournalReceipt $bad $case.Changes $remove;$null=Poll $bad;$r=Poll $bad
  Check ($r.RecoveryPending -and !$r.RecoveryReady -and $r.RecoveryCode -ceq 'LIVE_RECOVERY_SHEET_WAIT' -and $r.State -ceq 'DISARMED') ($case.Name+' cannot certify existing fills or bypass recovery')
 }

 $consent=New-Fixture 'missing-consent';$null=Poll $consent;$null=Poll $consent;$noConsent=Request-Recovery $consent ''
 Check ($noConsent.CommandError -and !(At58-Value $consent.Owner 'RecoveryRequest') -and ![IO.File]::Exists((Join-Path (At58X-Context $consent.Owner).Root 'reject-recovery.dpapi'))) 'recovery without explicit account and sheet confirmation is rejected'
 $expired=New-Fixture 'expired-command';$null=Poll $expired;$null=Poll $expired
 Save-Input $expired;$old=At58X-Mailbox $expired.Owner.RunId;$old.Mode='LIVE';$old.SourceHash=$expired.Source.Hash;$old.Last=$expired.Last;$old.UiUtc=$script:cashClock.ToString('o')
 At58X-Queue $old 'RECOVER' $expired.Source.Hash $null ($script:cashClock.AddSeconds(-61)) 'MANUAL_ACCOUNT_AND_SHEET_CHECKED';At58X-Commands $expired.Owner $old
 Check ($old.CommandError -ceq 'LIVE_COMMAND_EXPIRED' -and !(At58-Value $expired.Owner 'RecoveryRequest')) 'an expired recovery command cannot reuse a prior operator confirmation'

 $changed=New-Fixture 'request-proof-changed';$null=Poll $changed;$null=Poll $changed;$null=Request-Recovery $changed;Write-JournalReceipt $changed
 $next=At58S-Clone $changed.Rejected.Intent;$next.GoalId=At58-Hash 'rejection-after-user-reviewed';$null=Add-Node $changed $next
 $null=Poll $changed;$changedResult=Poll $changed
 Check (!$changedResult.RecoveryPending -and !$changedResult.RecoveryReady -and $changedResult.RecoveryCode -ceq 'LIVE_RECOVERY_CHANGED' -and $changedResult.State -ceq 'DISARMED') 'a rejection arriving after user confirmation invalidates that recovery request'

 $stopRecovery=New-Fixture 'stop-recovery';$null=Poll $stopRecovery;$null=Poll $stopRecovery;$null=Request-Recovery $stopRecovery;Write-JournalReceipt $stopRecovery
 At58X-Queue $stopRecovery.Box 'STOP' '' $null $script:cashClock;At58X-Commands $stopRecovery.Owner $stopRecovery.Box;$stoppedRecovery=Poll $stopRecovery
 Check (!$stoppedRecovery.RecoveryPending -and !$stoppedRecovery.RecoveryReady -and $stoppedRecovery.State -ceq 'DISARMED' -and ![IO.File]::Exists((Join-Path (At58X-Context $stopRecovery.Owner).Root 'reject-recovery.dpapi'))) 'STOP cancels pending recovery instead of saving approval'

 foreach($list in @('OpenOrdersToday','PriorUnresolved')){
  $open=New-Fixture ('external-'+$list);$null=Poll $open;$null=Poll $open;$null=Request-Recovery $open;Write-JournalReceipt $open
  # A different-symbol account order is still outstanding and must block recovery.
  $open.Snapshot.$list=@([pscustomobject]@{Symbol='000000';Remaining=1})
  $null=Poll $open;$blockedOpen=Poll $open
  Check (!$blockedOpen.RecoveryReady -and !$blockedOpen.RecoveryPending -and $blockedOpen.State -ceq 'DISARMED') ($list+' on any symbol prevents recovery')
 }

 $finger=New-Fixture 'fill-proof';$book=At58T-Load (At58X-Context $finger.Owner);$emptyProof=At58X-FillProof $book
 $copy=At58S-Clone $book;$copy.Revision+=99
 Check ((At58X-FillProof $copy) -ceq $emptyProof) 'sheet fill proof ignores reconciliation-only revision increments'
 $copy.Fills=@([pscustomobject]@{Key=('a'*64);OrderKey=$finger.Rejected.Key;Account=$book.Account;Day='20261106';Time='100000';Qty=1D;Price=3000D;Amount=3000D;Evidence='BROKER_NOTIFICATION_RECONCILED'})
 Check ((At58X-FillProof $copy) -cne $emptyProof) 'a newly recorded broker fill changes the required sheet proof'
 $cache=New-Fixture 'cached-evidence';$null=Poll $cache;$null=Poll $cache;$null=Request-Recovery $cache;Write-JournalReceipt $cache
 $null=Poll $cache 0;$cached=Poll $cache 0
 Check ($cached.RecoveryPending -and !$cached.RecoveryReady -and $cached.State -ceq 'DISARMED') 'replaying pre-request cached snapshots cannot satisfy recovery account quorum'
 $null=Poll $cache;$duplicate=Poll $cache 0
 Check ($duplicate.RecoveryPending -and !$duplicate.RecoveryReady) 'one fresh account snapshot repeated twice still cannot complete recovery'
 $unique=Poll $cache
 Check ($unique.RecoveryReady -and $unique.State -ceq 'DISARMED') 'two distinct post-request account snapshots allow recovery with matching sheet evidence'

 $identity=New-Fixture 'request-run-changed';$null=Poll $identity;$null=Poll $identity;$null=Request-Recovery $identity;Write-JournalReceipt $identity
 $identity.Owner.RunId=[guid]::NewGuid().ToString();$runChanged=Poll $identity
 Check (!$runChanged.RecoveryPending -and !$runChanged.RecoveryReady -and $runChanged.RecoveryCode -ceq 'LIVE_RECOVERY_BLOCKED' -and $runChanged.State -ceq 'DISARMED') 'changing process identity while recovery waits invalidates the operator request'

 $sourceChanged=New-Fixture 'command-source-changed';$null=Poll $sourceChanged;$null=Poll $sourceChanged;Save-Input $sourceChanged
 $sourceBox=At58X-Mailbox $sourceChanged.Owner.RunId;$sourceBox.Mode='LIVE';$sourceBox.SourceHash=$sourceChanged.Source.Hash;$sourceBox.Last=$sourceChanged.Last;$sourceBox.UiUtc=$script:cashClock.ToString('o')
 At58X-Queue $sourceBox 'RECOVER' $sourceChanged.Source.Hash $null $script:cashClock 'MANUAL_ACCOUNT_AND_SHEET_CHECKED';$sourceBox.SourceHash=('d'*64);At58X-Commands $sourceChanged.Owner $sourceBox
 Check ($sourceBox.CommandError -ceq 'LIVE_SOURCE_CHANGED' -and !(At58-Value $sourceChanged.Owner 'RecoveryRequest')) 'a source identity change while the recovery command waits cannot reuse confirmation'

 foreach($action in @('ARM_AUTO','ARM_TELEGRAM')){
  $manualOnly=New-Fixture ('recovered-'+$action);$null=Poll $manualOnly;$null=Poll $manualOnly;$null=Recover-Fixture $manualOnly
  $automatic=Start-Manual $manualOnly $action;$automaticResult=Poll $manualOnly
  Check ($automatic.CommandError -ceq 'LIVE_RECOVERY_MANUAL_START' -and $automaticResult.State -ceq 'DISARMED' -and $automaticResult.RecoveryReady) ($action+' cannot start trading after recovery before the separate manual Start action')
 }
 $race=New-Fixture 'stop-during-commit';$null=Poll $race;$null=Poll $race;$null=Request-Recovery $race;Write-JournalReceipt $race;$null=Poll $race
 $script:realFillProof=${function:At58X-FillProof};$script:stopRaceBox=$race.Box;$script:injectStop=$true
 function At58X-FillProof($book){
  $proof=& $script:realFillProof $book
  if($script:injectStop){$script:injectStop=$false;At58X-Queue $script:stopRaceBox 'STOP' '' $null $script:cashClock}
  return $proof
 }
 try{$raceResult=Poll $race}finally{Set-Item -Path Function:At58X-FillProof -Value $script:realFillProof}
 Check (!$raceResult.RecoveryReady -and !$raceResult.RecoveryPending -and $raceResult.RecoveryCode -ceq 'LIVE_RECOVERY_CANCELLED' -and $raceResult.State -ceq 'DISARMED' -and ![IO.File]::Exists((At58X-RecoveryPath $race.Owner))) 'STOP arriving between sheet verification and approval commit cannot persist recovery or arm trading'
 Check ($script:network -eq 0 -and $script:posts -eq 1 -and $script:cancels -eq 1) 'all scenarios used synthetic temporary state, one fake new order and one fake cancellation; zero network calls'
 Write-Output ('REJECT RESUME TESTS COMPLETE: '+$script:checks+' passed; Engine='+$PSVersionTable.PSVersion+'; PortableProtection='+$portable+'.')
}finally{
 $safe=[IO.Path]::GetFullPath($work);$temp=[IO.Path]::GetFullPath([IO.Path]::GetTempPath()).TrimEnd([IO.Path]::DirectorySeparatorChar)+[IO.Path]::DirectorySeparatorChar
 if(!$safe.StartsWith($temp,[StringComparison]::OrdinalIgnoreCase) -or [IO.Path]::GetFileName($safe) -cnotmatch '^AvataRejectTest-[a-f0-9]{32}$'){throw 'TEST_CLEANUP_PATH'}
 if([IO.Directory]::Exists($safe)){Remove-Item -LiteralPath $safe -Recurse -Force}
}
