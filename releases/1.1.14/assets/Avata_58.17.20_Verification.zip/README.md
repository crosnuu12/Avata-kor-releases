# Avata 1.1.14 / 58.17.20

Bound repeated authentication recovery across read cycles, preserve bounded asset-worker retry state and clear rejected cached tokens, and classify explicit credential errors before HTTP401. A transient expired GET still gets one immediate renewal/retry; repeated rejection backs off 30/60/120/300 seconds and resets only after an authenticated GET succeeds.

Authentication diagnostics contain only bounded timing, event and error metadata. Tokens, keys, account identity, token hashes and response text are never recorded. The server's initial rejection of a freshly issued token is not established by the previous logs; this release fixes reproduced recovery defects and adds evidence needed to distinguish that cause.

Run Run-Checks.ps1 under Windows PowerShell 5.1, then Test-TrayRestore.ps1 -HostedRunner, Test-DesktopStartup.ps1 and Test-RecoveryDialog.ps1 -HostedRunner. Synthetic regression includes read retries, asset process replacement, remote redaction and real live-cycle authorization/quorum/STOP invariants. No actual broker orders are used.

Final native validation and publication evidence lives in releases/1.1.14/STATUS.md and the release-auth-recovery workflow. This complete source archive is not an installer; archived host scripts must not overwrite installed trust keys. User PC installation and actual incident recovery require independent confirmation.
