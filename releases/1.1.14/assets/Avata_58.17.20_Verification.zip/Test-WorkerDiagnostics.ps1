#requires -Version 5.1
param([string]$Root=$PSScriptRoot)
$ErrorActionPreference='Stop';Set-StrictMode -Version 2
$core=Join-Path $Root 'bundle/payload/At58.Core.ps1'
$ui=Join-Path $Root 'bundle/payload/esbada_Merits_AT_v58.ps1'
. $core
$script:checks=0
function Check($ok,[string]$name){if(!$ok){throw ('FAILED: '+$name)};$script:checks++;Write-Host ('PASS '+$name)}
$work=Join-Path ([IO.Path]::GetTempPath()) ('AvataWorkerDiagnosticTest-'+[guid]::NewGuid().ToString('N'))
[void][IO.Directory]::CreateDirectory($work)
$run=[guid]::NewGuid().ToString();$secret='SECRET_TOKEN_ACCOUNT_12345678'
$tok=$null;$parse=$null;$ast=[Management.Automation.Language.Parser]::ParseFile($ui,[ref]$tok,[ref]$parse)
Check (!$parse.Count) 'UI parses after diagnostic integration'
$tries=@($ast.FindAll({param($a) $a -is [Management.Automation.Language.TryStatementAst] -and $a.Body.Extent.Text.Contains('$u.Worker.EndInvoke($u.Handle)')},$true)|Sort-Object {$_.Extent.Text.Length})
Check ($tries.Count -gt 0) 'locates the production EndInvoke failure handler'
$endInvoke=[scriptblock]::Create($tries[0].Extent.Text)
function Read-Worker([string]$dir){return ([IO.File]::ReadAllText((Join-Path $dir 'worker-error.json'))|ConvertFrom-Json)}
function Run-Worker([string]$dir,[string]$faultScript,[bool]$managed){
 $DataRoot=$dir;$RunId=$run;$box=At58X-Mailbox $run;$box.Mode='LIVE'
 $owner=@{Root=$dir;RunId=$run;LiveSession=@{State='ARMED'}}
 $worker=[PowerShell]::Create()
 try{
  $script:At58Ui=@{Fault='';Worker=$worker;WorkerStartedUtc=[datetime]::UtcNow}
  if($managed){
   [void]$worker.AddScript('param($core,$fixture,$owner,$box); . $core; . $fixture; At58X-ManagedCycle $owner $box').AddArgument($core).AddArgument($faultScript).AddArgument($owner).AddArgument($box)
  }else{[void]$worker.AddScript($faultScript)}
  $u=$script:At58Ui;$u.Handle=$worker.BeginInvoke()
  . $endInvoke
  Check ($script:At58Ui.Fault -ceq 'WORKER_FAILED' -and !$r.Ok -and $r.Status.State -ceq 'STOPPED') 'production EndInvoke catch keeps the worker stopped'
  return [pscustomobject]@{Owner=$owner;Box=$box;Result=$r}
 }finally{$worker.Dispose()}
}
try{
 # The known basename is intentionally copied into an isolated fixture, so
 # real ErrorRecord source attribution can be checked without a live account.
 $fixtureDir=Join-Path $work 'fixture';[void][IO.Directory]::CreateDirectory($fixtureDir)
 $fixture=Join-Path $fixtureDir 'At58.Core.ps1'
 [IO.File]::WriteAllText($fixture,@'
function At58X-Load {return $null}
function At58X-Commands {}
function At58X-Cycle {
 throw [IO.IOException]::new('SECRET_TOKEN_ACCOUNT_12345678')
}
'@)
 $dir=Join-Path $work 'managed';[void][IO.Directory]::CreateDirectory($dir)
 $failed=Run-Worker $dir $fixture $true;$record=Read-Worker $dir
 Check ($record.Schema -ceq 'AT-WORKER-ERROR-1' -and $record.RunId -ceq $run -and $record.Boundary -ceq 'MANAGED_CYCLE') 'EndInvoke preserves the original managed-cycle diagnostic'
 Check ($record.Code -ceq 'UNEXPECTED' -and $record.ErrorType -ceq 'IOException' -and $record.HResult -ne 0) 'records original exception class and numeric error'
 Check ($record.SourceFile -ceq 'At58.Core.ps1' -and $record.Line -eq 4) 'keeps only known source basename and original failing line'
 Check ($failed.Box.State -ceq 'REVIEW' -and $failed.Box.CommandError -ceq 'UNEXPECTED' -and !$failed.Box.Busy -and $failed.Owner.LiveSession.State -ceq 'REVIEW') 'diagnostics preserve managed review and busy cleanup'
 $json=[IO.File]::ReadAllText((Join-Path $dir 'worker-error.json'))
 $keys=@($record.PSObject.Properties.Name|Sort-Object)
 $expected=@('Schema','Utc','RunId','Code','Boundary','ErrorType','HResult','Win32','SourceFile','Line'|Sort-Object)
 Check (($keys -join '|') -ceq ($expected -join '|')) 'diagnostic schema has only the approved bounded fields'
 Check (!$json.Contains($secret) -and !$json.Contains($work) -and $json -notmatch 'Message|Stack|Position|Invocation|Parameters|CommandLine|ScriptText|Authorization') 'root evidence contains no message stack full path or credential text'

 # New invocation before ManagedCycle: fallback replaces the prior invocation,
 # and unknown source names must not be forwarded even when they contain secrets.
 $fallback=Run-Worker $dir "throw [UnauthorizedAccessException]::new('$secret')" $false
 $record=Read-Worker $dir
 Check ($record.Boundary -ceq 'END_INVOKE' -and $record.ErrorType -ceq 'UnauthorizedAccessException' -and $record.SourceFile -ceq '' -and $record.Line -eq 0) 'new invocation fallback replaces stale root evidence without leaking unknown locations'

 # Direct real managed catch: a failed diagnostic write must not replace the
 # original exception or alter REVIEW behavior.
 . $fixture
 $blocked=Join-Path $work 'root-is-a-file';[IO.File]::WriteAllText($blocked,'blocking file')
 $owner=@{Root=$blocked;RunId=$run;LiveSession=@{State='ARMED'}};$box=At58X-Mailbox $run;$box.Mode='LIVE';$caught=$null
 try{$null=At58X-ManagedCycle $owner $box}catch{$caught=$_}
 Check ($caught -and $caught.Exception.Message -ceq $secret -and $box.State -ceq 'REVIEW' -and $owner.LiveSession.State -ceq 'REVIEW' -and !$box.Busy) 'diagnostic storage failure preserves the original exception and all stop behavior'
 Check ([IO.File]::ReadAllText($blocked) -ceq 'blocking file') 'failed diagnostics never replace an unrelated file'

 # Unknown source path and custom exception class are never serialized.
 $unknown=Join-Path $fixtureDir ($secret+'.ps1')
 [IO.File]::WriteAllText($unknown,"throw [ArgumentException]::new('$secret')")
 try{. $unknown}catch{At58WD-Write $dir $run $_ 'MANAGED_CYCLE'}
 $record=Read-Worker $dir
 Check ($record.ErrorType -ceq 'ArgumentException' -and $record.SourceFile -ceq '' -and $record.Line -eq 0) 'unknown script source location is suppressed'
 try{At58-Fail 'LIVE_STATUS_STORAGE' 'LIVE_CONTROL'}catch{At58WD-Write $dir $run $_ 'MANAGED_CYCLE'}
 Check ((Read-Worker $dir).Code -ceq 'LIVE_STATUS_STORAGE') 'tagged machine error code survives without its message or API'
 $before=[IO.File]::ReadAllText((Join-Path $dir 'worker-error.json'))
 try{throw $secret}catch{At58WD-Write $dir $secret $_ 'END_INVOKE';At58WD-Write $dir $run $_ $secret}
 Check ([IO.File]::ReadAllText((Join-Path $dir 'worker-error.json')) -ceq $before) 'invalid run identity and boundary cannot write diagnostics'
 Check ($before.Length -lt 1024 -and !$before.Contains($secret) -and !$before.Contains($work)) 'final diagnostic remains small and secret free'
 'WORKER DIAGNOSTIC TESTS COMPLETE: '+$script:checks+' passed; real runspaces and synthetic local failures only.'
}finally{
 $safe=[IO.Path]::GetFullPath($work);$parent=[IO.Path]::GetFullPath([IO.Path]::GetTempPath()).TrimEnd([IO.Path]::DirectorySeparatorChar,[IO.Path]::AltDirectorySeparatorChar)
 if([IO.Path]::GetDirectoryName($safe) -cne $parent -or [IO.Path]::GetFileName($safe) -cnotmatch '^AvataWorkerDiagnosticTest-[a-f0-9]{32}$'){throw 'TEST_CLEANUP_PATH'}
 if([IO.Directory]::Exists($safe)){Remove-Item -LiteralPath $safe -Recurse -Force}
}
