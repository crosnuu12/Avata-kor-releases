﻿#requires -Version 5.1
param([string]$Root=$PSScriptRoot)
$ErrorActionPreference='Stop';Set-StrictMode -Version 2
. (Join-Path $Root 'bundle/At58.Ops.ps1')
. (Join-Path $Root 'bundle/At58.Sheets.ps1')
$script:checks=0
function Check($ok,[string]$message){if(!$ok){throw ('FAILED: '+$message)};$script:checks++;Write-Output ('PASS '+$message)}
function Throws([scriptblock]$action,[string]$code){$actual='';try{$null=& $action}catch{$actual=$_.Exception.Message};Check ($actual -ceq $code) $code}
$tmp=Join-Path ([IO.Path]::GetTempPath()) ('AvataInputRemote-'+[guid]::NewGuid().ToString('N'))
$data=Join-Path $tmp 'data';$manage=Join-Path $tmp 'manage';$hostRoot=Join-Path $tmp 'host';$inputRoot=Join-Path $data 'input-diagnostics'
foreach($path in @($data,$manage,$hostRoot,$inputRoot)){[void][IO.Directory]::CreateDirectory($path)}
$now=[datetime]::Parse('2026-11-07T03:15:00Z').ToUniversalTime();$runId='11111111-1111-4111-8111-111111111111';$device='22222222-2222-4222-8222-222222222222'
$secret='INPUT_REMOTE_PRIVATE_CANARY'
function Save-Lines([string]$path,$records){$lines=@($records|ForEach-Object {$_|ConvertTo-Json -Depth 12 -Compress});[IO.File]::WriteAllText($path,($lines -join "`n")+"`n",[Text.UTF8Encoding]::new($false))}
try{
 $failed=[ordered]@{Schema='AT-INPUT-DIAGNOSTIC-1';Utc=$now.ToString('o');RunId=$runId;Outcome='FAILED';Step='AGE';Reason='INPUT_EXPIRED';InputUtc=$now.AddSeconds(-121).ToString('o');Code=$secret;Message=$secret;File=@{Path=$secret;Bytes=997};Refresh=@{Token=$secret;Account=$secret};LastSuccessfulRefresh=@{Message=$secret};Error=@{ErrorType='IOException';HResult=-2147024864;Win32=32;Network='Timeout';Http=504;Message=$secret;StackTrace=$secret}}
 $recovered=[ordered]@{Schema='AT-INPUT-DIAGNOSTIC-1';Utc=$now.AddSeconds(60).ToString('o');RunId=$runId;Outcome='INPUT_RECOVERED';Step='COMPLETE';PreviousReason='INPUT_EXPIRED';Message=$secret}
 $clean=SheetDiag-InputLog $failed
 Check ($clean.Code -ceq 'INPUT_READ_FAILED' -and $clean.Reason -ceq 'INPUT_EXPIRED' -and $clean.Stage -ceq 'AGE' -and $clean.Outcome -ceq 'FAILED') 'input read failure exposes exact reason and step without requiring an original Code field'
 Check ($clean.ErrorType -ceq 'IOException' -and $clean.Win32 -eq 32 -and $clean.HResult -eq -2147024864 -and $clean.Network -ceq 'Timeout' -and $clean.Http -eq 504) 'only bounded nested error diagnostics are projected'
 Check ($clean.InputUtc -ceq $now.AddSeconds(-121).ToString('o') -and !(($clean|ConvertTo-Json -Depth 8).Contains($secret)) -and !$clean.Contains('File') -and !$clean.Contains('Refresh') -and !$clean.Contains('LastSuccessfulRefresh')) 'raw file refresh account and exception data never enter the remote projection'
 Check ($null -eq (SheetDiag-InputLog @{Schema='OTHER';Utc=$now.ToString('o');Outcome='FAILED'}) -and $null -eq (SheetDiag-InputLog @{Schema='AT-INPUT-DIAGNOSTIC-1';Utc=$now.ToString('o');Outcome='OK'})) 'unrelated schema and unrecognized outcomes are excluded'
 $mal=SheetDiag-InputLog @{Schema='AT-INPUT-DIAGNOSTIC-1';Utc=$now.ToString('o');Outcome='FAILED';Step=$secret;Reason=$secret;PreviousReason=$secret;InputUtc=$secret;Error=@{Message=$secret;Win32=-1;Http='=1'}}
 Check ($mal.Code -ceq 'INPUT_READ_FAILED' -and !$mal.Contains('Step') -and !$mal.Contains('Reason') -and !$mal.Contains('PreviousReason') -and !$mal.Contains('InputUtc') -and !(($mal|ConvertTo-Json).Contains($secret))) 'malformed input reason step time and error fields are omitted'
 $inputPath=Join-Path $inputRoot 'read-20261107.jsonl';Save-Lines $inputPath @($failed,$recovered)
 $previous=@{};foreach($key in $failed.Keys){$previous[$key]=$failed[$key]};$previous.Utc=$now.AddDays(-1).ToString('o');$previous.Step='READ';$previous.Reason='FILE_SHARING';Save-Lines (Join-Path $inputRoot 'read-20261106.jsonl') @($previous)
 foreach($day in @('20261105','20261108')){$outside=@{};foreach($key in $failed.Keys){$outside[$key]=$failed[$key]};$outside.Reason='DECRYPT';Save-Lines (Join-Path $inputRoot ('read-'+$day+'.jsonl')) @($outside)}
 Save-Lines (Join-Path $data 'read-20261107.jsonl') @(@{Utc=$now.AddSeconds(-30).ToString('o');Code='OK';Stage='ACCOUNT_READ'})
 $before=@(Get-ChildItem -LiteralPath $data -Recurse -File|ForEach-Object {$_.FullName+'|'+(Get-FileHash -LiteralPath $_.FullName).Hash}) -join ';'
 $snapshot=SheetDiag-Snapshot $data $manage $hostRoot $now.AddSeconds(90)
 $inputLogs=@($snapshot.ArchiveLogs|Where-Object {$_.File -like 'input-read-*'})
 Check ($inputLogs.Count -eq 3 -and @($inputLogs|Where-Object {$_.File -ceq 'input-read-20261106.jsonl'}).Count -eq 1 -and @($inputLogs|Where-Object {$_.File -ceq 'input-read-20261107.jsonl'}).Count -eq 2) 'only current and previous KST day fixed input paths are collected'
 Check (@($inputLogs|Where-Object {$_.Data.Code -ceq 'INPUT_RECOVERED' -and $_.Context}).Count -eq 1 -and @($inputLogs|Where-Object {$_.Data.Code -ceq 'INPUT_READ_FAILED' -and !$_.Context}).Count -eq 2) 'input recovery is normal context while actual input failures are diagnostic events'
 Check (@($snapshot.ArchiveLogs|Where-Object {$_.File -ceq 'read-20261107.jsonl' -and $_.Context}).Count -eq 1) 'input incidents retain nearby account-read context without source name collisions'
 Check (!(($snapshot|ConvertTo-Json -Depth 12 -Compress).Contains($secret))) 'rolling snapshot and archival selection contain no private canary'
 $rows=SheetDiag-Values $snapshot $device 1
 Check (@($rows|Where-Object {$_[0] -ceq 'LOG' -and $_[1] -ceq 'input-read-20261107.jsonl' -and $_[5] -ceq 'INPUT_READ_FAILED' -and $_[11].Contains('INPUT_EXPIRED')}).Count -eq 1) 'rolling diagnostic sheet carries the exact input failure reason'
 $after=@(Get-ChildItem -LiteralPath $data -Recurse -File|ForEach-Object {$_.FullName+'|'+(Get-FileHash -LiteralPath $_.FullName).Hash}) -join ';'
 Check ($before -ceq $after) 'input diagnostic collection never mutates application data or trading state'

 $script:originalTail=(Get-Command SheetDiag-Tail).ScriptBlock
 function SheetDiag-Tail([string]$path,[int]$limit=100){if($path -ceq (Join-Path $inputRoot 'read-20261106.jsonl')){throw 'synthetic unreadable prior-day log'};return (& $script:originalTail $path $limit)}
 $partial=SheetDiag-Snapshot $data $manage $hostRoot $now.AddSeconds(90)
 Set-Item -LiteralPath Function:SheetDiag-Tail -Value $script:originalTail
 Check (@($partial.ArchiveLogs|Where-Object {$_.File -ceq 'input-read-20261107.jsonl'}).Count -eq 2) 'an unreadable prior-day input log cannot block current-day diagnostics'

 $normalData=Join-Path $tmp 'normal';$normalInput=Join-Path $normalData 'input-diagnostics';[void][IO.Directory]::CreateDirectory($normalInput)
 Save-Lines (Join-Path $normalInput 'read-20261107.jsonl') @($recovered)
 $normal=SheetDiag-Snapshot $normalData $manage $hostRoot $now.AddSeconds(90)
 Check (@($normal.ArchiveLogs).Count -eq 0 -and @($normal.Logs).Count -eq 0) 'healthy input recovery alone does not flood the remote archive'
 $tailData=Join-Path $tmp 'tail';$tailInput=Join-Path $tailData 'input-diagnostics';[void][IO.Directory]::CreateDirectory($tailInput)
 $tailPath=Join-Path $tailInput 'read-20261107.jsonl'
 [IO.File]::WriteAllText($tailPath,('x'*300000)+"`n"+($failed|ConvertTo-Json -Depth 12 -Compress)+"`n"+'{partial',[Text.UTF8Encoding]::new($false))
 $tail=SheetDiag-Snapshot $tailData $manage $hostRoot $now
 Check (@($tail.ArchiveLogs).Count -eq 1 -and $tail.ArchiveLogs[0].Data.Reason -ceq 'INPUT_EXPIRED') 'bounded input tail ignores the truncated prefix and incomplete final record'

 $script:sent=@()
 function SheetDiag-ArchiveConfig($headers,[string]$mainBase){return 'ARCHIVE_TEST_SHEET'}
 function SheetDiag-ArchiveTarget($headers,[string]$archiveId){return [pscustomobject]@{SpreadsheetId='ARCHIVE_TEST_SHEET';SheetId=77;Rows=1000}}
 function Invoke-RestMethod {param($Method,$Uri,$Headers,$ContentType,$Body,$TimeoutSec,$MaximumRedirection)
  if($Method -ceq 'Get'){return @{range="'진단로그'!A2:A1000";majorDimension='ROWS'}}
  $text=[Text.Encoding]::UTF8.GetString($Body);$script:sent+=,$text;$parsed=$text|ConvertFrom-Json
  return @{spreadsheetId='ARCHIVE_TEST_SHEET';replies=@($parsed.requests|ForEach-Object {@{}})}
 }
 $state=SheetDiag-ArchiveRun $snapshot @{} 'https://synthetic.invalid/MAIN' $device $manage
 Check ($state.Code -ceq 'OK' -and @($state.Pending).Count -eq 0 -and $state.NextSequence -eq 4 -and $script:sent.Count -eq 1) 'input diagnostics pass real queue validation and drain through mocked archive transport'
 Check ($script:sent[0].Contains('input-read-20261107.jsonl') -and $script:sent[0].Contains('INPUT_EXPIRED') -and $script:sent[0].Contains('PreviousReason') -and $script:sent[0].Contains('InputUtc') -and !$script:sent[0].Contains($secret)) 'archive payload retains bounded input detail and recovery context without raw private fields'
 $disk=SheetDiag-ArchiveReadState $manage
 Check ($disk.Ready -and @($disk.Pending).Count -eq 0 -and @($disk.Seen).Count -eq 4) 'archive state round-trip retains the new source safely'
 $values=SheetDiag-ArchiveRow $inputLogs[0] $device 1 ('a'*64)
 $values[4]='../input-diagnostics/read-20261107.jsonl'
 Throws {SheetDiag-ArchiveValidateEvent ([pscustomobject]@{Sequence=1;Key=('a'*64);Values=$values})} 'DIAG_ARCHIVE_EVENT'
 Write-Output ('INPUT DIAGNOSTIC REMOTE PASSED: '+$script:checks+' checks; isolated files and mocked network only')
}finally{Remove-Item -LiteralPath $tmp -Recurse -Force}
