﻿#requires -Version 5.1
param([string]$Root=$PSScriptRoot,[switch]$HostedRunner)
$ErrorActionPreference='Stop';Set-StrictMode -Version 2
if(!$HostedRunner -or $env:GITHUB_ACTIONS -cne 'true' -or $env:RUNNER_ENVIRONMENT -cne 'github-hosted'){throw 'ISOLATED_HOSTED_WINDOWS_REQUIRED'}
Add-Type -AssemblyName System.Windows.Forms,System.Drawing
. (Join-Path $Root 'bundle/payload/At58.Core.ps1')
$script:checks=0;$script:queued=@();$script:disabled=0;$script:reads=0;$script:confirmAnswer=$false;$script:changeDuringConfirm=$false
function Check([bool]$ok,[string]$name){if(!$ok){throw ('FAIL '+$name)};$script:checks++;Write-Output ('PASS '+$name)}
function Invoke-RestMethod {throw 'NETWORK_FORBIDDEN'}
function At58T-Wire {throw 'ORDER_FORBIDDEN'}
$tokens=$null;$errors=$null;$app=Join-Path $Root 'bundle/payload/esbada_Merits_AT_v58.ps1'
$ast=[Management.Automation.Language.Parser]::ParseFile($app,[ref]$tokens,[ref]$errors)
if($errors.Count){throw 'APPLICATION_PARSE'}
foreach($name in @('New-LiveRecoveryDialog','Live-RecoveryBlocked','Live-RecoveryCanRequest','Live-RecoveryText','Live-Recover')){
 $fn=$ast.Find({param($n) $n -is [Management.Automation.Language.FunctionDefinitionAst] -and $n.Name -ceq $name},$true)
 if(!$fn){throw ('FUNCTION_MISSING '+$name)}
 . ([scriptblock]::Create($fn.Extent.Text))
}
$version=(Get-Content (Join-Path $Root 'bundle/release.json') -Raw|ConvertFrom-Json).Version
function Ops-ReadJson($path){return [pscustomobject]@{Version=$version;State='CURRENT';Utc=[datetime]::UtcNow.ToString('o')}}
function Ops-Utc($value){return [datetime]::Parse($value).ToUniversalTime()}
function Live-RecoveryConfirm {if($script:changeDuringConfirm){$script:At58LiveBox.Last.State='ARMED'};return $script:confirmAnswer}
function Live-AutoDisable {$script:disabled++}
function Live-RequestRead {$script:reads++}
function At58X-Queue($box,[string]$action,[string]$hash='',$limits=$null,[datetime]$now=[datetime]::UtcNow,[string]$consentId=''){
 $q=[pscustomobject]@{Action=$action;Hash=$hash;Limits=$limits;Consent=$consentId};$script:queued+=,$q;$box.Command=$q
}
$managed=$true;$HostProtocol=2;$ManagementRoot=$env:RUNNER_TEMP;$script:At58UpdateQueued=$false
function Fresh {
 $script:At58LiveBox=At58X-Mailbox 'ui-test-run';$script:At58LiveBox.Mode='LIVE';$script:At58LiveBox.SourceHash='a'*64;$script:At58LiveBox.TelegramPermit='old-permit'
 $script:At58LiveBox.Last=[pscustomobject]@{State='DISARMED';Code='LIVE_ORDER_REJECTED';RecoveryCode='LIVE_RECOVERY_REQUIRED';RecoveryPending=$false;RecoveryReady=$false;RecoveryCount=1;UncertainOrders=0;OpenOrders=0;Reconciled=$true}
 $liveRecover.Enabled=$true;$liveArm.Enabled=$true
}
$form=[Windows.Forms.Form]::new();$form.Size=[Drawing.Size]::new(1000,760);$form.Padding=[Windows.Forms.Padding]::new(12);$form.Font=[Drawing.Font]::new('Malgun Gothic',10)
$tabs=[Windows.Forms.TabControl]::new();$tabs.Dock='Fill';$liveTab=[Windows.Forms.TabPage]::new('실전 제어');$tabs.TabPages.Add($liveTab);$form.Controls.Add($tabs)
$liveLabel=[Windows.Forms.Label]::new();$liveLabel.Dock='Bottom';$liveLabel.Height=84;$liveTab.Controls.Add($liveLabel)
$dialog=$null
try{
 $source=[IO.File]::ReadAllLines($app)
 $start=-1;$finish=-1
 for($i=0;$i -lt $source.Count;$i++){
  if($source[$i].TrimStart().StartsWith('$liveBar=[Windows.Forms.FlowLayoutPanel]::new();')){$start=$i}
  if($source[$i].Contains('$liveBar.Controls.AddRange(')){$finish=$i}
 }
 if($start -lt 0 -or $finish -le $start){throw 'BAR_INITIALIZER_MISSING'}
 . ([scriptblock]::Create(($source[$start..$finish]-join [Environment]::NewLine)))
 $event=@($source|Where-Object {$_.TrimStart().StartsWith('$liveRecover.Add_Click(')})
 if($event.Count -ne 1){throw 'RECOVERY_EVENT_MISSING'}
 . ([scriptblock]::Create($event[0]))
 $form.Show();[Windows.Forms.Application]::DoEvents()
 Check ($liveBar.Controls.Count -eq 5) 'recovery button is separate from prepare, start, stop and auto-start'
 $fits=$true;foreach($c in $liveBar.Controls){if($c.Right -gt $liveBar.ClientSize.Width -or $c.Bottom -gt $liveBar.ClientSize.Height){$fits=$false}}
 Check $fits 'five real controls fit the minimum-size main window'
 $dialog=New-LiveRecoveryDialog;$dialog.Show($form);[Windows.Forms.Application]::DoEvents();$d=$dialog.Tag
 Check (!$d.Confirm.Enabled -and $dialog.AcceptButton -eq $d.Confirm) 'keyboard and button confirmation start disabled'
 $d.Checks[0].Checked=$true;[Windows.Forms.Application]::DoEvents()
 Check (!$d.Confirm.Enabled) 'broker open-orders checkbox alone cannot confirm'
 $d.Checks[1].Checked=$true;[Windows.Forms.Application]::DoEvents()
 Check (!$d.Confirm.Enabled) 'sheet confirmation is independently required'
 $d.Checks[2].Checked=$true;[Windows.Forms.Application]::DoEvents()
 Check $d.Confirm.Enabled 'three actual checkbox events enable confirmation'
 $d.Checks[0].Checked=$false;[Windows.Forms.Application]::DoEvents()
 Check (!$d.Confirm.Enabled) 'removing any confirmation disables submit again'
 $d.Checks[0].Checked=$true;$d.Confirm.PerformClick();[Windows.Forms.Application]::DoEvents()
 Check ($dialog.DialogResult -eq [Windows.Forms.DialogResult]::OK) 'actual confirm event returns OK only after all checks'
 $dialog.Font.Dispose();$dialog.Dispose();$dialog=$null
 $dialog=New-LiveRecoveryDialog;$dialog.Show($form);[Windows.Forms.Application]::DoEvents();$dialog.Tag.Cancel.PerformClick();[Windows.Forms.Application]::DoEvents()
 Check ($dialog.DialogResult -eq [Windows.Forms.DialogResult]::Cancel) 'actual cancel button exits without approval'
 $dialog.Font.Dispose();$dialog.Dispose();$dialog=$null
 Fresh
 Check (Live-RecoveryCanRequest $script:At58LiveBox) 'disarmed confirmed rejection exposes recovery'
 Check (Live-RecoveryBlocked $script:At58LiveBox.Last) 'ordinary start remains blocked before recovery'
 $script:confirmAnswer=$false;$liveRecover.PerformClick()
 Check ($script:queued.Count -eq 0 -and $script:disabled -eq 0) 'cancelled recovery does not queue a command or change auto-start'
 $script:confirmAnswer=$true;$script:changeDuringConfirm=$true;$liveRecover.PerformClick()
 Check ($script:queued.Count -eq 0) 'changed account state during modal confirmation is rechecked'
 $script:changeDuringConfirm=$false;Fresh;$liveRecover.PerformClick()
 Check ($script:queued.Count -eq 1 -and $script:queued[0].Action -ceq 'RECOVER' -and $script:queued[0].Consent -ceq 'MANUAL_ACCOUNT_AND_SHEET_CHECKED') 'actual recovery button queues only explicit RECOVER consent'
 Check ($script:queued[0].Hash -ceq ('a'*64) -and $null -eq $script:queued[0].Limits) 'recovery request is bound to current source and does not set trading limits'
 Check ($script:disabled -eq 1 -and $script:reads -eq 1 -and !$script:At58LiveBox.TelegramPermit) 'recovery revokes automatic start and old Telegram permit and requests a new read'
 Check (!$liveRecover.Enabled -and !$liveArm.Enabled) 'recovery request disables both buttons until worker results arrive'
 Fresh;$script:At58LiveBox.Last.RecoveryPending=$true;$script:At58LiveBox.Last.RecoveryCode='LIVE_RECOVERY_SHEET_WAIT'
 Check (!(Live-RecoveryCanRequest $script:At58LiveBox) -and (Live-RecoveryBlocked $script:At58LiveBox.Last)) 'pending sheet verification blocks duplicate recovery and manual start'
 Fresh;$script:At58LiveBox.Last.RecoveryReady=$true;$script:At58LiveBox.Last.RecoveryCode='LIVE_RECOVERY_READY';$script:At58LiveBox.Last.Code='LIVE_DISARMED'
 Check (!(Live-RecoveryCanRequest $script:At58LiveBox) -and !(Live-RecoveryBlocked $script:At58LiveBox.Last)) 'recovered state permits separate manual start and avoids redundant recovery'
 Check ((Live-RecoveryText 'LIVE_RECOVERY_READY').Contains('실주문 꺼짐')) 'completion explicitly says trading remains off'
 foreach($state in @('ARMED','STOPPING','REVIEW')){Fresh;$script:At58LiveBox.Last.State=$state;Check (!(Live-RecoveryCanRequest $script:At58LiveBox)) ('recovery is unavailable during '+$state)}
 Fresh;$script:At58LiveBox.Last.UncertainOrders=1;Check (!(Live-RecoveryCanRequest $script:At58LiveBox)) 'uncertain order prevents recovery dialog'
 Fresh;$script:At58LiveBox.Last.OpenOrders=1;Check (!(Live-RecoveryCanRequest $script:At58LiveBox)) 'open order prevents recovery dialog'
 Fresh;$script:At58LiveBox.Busy=$true;Check (!(Live-RecoveryCanRequest $script:At58LiveBox)) 'busy worker prevents racing recovery commands'
 Fresh;$script:At58UpdateQueued=$true;Check (!(Live-RecoveryCanRequest $script:At58LiveBox)) 'queued software update prevents recovery race';$script:At58UpdateQueued=$false
 foreach($code in @('LIVE_RECOVERY_EXPIRED','LIVE_RECOVERY_CHANGED','LIVE_RECOVERY_STORAGE','LIVE_RECOVERY_BLOCKED')){Fresh;$script:At58LiveBox.Last.RecoveryCode=$code;Check ((Live-RecoveryBlocked $script:At58LiveBox.Last) -and [bool](Live-RecoveryText $code)) ('blocked recovery reason is displayed: '+$code)}
 Check ($script:queued.Count -eq 1) 'dialog and gating tests never queue ARM, STOP, cancel or broker requests'
 Write-Output ('RECOVERY DIALOG TESTS COMPLETE: '+$script:checks+' passed; isolated hosted Windows; actual widgets and recovery click handler; no network, credentials or broker orders.')
}finally{
 if($dialog){$dialog.Font.Dispose();$dialog.Dispose()};$form.Font.Dispose();$form.Dispose()
}
