# Avata 1.1.9 / 58.17.15

A manual real-order Start can acknowledge the exact existing broker-identified, zero-fill terminal rejections in the current session. It requires two new reconciled account reads before evaluating orders. Outside market hours it remains armed in market wait and checks again at the open. A new rejection disarms execution; unknown orders, missing broker identifiers, partial fills and unresolved orders remain blocked. Automatic startup and Telegram startup do not acknowledge historical rejections.

The order ledger is retained. Acknowledgment is held only in memory for this running session; a process restart requires a new manual Start. Tests use synthetic fixtures only, with no broker connection or real order.

Run Run-Checks.ps1 on Windows PowerShell 5.1, followed by Test-TrayRestore.ps1 -HostedRunner and Test-DesktopStartup.ps1. Final validation and publication results belong to the release CI records. VALIDATION_STATUS.json records the state at archive creation.

This is the complete verification/source archive, not an installer. The signed runtime update includes only the files listed under bundle/release.json. The host/ folder is inherited verification source: do not copy it over an installed host or replace its installed trust key.
