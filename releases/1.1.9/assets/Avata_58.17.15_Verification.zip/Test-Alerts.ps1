﻿#requires -Version 5.1
param([string]$Root=$PSScriptRoot)
$ErrorActionPreference='Stop';Set-StrictMode -Version 2
. (Join-Path $Root 'bundle/At58.Ops.ps1')
$script:checks=0
function Check([bool]$ok,[string]$name){if(!$ok){throw ('FAIL '+$name)};$script:checks++;Write-Output ('PASS '+$name)}
$now=([datetime]'2026-11-03T13:00:00Z').ToUniversalTime();$run='synthetic-current'
$liveRuntime=[pscustomobject]@{RunId=$run;LiveMode='LIVE';Utc=$now.ToString('o');DesiredRunning=$true;Fault=''}
$paperRuntime=[pscustomobject]@{RunId=$run;LiveMode='PAPER';Utc=$now.ToString('o');DesiredRunning=$true;Fault=''}
$oldSim=[pscustomobject]@{RunId='synthetic-previous';Utc=$now.AddDays(-1).ToString('o');Mode='SIMULATED_CHAIN';Code='SIM_INPUT_WAIT';ExecutionEnabled=$false;OrdersSent=0}
foreach($sim in @($null,$oldSim)){
 $watch=@{}
 $a=Ops-SimulationAlert $watch $sim $run $true $now $liveRuntime
 $b=Ops-SimulationAlert $watch $sim $run $true $now.AddMinutes(10) $liveRuntime
 Check (!$a -and !$b -and $watch.Count -eq 0) 'live mode ignores inactive simulation and does not start its fault timer'
}
$watch=@{}
$null=Ops-SimulationAlert $watch $null $run $true $now $paperRuntime
Check (!(Ops-SimulationAlert $watch $null $run $true $now.AddSeconds(299) $paperRuntime)) 'paper mode keeps five-minute grace'
$fault=Ops-SimulationAlert $watch $null $run $true $now.AddSeconds(300) $paperRuntime
Check ($fault.Event -ceq 'SIM_FAULT' -and $fault.Code -ceq 'SIM_STATUS_MISSING') 'missing active simulation still raises fault'
Check (!(Ops-SimulationAlert $watch $null $run $true $now.AddSeconds(301) $paperRuntime)) 'same simulation incident is not repeated'
$healthySim=[pscustomobject]@{RunId=$run;Utc=$now.AddSeconds(302).ToString('o');Mode='SIMULATED_CHAIN';Code='SIM_MARKET_WAIT';ExecutionEnabled=$false;OrdersSent=0}
$recovered=Ops-SimulationAlert $watch $healthySim $run $true $now.AddSeconds(302) $paperRuntime
Check ($recovered.Event -ceq 'SIM_RECOVERED') 'active simulation recovery is reported'
$watch=@{}
$null=Ops-SimulationAlert $watch $oldSim $run $true $now $paperRuntime
$null=Ops-SimulationAlert $watch $oldSim $run $true $now.AddSeconds(290) $liveRuntime
$a=Ops-SimulationAlert $watch $null $run $true $now.AddSeconds(600) $paperRuntime
$b=Ops-SimulationAlert $watch $null $run $true $now.AddSeconds(900) $paperRuntime
Check (!$a -and $b.Event -ceq 'SIM_FAULT') 'switching back to paper starts a new full grace period'
$wrongRuntime=[pscustomobject]@{RunId='other-run';LiveMode='LIVE'}
foreach($runtime in @($null,$wrongRuntime)){
 $watch=@{}
 $null=Ops-SimulationAlert $watch $null $run $true $now $runtime
 $fault=Ops-SimulationAlert $watch $null $run $true $now.AddMinutes(6) $runtime
 Check ($fault.Event -ceq 'SIM_FAULT') 'legacy or unrelated runtime cannot disable simulation monitoring'
}
$watch=@{}
$null=Ops-SimulationAlert $watch $oldSim $run $true $now $paperRuntime
Check (!(Ops-SimulationAlert $watch $oldSim $run $false $now.AddMinutes(6) $paperRuntime)) 'paused simulation does not emit a fault'
Check (!(Ops-SimulationAlert $watch $oldSim $run $true $now.AddMinutes(7) $paperRuntime)) 'simulation resume receives fresh grace'

function LiveStatus([string]$code,[string]$phase='ARMED',[int]$uncertain=0){
 return [pscustomobject]@{RunId=$run;Live=[pscustomobject]@{RunId=$run;State=$phase;Code=$code;UncertainOrders=$uncertain}}
}
$state=[pscustomobject]@{}
foreach($code in @('LIVE_WAIT','LIVE_DISARMED','LIVE_DUPLICATE_SNAPSHOT','LIVE_ORDER_SENT','LIVE_CANCEL_SENT','LIVE_STOPPED','LIVE_MARKET_WAIT','LIVE_CLOSE_WAIT','LIVE_RECONCILE_WAIT')){
 Check (!(Ops-LiveAlert $state (LiveStatus $code) $run)) ($code+' is a normal status')
}
foreach($code in @('LIVE_MARKET_WAIT','LIVE_CLOSE_WAIT','LIVE_RECONCILE_WAIT')){
 $state=[pscustomobject]@{}
 Check ((Ops-LiveAlert $state (LiveStatus $code 'REVIEW') $run).Event -ceq 'FAULT') 'review state overrides a normal wait code'
 $state=[pscustomobject]@{}
 Check ((Ops-LiveAlert $state (LiveStatus $code 'ARMED' 1) $run).Code -ceq 'LIVE LIVE_ORDER_REVIEW') 'uncertain order overrides a normal wait code'
}
foreach($code in @('LIVE_ORDER_REJECTED','LIVE_INPUT_WAIT','LIVE_CASH_WAIT','LIVE_HISTORY_WAIT','LIVE_SOURCE_CHANGED','LIVE_BOOK_UNREADABLE','UNRECOGNIZED_FAULT')){
 $state=[pscustomobject]@{}
 Check ((Ops-LiveAlert $state (LiveStatus $code) $run).Event -ceq 'FAULT') ($code+' still raises a fault')
}
$state=[pscustomobject]@{}
Check ((Ops-LiveAlert $state (LiveStatus 'LIVE_WAIT' 'UNKNOWN') $run).Event -ceq 'FAULT') 'unknown session state cannot hide behind normal code'
$state=[pscustomobject]@{};$s=LiveStatus 'LIVE_INPUT_WAIT'
$first=Ops-LiveAlert $state $s $run;$second=Ops-LiveAlert $state $s $run
Check ($first.Event -ceq 'FAULT' -and !$second) 'one alert per unchanged live incident'
$null=Ops-LiveAlert $state (LiveStatus 'LIVE_MARKET_WAIT') $run
Check ((Ops-LiveAlert $state $s $run).Event -ceq 'FAULT') 'new occurrence after normal state is reported'
$s.RunId='other-run'
Check (!(Ops-LiveAlert $state $s $run)) 'previous parent status does not create a current alarm'
$s.RunId=$run;$s.Live.RunId='other-run'
Check (!(Ops-LiveAlert $state $s $run)) 'previous nested live status does not create a current alarm'
$state=[pscustomobject]@{}
Check ((Ops-LiveAlert $state (LiveStatus 'bad details!') $run).Code -ceq 'LIVE LIVE_STATUS_INVALID') 'malformed diagnostic details are not forwarded'

$watch=@{}
$null=Ops-ReceiptAlert $watch $null $run $true $now
$receipt=Ops-ReceiptAlert $watch $null $run $true $now.AddMinutes(5)
Check ($receipt.Event -ceq 'FEED_FAULT') 'real receipt-feed loss still raises an alarm'
$status=[pscustomobject]@{RunId=$run;Utc=$now.AddMinutes(5).ToString('o');Mode='OBSERVE';Code='LISTENING';Connected=$true;ExecutionEnabled=$false;OrdersSent=0}
Check ((Ops-ReceiptAlert $watch $status $run $true $now.AddMinutes(5)).Event -ceq 'FEED_RECOVERED') 'real receipt-feed recovery still raises a recovery notice'
$status=[pscustomobject]@{RunId=$run;Utc=$now.ToString('o');Code='OK';Failures=0;ExecutionEnabled=$false;OrdersSent=0}
Check ((Ops-Classify $paperRuntime $status $run $now.AddMinutes(-5) $false $now) -ceq 'HEALTHY') 'healthy reads remain healthy'
$status.Code='NETWORK_TIMEOUT';$status.Failures=3
Check ((Ops-Classify $paperRuntime $status $run $now.AddMinutes(-5) $false $now) -ceq 'PERSISTENT_ERROR') 'persistent real account-query failure is still detected'
$paperRuntime.Utc=$now.AddSeconds(-31).ToString('o')
Check ((Ops-Classify $paperRuntime $status $run $now.AddMinutes(-5) $false $now) -ceq 'NO_HEARTBEAT') 'lost application heartbeat is still detected'

# Execute the actual manager call sites without starting a manager, reading account files,
# sending Telegram messages, or running the application.
$tokens=$null;$errors=$null
$ast=[Management.Automation.Language.Parser]::ParseFile((Join-Path $Root 'bundle/At58.Manager.ps1'),[ref]$tokens,[ref]$errors)
if($errors.Count){throw 'MANAGER_PARSE'}
$calls=$ast.FindAll({param($n) $n -is [Management.Automation.Language.AssignmentStatementAst] -and $n.Left -is [Management.Automation.Language.VariableExpressionAst] -and $n.Left.VariablePath.UserPath -cin @('simulationNotice','liveNotice')},$true)
function Ops-ReadJson([string]$path){return $oldSim}
$DataRoot='C:\synthetic-not-read';$script:runId=$run;$desired=$true;$runtime=$liveRuntime
$simulationWatch=@{RunId=$run;Since=$now.AddMinutes(-10);Notified=$false};$state=[pscustomobject]@{};$status=LiveStatus 'LIVE_MARKET_WAIT'
$simulationNotice=$null;$liveNotice=$null
foreach($call in $calls){. ([scriptblock]::Create($call.Extent.Text))}
Check ($calls.Count -eq 2 -and !$simulationNotice -and !$liveNotice) 'actual manager call sites suppress both reproduced false alarms'
$status=LiveStatus 'LIVE_ORDER_REVIEW' 'REVIEW'
foreach($call in $calls){. ([scriptblock]::Create($call.Extent.Text))}
Check ($liveNotice.Event -ceq 'FAULT') 'actual manager call site preserves real order-review alert'
Write-Output ('ALERT TESTS COMPLETE: '+$script:checks+' passed; synthetic data only; no network or orders.')
