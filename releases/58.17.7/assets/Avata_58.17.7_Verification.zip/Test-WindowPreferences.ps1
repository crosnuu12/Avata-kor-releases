#requires -Version 5.1
param([string]$Root=$PSScriptRoot)
$ErrorActionPreference='Stop';Set-StrictMode -Version 2
. (Join-Path $Root 'bundle/payload/At58.Core.ps1')
$work=Join-Path ([IO.Path]::GetTempPath()) ('AvataWindowMode-'+[guid]::NewGuid().ToString('N'))
[void][IO.Directory]::CreateDirectory($work)
$script:checks=0
function Check([bool]$ok,[string]$name){if(!$ok){throw ('FAIL '+$name)};$script:checks++;Write-Output ('PASS '+$name)}
$path=Join-Path $work 'window-preferences.json'
try{
 Check ((At58Window-UseTray $work) -and (At58Window-LoadTray $work)) 'existing mini-PC without preferences still starts hidden'
 [IO.File]::WriteAllText($path,'{"Schema":"AT-WINDOW-1","StartInTray":false}')
 Check ((At58Window-UseTray $work) -and !(At58Window-LoadTray $work)) 'legacy visible-start preference remains compatible'
 At58Window-SaveMode $work $false
 Check (!(At58Window-UseTray $work) -and !(At58Window-LoadTray $work)) 'desktop mode disables tray and hidden startup'
 At58Window-SaveTray $work
 Check (!(At58Window-UseTray $work) -and !(At58Window-LoadTray $work)) 'late minimize save cannot silently re-enable disabled tray mode'
 [IO.File]::WriteAllText($path,'{"Schema":"AT-WINDOW-2","UseTray":false,"StartInTray":true}')
 Check (!(At58Window-LoadTray $work)) 'desktop setting cannot leave the application hidden without a tray icon'
 At58Window-SaveMode $work $true
 Check ((At58Window-UseTray $work) -and (At58Window-LoadTray $work)) 'explicit tray setting restores hidden startup'
 foreach($raw in @('broken','{"Schema":"AT-WINDOW-2","UseTray":"false","StartInTray":false}','{"Schema":"UNKNOWN","UseTray":false,"StartInTray":false}')){
  [IO.File]::WriteAllText($path,$raw)
  Check ((At58Window-UseTray $work) -and (At58Window-LoadTray $work)) 'invalid preferences preserve the existing mini-PC hidden default'
 }
 $canary=Join-Path $work 'auto-start.dpapi';[IO.File]::WriteAllText($canary,'synthetic consent canary')
 At58Window-SaveMode $work $false
 Check ([IO.File]::ReadAllText($canary) -ceq 'synthetic consent canary') 'window setting does not modify live-trading consent'
 $other=Join-Path $work 'other-pc';[void][IO.Directory]::CreateDirectory($other)
 At58Window-SaveMode $other $true
 Check (!(At58Window-UseTray $work) -and (At58Window-UseTray $other)) 'each PC retains an independent display mode'
 Check (@(Get-ChildItem -LiteralPath $work -File).Count -eq 2) 'window preferences create no account, ledger or trading files'
 Write-Output ('WINDOW PREFERENCE TESTS COMPLETE: '+$script:checks+' passed; synthetic data only.')
}finally{
 $safe=[IO.Path]::GetFullPath($work);$temp=[IO.Path]::GetFullPath([IO.Path]::GetTempPath()).TrimEnd('\')+'\'
 if(!$safe.StartsWith($temp,[StringComparison]::OrdinalIgnoreCase) -or [IO.Path]::GetFileName($safe) -cnotmatch '^AvataWindowMode-[a-f0-9]{32}$'){throw 'TEST_CLEANUP_PATH'}
 Remove-Item -LiteralPath $safe -Recurse -Force
}
