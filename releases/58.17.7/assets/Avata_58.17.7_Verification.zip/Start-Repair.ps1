#requires -Version 5.1
$ErrorActionPreference='Stop'
. (Join-Path $PSScriptRoot 'Install-Repair.ps1')
try{
 $null=IP-CheckPackage $PSScriptRoot
 Write-Host 'Checking package and repair tests...'
 foreach($test in @('Test-HostRepair.ps1','Test-RepairInstaller.ps1')){
  & (Join-Path $env:SystemRoot 'System32/WindowsPowerShell/v1.0/powershell.exe') -NoProfile -NonInteractive -ExecutionPolicy RemoteSigned -File (Join-Path $PSScriptRoot $test)
  if($LASTEXITCODE -ne 0){throw 'REPAIR_TEST_FAILED'}
 }
 $result=IP-Apply ([Environment]::GetFolderPath('LocalApplicationData')) $PSScriptRoot
 Write-Host ('SUCCESS: '+$result) -ForegroundColor Green
 Write-Host 'Now start Avata normally. Confirm 1.1.1, READ_OK and CURRENT.'
 Write-Host 'Live-order consent and account data were not changed.'
}catch{
 $code=[string]$_.Exception.Message
 if($code -cnotmatch '^[A-Z0-9_]{1,80}$'){$code='INSTALL_ERROR'}
 Write-Host ('NOT APPLIED: '+$code) -ForegroundColor Red
 if($code -ceq 'PROGRAM_RUNNING'){Write-Host 'Close Avata normally while DISARMED, then run Repair_Avata.cmd again.'}
 if($code -ceq 'STOP_RECONCILE_CLOSE_REQUIRED'){Write-Host 'Confirm DISARMED, reconciled twice, no open/unknown orders; close Avata normally.'}
 exit 1
}
