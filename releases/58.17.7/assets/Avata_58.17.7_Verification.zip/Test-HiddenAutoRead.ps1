param([string]$Root=$PSScriptRoot,[switch]$ExpectOldFailure)
$ErrorActionPreference='Stop';Set-StrictMode -Version 2
. (Join-Path $Root 'bundle/At58.Ops.ps1')
. (Join-Path $Root 'bundle/payload/At58.Core.ps1')
$work=Join-Path $Root ('test-auto-read-'+[guid]::NewGuid().ToString('N'))
$data=Join-Path $work 'synthetic-account';$manage=Join-Path $work 'manage';$copy=Join-Path $work 'bundle';$run=[guid]::NewGuid().ToString();$process=$null
[void][IO.Directory]::CreateDirectory($data);[void][IO.Directory]::CreateDirectory($manage)
try{
 Copy-Item -LiteralPath (Join-Path $Root 'bundle') -Destination $copy -Recurse
 # Only the isolated test copy replaces transport. The application startup code is unmodified.
 $stub=@'
function At58X-ManagedCycle($owner,$box){
 $owner.Sequence++
 At58-Atomic (Join-Path $owner.Root 'synthetic-reader.json') (@{RunId=$owner.RunId;Calls=$owner.Sequence;OrdersSent=0;ExecutionEnabled=$false}|ConvertTo-Json -Compress)
 return [pscustomobject]@{Ok=$false;Status=[pscustomobject]@{Code='SYNTHETIC_TRANSPORT';State='READ_ERROR';Failures=0;At='TEST';LastSuccessUtc=''};Snapshot=$null;RetrySeconds=60}
}
function At58-Http {throw 'TEST_NETWORK_FORBIDDEN'}
function At58T-Wire {throw 'TEST_ORDER_FORBIDDEN'}
'@
 [IO.File]::AppendAllText((Join-Path $copy 'payload/At58.Core.ps1'),([Environment]::NewLine+$stub),[Text.UTF8Encoding]::new($false))
 At58-SaveCredential $data 'synthetic-hidden-start-key' 'synthetic-hidden-start-secret'
 $exe=Join-Path $env:SystemRoot 'System32/WindowsPowerShell/v1.0/powershell.exe';$app=Join-Path $copy 'payload/esbada_Merits_AT_v58.ps1'
 $arguments=@('-NoProfile','-NonInteractive','-STA','-ExecutionPolicy','RemoteSigned','-File',('"'+$app+'"'),'-AutoStart','-DataRoot',('"'+$data+'"'),'-ManagementRoot',('"'+$manage+'"'),'-OperationsRoot',('"'+$copy+'"'),'-HostProtocol','2','-RunId',$run)
 $process=Start-Process -FilePath $exe -ArgumentList $arguments -WindowStyle Hidden -PassThru -RedirectStandardOutput (Join-Path $work 'stdout.txt') -RedirectStandardError (Join-Path $work 'stderr.txt')
 $processHandle=$process.Handle;$deadline=[datetime]::UtcNow.AddSeconds(15);$reader=$null;$runtime=$null
 do{
  Start-Sleep -Milliseconds 250;$process.Refresh()
  if($process.HasExited){throw ('AUTO_READ_EARLY_EXIT: '+[IO.File]::ReadAllText((Join-Path $work 'stderr.txt')))}
  $runtime=Ops-ReadJson (Join-Path $manage 'runtime.json');$reader=Ops-ReadJson (Join-Path $data 'synthetic-reader.json')
  if($runtime -and $reader){break}
 }while([datetime]::UtcNow -lt $deadline)
 if($ExpectOldFailure){
  if(!$runtime -or $reader -or $runtime.Running -or $runtime.DesiredRunning){throw 'OLD_FAILURE_NOT_REPRODUCED'}
  Write-Output 'REPRODUCED: hidden 58.17.3 startup ignores PerformClick and never starts account reads.'
 }else{
  if(!$runtime -or !$reader -or $runtime.RunId -cne $run -or $reader.RunId -cne $run -or $reader.Calls -lt 1 -or !$runtime.Running -or !$runtime.DesiredRunning -or $runtime.Fault){throw 'HIDDEN_AUTO_READ_NOT_STARTED'}
  Write-Output 'PASS full hidden application with saved synthetic credentials starts reader without a visible button'
  if($runtime.ExecutionEnabled -or $reader.ExecutionEnabled -or $reader.OrdersSent -ne 0 -or [IO.File]::Exists((Join-Path $data 'auto-start.dpapi'))){throw 'HIDDEN_AUTO_READ_UNEXPECTED_CONSENT'}
  Write-Output 'PASS automatic account reads do not create live-trading approval'
  if($process.MainWindowHandle -ne [IntPtr]::Zero){throw 'HIDDEN_AUTO_READ_VISIBLE'}
  Write-Output 'PASS saved-credential startup remains hidden while reader runs'
 }
 Ops-WriteJson (Join-Path $manage 'stop.request.json') @{RunId=$run;Action='RESTART'}
 if(!$process.WaitForExit(10000)){throw 'HIDDEN_AUTO_READ_CLOSE_TIMEOUT'};$process.Refresh()
 if($process.ExitCode -ne 0){throw ('AUTO_READ_CLOSE_ERROR: '+[IO.File]::ReadAllText((Join-Path $work 'stderr.txt')))}
 if(!$ExpectOldFailure){Write-Output 'PASS active hidden reader closes for managed restart without a foreground prompt';Write-Output 'HIDDEN AUTO READ TESTS COMPLETE: 4 passed; synthetic credentials and blocked transport only.'}
}finally{
 if($process){$process.Refresh();if(!$process.HasExited){$process.Kill();$process.WaitForExit()};$process.Dispose()}
 $safe=[IO.Path]::GetFullPath($work);$testBase=[IO.Path]::GetFullPath($Root).TrimEnd('\')+'\'
 if(!$safe.StartsWith($testBase,[StringComparison]::OrdinalIgnoreCase) -or [IO.Path]::GetFileName($safe) -cnotmatch '^test-auto-read-[a-f0-9]{32}$'){throw 'TEST_CLEANUP_PATH'}
 if([IO.Directory]::Exists($safe)){Remove-Item -LiteralPath $safe -Recurse -Force}
}
