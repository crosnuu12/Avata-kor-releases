﻿#requires -Version 5.1
param([string]$LocalBase=([Environment]::GetFolderPath('LocalApplicationData')),[string]$ValidationFile='')
$ErrorActionPreference='Stop'


function IP-Hash([string]$path){return (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant()}
function IP-Read([string]$path){return ([IO.File]::ReadAllText($path,[Text.Encoding]::UTF8)|ConvertFrom-Json)}
function IP-CheckPackage([string]$package){
 $m=IP-Read (Join-Path $package 'package.json')
 if($m.Schema -cne 'AVATA-REPAIR-1' -or $m.Version -cne '58.17.7'){throw 'PACKAGE_INVALID'}
 $seen=@{}
 foreach($f in $m.Files){
  $n=[string]$f.Name
  if($n -cnotmatch '^[A-Za-z0-9_./-]+$' -or $n.StartsWith('/') -or $n -match '(^|/)\.\.?(/|$)' -or $seen.ContainsKey($n)){throw 'PACKAGE_PATH'}
  $seen[$n]=$true;$p=Join-Path $package $n
  if(![IO.File]::Exists($p) -or ([IO.FileInfo]$p).Length -ne $f.Size -or (IP-Hash $p) -cne $f.Hash){throw 'PACKAGE_HASH'}
 }
 foreach($n in @('Install-Repair.ps1','host/At58.Host.ps1','host/At58.Ops.ps1','host/At58.Update.ps1','bundle/release.json','offer.json','Start-Repair.ps1','Repair_Avata.cmd','Test-HostRepair.ps1','Test-RepairInstaller.ps1')){if(!$seen.ContainsKey($n)){throw 'PACKAGE_INCOMPLETE'}}
 return $m
}
function IP-RequireValidation([string]$package,[string]$receiptPath){
 if(!$receiptPath -or ![IO.File]::Exists($receiptPath)){throw 'RUN_START_UPDATE_FIRST'}
 $r=IP-Read $receiptPath
 if($r.Schema -cne 'AVATA-PREFLIGHT-1' -or $r.Result -cne 'PASSED' -or $r.Engine -cne 'WindowsPowerShell-5.1' -or $r.Root -ine [IO.Path]::GetFullPath($package) -or $r.PackageHash -cne (IP-Hash (Join-Path $package 'package.json'))){throw 'PREFLIGHT_PACKAGE_MISMATCH'}
 $stamp=[datetime]::Parse($r.Utc,[Globalization.CultureInfo]::InvariantCulture,[Globalization.DateTimeStyles]::RoundtripKind)
 $age=([datetime]::UtcNow-$stamp.ToUniversalTime()).TotalSeconds
 if($age -lt -2 -or $age -gt 21600){throw 'PREFLIGHT_EXPIRED'}
 $logBase=[IO.Path]::GetFullPath((Join-Path $package 'logs')).TrimEnd('\')+'\'
 $logPath=[IO.Path]::GetFullPath($r.Log)
 if(!$logPath.StartsWith($logBase,[StringComparison]::OrdinalIgnoreCase) -or ![IO.File]::Exists($logPath) -or (IP-Hash $logPath) -cne $r.LogHash){throw 'PREFLIGHT_LOG_CHANGED'}
}
function IP-Paths([string]$localRoot){
 if(![IO.Path]::IsPathRooted($localRoot)){throw 'INSTALL_PATH'}
 $base=[IO.Path]::GetFullPath($localRoot).TrimEnd('\')
 return @{Base=$base;Host=(Join-Path $base 'esbada_AT_host');Manage=(Join-Path $base 'esbada_AT_manage');Data=(Join-Path $base 'esbada_AT_direct')}
}
function IP-WriteBytes([string]$path,[byte[]]$bytes){Ops-WriteBytes $path $bytes}
function IP-Lock($paths){
 $locks=New-Object 'Collections.Generic.List[object]'
 try{
  foreach($v in @(@('Local\esbada-AT-host-',$paths.Host),@('Local\esbada-AT-manager-',$paths.Manage),@('Local\esbada-AT-direct-',$paths.Data))){
   $created=$false;$m=[Threading.Mutex]::new($true,($v[0]+(Ops-Key $v[1].ToLowerInvariant()).Substring(0,24)),[ref]$created)
   if(!$created){$m.Dispose();throw 'PROGRAM_RUNNING'}
   $locks.Add($m)
  }
  return ,$locks
 }catch{foreach($m in $locks){$m.ReleaseMutex();$m.Dispose()};throw}
}
function IP-Unlock($locks){foreach($m in $locks){$m.ReleaseMutex();$m.Dispose()}}
function IP-Checkpoint([string]$name){}
function IP-Inspect($paths,$package){
 $cfg=IP-Read (Join-Path $paths.Host 'settings.json')
 if($cfg.Schema -cne 'AT58-HOST-1' -or $cfg.HostProtocol -ne 2 -or !$cfg.Enabled){throw 'HOST_SETTINGS'}
 if([IO.Path]::GetFullPath($cfg.DataRoot) -ine $paths.Data -or [IO.Path]::GetFullPath($cfg.ManagementRoot) -ine $paths.Manage){throw 'HOST_PATHS'}
 if((Ops-Get $cfg 'FeedUrl' '') -cne 'https://github.com/crosnuu12/Avata-kor-releases/releases/latest/download/avata-update.json'){throw 'SIGNED_FEED_REQUIRED'}
 if([IO.Path]::GetFullPath($cfg.ChannelRoot) -ine (Join-Path $paths.Host 'remote-channel')){throw 'HOST_CHANNEL'}
 $active=IP-Read (Join-Path $paths.Host 'active.json')
 $offer=IP-Read (Join-Path $package 'offer.json')
 if($active.Version -ceq '58.17.7' -and $active.Id -ceq $offer.Id -and $active.ManifestHash -ceq $offer.ManifestHash){
  $hostCurrent=$true
  foreach($n in @('At58.Host.ps1','At58.Ops.ps1','At58.Update.ps1')){if((IP-Hash (Join-Path $paths.Host $n)) -cne (IP-Hash (Join-Path $package ('host/'+$n)))){$hostCurrent=$false}}
  if($hostCurrent){throw 'ALREADY_INSTALLED'}
 }
 $known=@{
  '58.17.0'=@('bundle-a1911e62f3f0341a1353e7b7','972672bba0304b22dbad4cbef7cb77a130e7989eb25d8aae306a849fc1ad0efe')
  '58.17.6'=@('bundle-67aa5ba8ee68e80a146f4e5e','245ba35745d96320127c862218861e013dab09821e11ef3c16c596af56132f10')
  '58.17.7'=@($offer.Id,$offer.ManifestHash)
 }
 $identity=$known[[string]$active.Version]
 if(!$identity -or $active.Id -cne $identity[0] -or $active.ManifestHash -cne $identity[1]){throw 'INSTALLED_VERSION'}
 $null=Up-Validate (Ops-Inside $paths.Host (Join-Path $paths.Host ('bundles\'+$active.Id))) $active.ManifestHash
 $expected=@{'At58.Host.ps1'='101598fec8ed6719ac742f7be832c944497aded49b1d5a7663b16e3bcf3e34ab';'At58.Update.ps1'='b6c662070656820aa2331caabab196796063f4de23ac38732c4ad72b7b99823b';'At58.Ops.ps1'='42d6058e91b68e15e5fa14953bee6c129ee171c69f02dd5b9ed26cd1f3864a44'}
 foreach($n in $expected.Keys){if((IP-Hash (Ops-Inside $paths.Host (Join-Path $paths.Host $n))) -cne $expected[$n]){throw 'INSTALLED_HOST_CHANGED'}}
 $trial=Ops-ReadJson (Join-Path $paths.Host 'trial.json')
 if($trial -and $trial.Phase -cin @('PENDING','ROLLING_BACK')){throw 'UPDATE_TRIAL_ACTIVE'}
 $state=Ops-ReadJson (Join-Path $paths.Host 'state.json')
 if($state -and $offer.Id -cin @($state.Rejected)){throw 'CANDIDATE_PREVIOUSLY_REJECTED'}
 $runtime=IP-Read (Join-Path $paths.Manage 'runtime.json')
 $status=IP-Read (Join-Path $paths.Data 'status.json')
 # All three application mutexes are held by this installer. Validate the
 # recorded CLOSED state at its own timestamp; never use it as current trading proof.
 $closed=Ops-Utc $runtime.Utc;$age=((Ops-Now)-$closed).TotalSeconds
 try{$live=Ops-LiveStatus $runtime $status $runtime.RunId $closed}catch{throw 'STOP_RECONCILE_CLOSE_REQUIRED'}
 if(!$live -or $age -lt -2 -or $age -gt 2592000 -or $runtime.ExitReason -cne 'USER_CLOSE' -or (Ops-Get $runtime 'ExecutionEnabled' $true) -ne $false -or (Ops-Get $runtime 'LiveCommandPending' $true) -ne $false -or $live.State -cne 'DISARMED' -or $live.ExecutionEnabled -or $live.OpenOrders -ne 0 -or $live.UncertainOrders -ne 0 -or !$live.Reconciled -or $live.Confirmations -lt 2){throw 'STOP_RECONCILE_CLOSE_REQUIRED'}
 return @{Config=$cfg;Active=$active;Offer=$offer}
}
function IP-Restore($paths,[string]$backup){
 $receipt=IP-Read (Join-Path $backup 'receipt.json')
 if($receipt.Schema -cne 'AVATA-ROLLOVER-BACKUP-1' -or $receipt.Host -ine $paths.Host){throw 'BACKUP_INVALID'}
 $active=IP-Read (Join-Path $paths.Host 'active.json')
 if($active.Id -cne $receipt.Active.Id -or $active.ManifestHash -cne $receipt.Active.ManifestHash){throw 'RESTORE_AFTER_START_BLOCKED'}
 $sessionPath=Join-Path $paths.Host 'session.json'
 $sessionHash=if([IO.File]::Exists($sessionPath)){IP-Hash $sessionPath}else{''}
 if($sessionHash -cne (Ops-Get $receipt 'SessionHash' '')){throw 'RESTORE_AFTER_START_BLOCKED'}
 foreach($name in @('At58.Host.ps1','At58.Ops.ps1','At58.Update.ps1','settings.json')){
  $saved=Ops-Inside $backup (Join-Path $backup $name)
  $old=[string](Ops-Get $receipt.OriginalHashes $name '')
  $next=[string](Ops-Get $receipt.NewHashes $name '')
  $target=Ops-Inside $paths.Host (Join-Path $paths.Host $name)
  if((IP-Hash $saved) -cne $old -or (IP-Hash $target) -cnotin @($old,$next)){throw 'BACKUP_OR_TARGET_CHANGED'}
 }
 $ready=Ops-Inside $paths.Host (Join-Path $paths.Host 'local-upgrade\ready.json')
 if([IO.File]::Exists($ready) -and (IP-Hash $ready) -cne $receipt.OfferHash){throw 'QUEUED_OFFER_CHANGED'}
 if([IO.File]::Exists($ready)){[IO.File]::Delete($ready)}
 foreach($name in @('settings.json','At58.Update.ps1','At58.Ops.ps1','At58.Host.ps1')){IP-WriteBytes (Join-Path $paths.Host $name) ([IO.File]::ReadAllBytes((Join-Path $backup $name)))}
 $receipt.Phase='RESTORED';Ops-WriteJson (Join-Path $backup 'receipt.json') $receipt
}
function IP-Apply([string]$localRoot,[string]$package){
 $null=IP-CheckPackage $package
 . (Join-Path $package 'host/At58.Ops.ps1')
 . (Join-Path $package 'host/At58.Update.ps1')
 $paths=IP-Paths $localRoot;$locks=IP-Lock $paths
 $backup='';$changed=$false
 try{
  $pending=Ops-ReadJson (Join-Path $paths.Host 'rollover-install.json')
  if($pending -and $pending.Phase -cin @('PREPARED','APPLIED')){throw 'INSTALL_ALREADY_STAGED'}
  $info=IP-Inspect $paths $package
  $offer=$info.Offer;$null=Up-Validate (Join-Path $package 'bundle') $offer.ManifestHash
  $localChannel=Ops-Inside $paths.Host (Join-Path $paths.Host 'local-upgrade')
  $ready=Ops-Inside $paths.Host (Join-Path $localChannel 'ready.json')
  if([IO.File]::Exists($ready)){throw 'ANOTHER_UPDATE_QUEUED'}
  $dest=Ops-Inside $paths.Host (Join-Path $localChannel ('releases\'+$offer.Id))
  if([IO.Directory]::Exists($dest)){$null=Up-Validate $dest $offer.ManifestHash}else{
   [void][IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($dest))
   Copy-Item -LiteralPath (Join-Path $package 'bundle') -Destination $dest -Recurse
   $null=Up-Validate $dest $offer.ManifestHash
  }
  $backup=Ops-Inside $paths.Host (Join-Path $paths.Host ('rollover-backups\'+[guid]::NewGuid().ToString('N')))
  [void][IO.Directory]::CreateDirectory($backup)
  $oldHashes=@{}
  foreach($n in @('At58.Host.ps1','At58.Ops.ps1','At58.Update.ps1','settings.json')){Copy-Item -LiteralPath (Join-Path $paths.Host $n) -Destination (Join-Path $backup $n);$oldHashes[$n]=IP-Hash (Join-Path $backup $n)}
  $cfg=$info.Config;$cfg|Add-Member NoteProperty ResumeOnce $true -Force
  Ops-WriteJson (Join-Path $backup 'settings.new.json') $cfg
  $newHashes=@{'settings.json'=(IP-Hash (Join-Path $backup 'settings.new.json'))};foreach($n in @('At58.Host.ps1','At58.Ops.ps1','At58.Update.ps1')){$newHashes[$n]=IP-Hash (Join-Path $package ('host/'+$n))}
  $receipt=@{Schema='AVATA-ROLLOVER-BACKUP-1';Phase='PREPARED';Host=$paths.Host;Active=$info.Active;OriginalHashes=$oldHashes;NewHashes=$newHashes;OfferHash=(IP-Hash (Join-Path $package 'offer.json'))}
  $sessionPath=Join-Path $paths.Host 'session.json';$receipt.SessionHash=if([IO.File]::Exists($sessionPath)){IP-Hash $sessionPath}else{''}
  Ops-WriteJson (Join-Path $backup 'receipt.json') $receipt
  Ops-WriteJson (Join-Path $paths.Host 'rollover-install.json') @{Phase='PREPARED';Backup=$backup;Candidate=$offer.Id}
  $changed=$true;IP-Checkpoint 'BEFORE_HOST'
  foreach($n in @('At58.Host.ps1','At58.Ops.ps1','At58.Update.ps1')){IP-WriteBytes (Join-Path $paths.Host $n) ([IO.File]::ReadAllBytes((Join-Path $package ('host/'+$n))));IP-Checkpoint ('AFTER_'+$n)}
  IP-Checkpoint 'AFTER_HOST'
  IP-WriteBytes (Join-Path $paths.Host 'settings.json') ([IO.File]::ReadAllBytes((Join-Path $backup 'settings.new.json')))
  IP-Checkpoint 'AFTER_SETTINGS'
  IP-WriteBytes $ready ([IO.File]::ReadAllBytes((Join-Path $package 'offer.json')))
  IP-Checkpoint 'AFTER_OFFER'
  $receipt.Phase='APPLIED';Ops-WriteJson (Join-Path $backup 'receipt.json') $receipt
  Ops-WriteJson (Join-Path $paths.Host 'rollover-install.json') @{Phase='APPLIED';Backup=$backup;Candidate=$offer.Id}
  return 'UPDATE_STAGED'
 }catch{
  $failure=$_
  if($changed){try{IP-Restore $paths $backup;Ops-WriteJson (Join-Path $paths.Host 'rollover-install.json') @{Phase='RESTORED';Backup=$backup}}catch{throw 'INSTALL_ROLLBACK_REQUIRES_REVIEW'}}
  throw $failure
 }finally{IP-Unlock $locks}
}
function IP-Cancel([string]$localRoot,[string]$package){
 $null=IP-CheckPackage $package
 . (Join-Path $package 'host/At58.Ops.ps1')
 $paths=IP-Paths $localRoot;$locks=IP-Lock $paths
 try{
  $p=IP-Read (Join-Path $paths.Host 'rollover-install.json')
  if($p.Phase -cnotin @('PREPARED','APPLIED')){throw 'NO_PENDING_INSTALL'}
  $backup=Ops-Inside (Join-Path $paths.Host 'rollover-backups') $p.Backup
  IP-Restore $paths $backup
  Ops-WriteJson (Join-Path $paths.Host 'rollover-install.json') @{Phase='RESTORED';Backup=$backup}
  return 'UPDATE_CANCELLED'
 }finally{IP-Unlock $locks}
}
