﻿param([string]$Root='',[string]$OriginalRoot=(Join-Path $PSScriptRoot 'tests/original'))
$ErrorActionPreference='Stop'
if([string]::IsNullOrWhiteSpace($Root)){$Root=Split-Path -Parent $MyInvocation.MyCommand.Path}
. (Join-Path $Root 'Install-Repair.ps1')
. (Join-Path $Root 'host/At58.Ops.ps1')
. (Join-Path $Root 'host/At58.Update.ps1')
$script:passed=0
function Check($condition,[string]$name){if(!$condition){throw ('FAILED: '+$name)};$script:passed++;Write-Output ('PASS '+$name)}
function Reject($action,[string]$code,[string]$name){$actual='';try{& $action|Out-Null}catch{$actual=$_.Exception.Message};Check ($actual -ceq $code) ($name+' ['+$actual+']')}
$work=Join-Path ([IO.Path]::GetTempPath()) ('AIT-'+[guid]::NewGuid().ToString('N').Substring(0,12))
if([IO.Directory]::Exists($work)){throw 'TEST_DIRECTORY_COLLISION'}
$null=[IO.Directory]::CreateDirectory($work)
$script:fixtureId=0
function Fixture([string]$name){
 $script:fixtureId++;$base=Join-Path $work ('f'+$script:fixtureId);$p=IP-Paths $base
 foreach($d in @($p.Host,$p.Manage,$p.Data)){[void][IO.Directory]::CreateDirectory($d)}
 foreach($n in @('At58.Host.ps1','At58.Ops.ps1','At58.Update.ps1')){Copy-Item -LiteralPath (Join-Path $OriginalRoot $n) -Destination (Join-Path $p.Host $n)}
 $offer=IP-Read (Join-Path $OriginalRoot 'channel/ready.json')
 $bundles=Join-Path $p.Host 'bundles';[void][IO.Directory]::CreateDirectory($bundles)
 Copy-Item -LiteralPath (Join-Path $OriginalRoot ('channel/releases/'+$offer.Id)) -Destination (Join-Path $bundles $offer.Id) -Recurse
 if($name -ceq 'mini-current'){
  $offer=IP-Read (Join-Path $Root 'tests/stable6/offer.json')
  Copy-Item -LiteralPath (Join-Path $Root 'tests/stable6/bundle') -Destination (Join-Path $bundles $offer.Id) -Recurse
 }
 if($name -ceq 'bundle-updated-host-old'){
  $offer=IP-Read (Join-Path $Root 'offer.json')
  Copy-Item -LiteralPath (Join-Path $Root 'bundle') -Destination (Join-Path $bundles $offer.Id) -Recurse
 }
 Ops-WriteJson (Join-Path $p.Host 'active.json') @{Id=$offer.Id;Version=$offer.Version;ManifestHash=$offer.ManifestHash}
 Ops-WriteJson (Join-Path $p.Host 'settings.json') @{Schema='AT58-HOST-1';HostProtocol=2;Enabled=$true;DataRoot=$p.Data;ManagementRoot=$p.Manage;ChannelRoot=(Join-Path $p.Host 'remote-channel');FeedUrl='https://github.com/crosnuu12/Avata-kor-releases/releases/latest/download/avata-update.json';ManualWhenRunning=$true;ResumeOnce=$false;PreserveMe='synthetic'}
 $id=[guid]::NewGuid().ToString();$stamp=[datetime]::UtcNow.ToString('o')
 $live=@{Schema='AT-LIVE-STATUS-1';HostProtocol=2;RunId=$id;Utc=$stamp;State='DISARMED';ExecutionEnabled=$false;OrdersSent=0;OpenOrders=0;UncertainOrders=0;Reconciled=$true;Confirmations=2;TestOnly=$false}
 Ops-WriteJson (Join-Path $p.Data 'status.json') @{HostProtocol=2;RunId=$id;Utc=$stamp;Live=$live;ExecutionEnabled=$false;OrdersSent=0;Code='OK'}
 Ops-WriteJson (Join-Path $p.Manage 'runtime.json') @{HostProtocol=2;RunId=$id;Utc=$stamp;LiveMode='LIVE';ExitReason='USER_CLOSE';ExecutionEnabled=$false;LiveCommandPending=$false}
 [IO.File]::WriteAllText((Join-Path $p.Data 'protected-ledger-marker.txt'),'DO NOT CHANGE')
 return $p
}
try{
 # The user-facing installer must reject missing, stale or changed preflight results.
 $gate=Join-Path $work 'gate';$gateLogs=Join-Path $gate 'logs';[void][IO.Directory]::CreateDirectory($gateLogs)
 [IO.File]::WriteAllText((Join-Path $gate 'package.json'),'synthetic-manifest')
 $gateLog=Join-Path $gateLogs 'test.txt';[IO.File]::WriteAllText($gateLog,'synthetic passing output')
 $gateReceipt=Join-Path $gateLogs 'receipt.json'
 $receipt=@{Schema='AVATA-PREFLIGHT-1';Result='PASSED';Engine='WindowsPowerShell-5.1';Root=$gate;PackageHash=(IP-Hash (Join-Path $gate 'package.json'));Utc=[datetime]::UtcNow.ToString('o');Log=$gateLog;LogHash=(IP-Hash $gateLog)}
 Ops-WriteJson $gateReceipt $receipt
 Reject {IP-RequireValidation $gate ''} 'RUN_START_UPDATE_FIRST' 'direct installer entry requires tests first'
 IP-RequireValidation $gate $gateReceipt;Check $true 'matching current preflight accepted'
 $receipt.Utc=[datetime]::UtcNow.AddHours(-7).ToString('o');Ops-WriteJson $gateReceipt $receipt
 Reject {IP-RequireValidation $gate $gateReceipt} 'PREFLIGHT_EXPIRED' 'old tests cannot authorize new application'
 $receipt.Utc=[datetime]::UtcNow.ToString('o');Ops-WriteJson $gateReceipt $receipt
 [IO.File]::AppendAllText((Join-Path $gate 'package.json'),'changed')
 Reject {IP-RequireValidation $gate $gateReceipt} 'PREFLIGHT_PACKAGE_MISMATCH' 'changed package requires fresh tests'
 $receipt.PackageHash=IP-Hash (Join-Path $gate 'package.json');Ops-WriteJson $gateReceipt $receipt
 [IO.File]::AppendAllText($gateLog,'changed')
 Reject {IP-RequireValidation $gate $gateReceipt} 'PREFLIGHT_LOG_CHANGED' 'changed test record rejected'
 $m=IP-CheckPackage $Root
 Check ($m.Version -ceq '58.17.7') 'package hashes and expected scripts verified'
 $offer=IP-Read (Join-Path $Root 'offer.json')
 $release=Up-Validate (Join-Path $Root 'bundle') $offer.ManifestHash
 Check ($release.Version -ceq '58.17.7' -and $release.HostProtocol -eq 2) 'actual updater accepts candidate bundle'
 $p=Fixture 'bundle-updated-host-old'
 Check ((IP-Apply $p.Base $Root) -ceq 'UPDATE_STAGED') 'host repair also accepts an already updated 1.1.1 application'
 Ops-WriteJson (Join-Path $p.Host 'session.json') @{Session=[guid]::NewGuid().ToString()}
 Reject {IP-Cancel $p.Base $Root} 'RESTORE_AFTER_START_BLOCKED' 'same-version repair cannot be rolled back after a new host session'
 $p=Fixture 'mini-current'
 [IO.File]::WriteAllText((Join-Path $p.Data 'auto-start.dpapi'),'synthetic-unchanged-consent')
 [IO.File]::WriteAllText((Join-Path $p.Data 'window.json'),'synthetic-unchanged-window')
 Check ((IP-Apply $p.Base $Root) -ceq 'UPDATE_STAGED') 'installed 1.0.1 mini-PC bundle is accepted and staged'
 Check ([IO.File]::ReadAllText((Join-Path $p.Data 'auto-start.dpapi')) -ceq 'synthetic-unchanged-consent' -and [IO.File]::ReadAllText((Join-Path $p.Data 'window.json')) -ceq 'synthetic-unchanged-window') 'installation preserves consent and window preference files'
 $p=Fixture 'normal';$oldHost=IP-Hash (Join-Path $p.Host 'At58.Host.ps1');$oldSettings=IP-Hash (Join-Path $p.Host 'settings.json');$oldActive=IP-Hash (Join-Path $p.Host 'active.json');$oldOps=IP-Hash (Join-Path $p.Host 'At58.Ops.ps1');$oldUpdate=IP-Hash (Join-Path $p.Host 'At58.Update.ps1')
 Check ((IP-Apply $p.Base $Root) -ceq 'UPDATE_STAGED') 'installer stages update while all app processes are closed'
 Check ((IP-Hash (Join-Path $p.Host 'active.json')) -ceq $oldActive) 'installer leaves active bundle pointer unchanged'
 $cfg=IP-Read (Join-Path $p.Host 'settings.json')
 Check ($cfg.ManualWhenRunning -eq $true -and $cfg.ResumeOnce -eq $true -and $cfg.PreserveMe -ceq 'synthetic') 'query resumes while user update preference remains unchanged'
 $queued=Up-Offer (Join-Path $p.Host 'local-upgrade')
 Check ($queued.Id -ceq $offer.Id) 'real updater validates locally queued offer'
 Check ([IO.File]::ReadAllText((Join-Path $p.Data 'protected-ledger-marker.txt')) -ceq 'DO NOT CHANGE') 'installer leaves account data untouched'
 Reject {IP-Apply $p.Base $Root} 'INSTALL_ALREADY_STAGED' 'repeat apply cannot create a second transaction'
 Check ((IP-Cancel $p.Base $Root) -ceq 'UPDATE_CANCELLED') 'staged application can be cancelled before restart'
 Check ((IP-Hash (Join-Path $p.Host 'At58.Host.ps1')) -ceq $oldHost -and (IP-Hash (Join-Path $p.Host 'settings.json')) -ceq $oldSettings) 'cancellation restores original host and settings byte for byte'
 Check ((IP-Hash (Join-Path $p.Host 'At58.Ops.ps1')) -ceq $oldOps -and (IP-Hash (Join-Path $p.Host 'At58.Update.ps1')) -ceq $oldUpdate) 'cancellation restores both host dependencies byte for byte'
 Check (!(Test-Path -LiteralPath (Join-Path $p.Host 'local-upgrade/ready.json'))) 'cancellation removes queued offer'
 foreach($point in @('BEFORE_HOST','AFTER_HOST','AFTER_At58.Host.ps1','AFTER_At58.Ops.ps1','AFTER_At58.Update.ps1','AFTER_SETTINGS','AFTER_OFFER')){
  $p=Fixture ('fault-'+$point);$h=IP-Hash (Join-Path $p.Host 'At58.Host.ps1');$s=IP-Hash (Join-Path $p.Host 'settings.json');$ops=IP-Hash (Join-Path $p.Host 'At58.Ops.ps1');$up=IP-Hash (Join-Path $p.Host 'At58.Update.ps1')
  $script:failAt=$point
  function IP-Checkpoint([string]$name){if($name -ceq $script:failAt){throw 'TEST_INJECTED_FAILURE'}}
  Reject {IP-Apply $p.Base $Root} 'TEST_INJECTED_FAILURE' ('injected interruption at '+$point)
  Check ((IP-Hash (Join-Path $p.Host 'At58.Host.ps1')) -ceq $h -and (IP-Hash (Join-Path $p.Host 'settings.json')) -ceq $s -and !(Test-Path -LiteralPath (Join-Path $p.Host 'local-upgrade/ready.json'))) ('transaction rollback at '+$point)
  Check ((IP-Hash (Join-Path $p.Host 'At58.Ops.ps1')) -ceq $ops -and (IP-Hash (Join-Path $p.Host 'At58.Update.ps1')) -ceq $up) ('host dependencies rollback at '+$point)
 }
 function IP-Checkpoint([string]$name){}
 foreach($lockKind in @('host','manager','direct')){
  $p=Fixture ('mutex-'+$lockKind);$target=@{host=$p.Host;manager=$p.Manage;direct=$p.Data}[$lockKind]
  $created=$false;$lock=[Threading.Mutex]::new($true,('Local\esbada-AT-'+$lockKind+'-'+(Ops-Key $target.ToLowerInvariant()).Substring(0,24)),[ref]$created)
  try{Reject {IP-Apply $p.Base $Root} 'PROGRAM_RUNNING' ('running '+$lockKind+' blocks installation')}finally{$lock.ReleaseMutex();$lock.Dispose()}
 }
 foreach($case in @('ARMED','STOPPING','UNCERTAIN','UNRECONCILED','OLD_STATUS','PENDING_COMMAND')){
  $p=Fixture $case;$s=IP-Read (Join-Path $p.Data 'status.json');$r=IP-Read (Join-Path $p.Manage 'runtime.json')
  switch($case){
   'ARMED' {$s.Live.State='ARMED'}
   'STOPPING' {$s.Live.State='STOPPING'}
   'UNCERTAIN' {$s.Live.UncertainOrders=1}
   'UNRECONCILED' {$s.Live.Reconciled=$false}
   'OLD_STATUS' {$s.Live.Utc=[datetime]::UtcNow.AddMinutes(-2).ToString('o')}
   'PENDING_COMMAND' {$r.LiveCommandPending=$true}
  }
  Ops-WriteJson (Join-Path $p.Data 'status.json') $s;Ops-WriteJson (Join-Path $p.Manage 'runtime.json') $r
  Reject {IP-Apply $p.Base $Root} 'STOP_RECONCILE_CLOSE_REQUIRED' ('unsafe state rejected: '+$case)
 }
 $p=Fixture 'old-closed';$s=IP-Read (Join-Path $p.Data 'status.json');$v=IP-Read (Join-Path $p.Manage 'runtime.json');$stamp=[datetime]::UtcNow.AddDays(-1).ToString('o');$v.Utc=$stamp;$s.Utc=$stamp;$s.Live.Utc=$stamp
 Ops-WriteJson (Join-Path $p.Data 'status.json') $s;Ops-WriteJson (Join-Path $p.Manage 'runtime.json') $v
 Check ((IP-Apply $p.Base $Root) -ceq 'UPDATE_STAGED') 'closed inactive main PC can be upgraded without treating old data as current trading proof'
 $p=Fixture 'cash-wait';$s=IP-Read (Join-Path $p.Data 'status.json');$s.Live.Reconciled=$false;$s.Live|Add-Member Code 'LIVE_CASH_WAIT';Ops-WriteJson (Join-Path $p.Data 'status.json') $s
 Reject {IP-Apply $p.Base $Root} 'STOP_RECONCILE_CLOSE_REQUIRED' 'cash mismatch is never bypassed'
 $p=Fixture 'wrong-version';$a=IP-Read (Join-Path $p.Host 'active.json');$a.Version='58.16.0';Ops-WriteJson (Join-Path $p.Host 'active.json') $a
 Reject {IP-Apply $p.Base $Root} 'INSTALLED_VERSION' 'unknown version rejected'
 $p=Fixture 'tampered-host';[IO.File]::AppendAllText((Join-Path $p.Host 'At58.Host.ps1'),'# synthetic local edit')
 Reject {IP-Apply $p.Base $Root} 'INSTALLED_HOST_CHANGED' 'local host modifications are not overwritten'
 $p=Fixture 'changed-after-stage';$null=IP-Apply $p.Base $Root
 $a=IP-Read (Join-Path $p.Host 'active.json');$a.Id=$offer.Id;$a.ManifestHash=$offer.ManifestHash;$a.Version=$offer.Version;Ops-WriteJson (Join-Path $p.Host 'active.json') $a
 Reject {IP-Cancel $p.Base $Root} 'RESTORE_AFTER_START_BLOCKED' 'manual rollback cannot silently replace active newer app'
 Write-Output ('INSTALLER TESTS COMPLETE: '+$script:passed+' passed; synthetic local state only; no network or orders.')
}finally{
 $safe=[IO.Path]::GetFullPath($work);$temp=[IO.Path]::GetFullPath([IO.Path]::GetTempPath()).TrimEnd('\')+'\'
 if(!$safe.StartsWith($temp,[StringComparison]::OrdinalIgnoreCase) -or [IO.Path]::GetFileName($safe) -cnotmatch '^AIT-[a-f0-9]{12}$'){throw 'TEST_CLEANUP_PATH'}
 if(Test-Path -LiteralPath $work){Remove-Item -LiteralPath $safe -Recurse -Force}
}
