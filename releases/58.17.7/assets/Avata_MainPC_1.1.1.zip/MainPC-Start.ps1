#requires -Version 5.1
param([switch]$Inspect)
$ErrorActionPreference='Stop'
$profileRoot=[Environment]::GetFolderPath('UserProfile')
$localRoot=Join-Path $profileRoot 'AppData\Local'
$hostRoot=Join-Path $localRoot 'esbada_AT_host'
$launcher=Join-Path $localRoot 'Avata_kor\Avata_kor.exe'
function Key([string]$text){$h=[Security.Cryptography.SHA256]::Create();try{return ([BitConverter]::ToString($h.ComputeHash([Text.Encoding]::UTF8.GetBytes($text)))).Replace('-','').ToLowerInvariant()}finally{$h.Dispose()}}
function Running([string]$name){$m=$null;try{$m=[Threading.Mutex]::OpenExisting($name);return $true}catch [Threading.WaitHandleCannotBeOpenedException]{return $false}catch [UnauthorizedAccessException]{return $true}finally{if($m){$m.Dispose()}}}
function Write-WindowBytes([string]$path,[byte[]]$bytes){
 $temp=$path+'.'+[guid]::NewGuid().ToString('N')+'.tmp'
 try{[IO.File]::WriteAllBytes($temp,$bytes);if([IO.File]::Exists($path)){[IO.File]::Replace($temp,$path,[Management.Automation.Language.NullString]::Value)}else{[IO.File]::Move($temp,$path)}}finally{if([IO.File]::Exists($temp)){[IO.File]::Delete($temp)}}
}
try{
 if(!(Test-Path -LiteralPath $launcher)){throw 'AVATA_INSTALLATION_MISSING'}
 $settings=Get-Content -LiteralPath (Join-Path $hostRoot 'settings.json') -Raw | ConvertFrom-Json
 $active=Get-Content -LiteralPath (Join-Path $hostRoot 'active.json') -Raw | ConvertFrom-Json
 if($settings.Schema -cne 'AT58-HOST-1' -or !$settings.Enabled -or $settings.FeedUrl -cne 'https://github.com/crosnuu12/Avata-kor-releases/releases/latest/download/avata-update.json'){throw 'AVATA_UPDATE_SETTINGS_CHECK'}
 $data=[IO.Path]::GetFullPath([string]$settings.DataRoot)
 $manage=[IO.Path]::GetFullPath([string]$settings.ManagementRoot)
 foreach($path in @($data,$manage)){
  if(!$path.StartsWith(($profileRoot.TrimEnd('\')+'\'),[StringComparison]::OrdinalIgnoreCase) -or ![IO.Directory]::Exists($path)){throw 'AVATA_INSTALLATION_PATH'}
 }
 $running=(Running ('Local\esbada-AT-host-'+(Key $hostRoot.ToLowerInvariant()).Substring(0,24))) -or (Running ('Local\esbada-AT-manager-'+(Key $manage.ToLowerInvariant()).Substring(0,24))) -or (Running ('Local\esbada-AT-direct-'+(Key $data.ToLowerInvariant()).Substring(0,24)))
 if($Inspect){[pscustomobject]@{InstalledVersion=$active.Version;AutomaticUpdate=$true;TargetProduct='1.1.1';WindowMode='DESKTOP';Running=$running;Changes='Window preferences only; trading features retained'}|ConvertTo-Json -Compress;exit 0}
 if($running){throw 'AVATA_CLOSE_FIRST'}
 $pref=Join-Path $data 'window-preferences.json'
 $before=if([IO.File]::Exists($pref)){[IO.File]::ReadAllBytes($pref)}else{$null}
 $bytes=[Text.Encoding]::UTF8.GetBytes('{"Schema":"AT-WINDOW-2","UseTray":false,"StartInTray":false}')
 Write-WindowBytes $pref $bytes
 try{
  # User-invoked main-PC launch: the requested desktop UI is intentionally visible.
  Start-Process -FilePath $launcher -WorkingDirectory ([IO.Path]::GetDirectoryName($launcher)) -WindowStyle Normal
 }catch{if($null -ne $before){Write-WindowBytes $pref $before}else{[IO.File]::Delete($pref)};throw}
 Write-Output 'Desktop mode saved. Avata is starting and checking for the latest update.'
 Write-Output 'Both manual live start and optional automatic live start remain available.'
}catch{
 $code=$_.Exception.Message
 if($code -cnotmatch '^[A-Z][A-Z0-9_]{1,70}$'){$code='MAIN_PC_START_FAILED'}
 Write-Output ('Could not complete: '+$code)
 if($code -ceq 'AVATA_CLOSE_FIRST'){Write-Output 'Close Avata normally, then run this file again.'}
 exit 1
}
