﻿param([string]$RemoteHostRoot='')
# HTTPS releases require the pinned publisher signature.
function Up-Files {

 return @('At58.Manager.ps1','At58.Ops.ps1','At58.Repair.ps1','At58.Telegram.ps1',

 'At58.Sheets.ps1','At58.SheetsJwt.ps1','At58.SheetWorker.ps1',

 'payload/At58.Core.ps1','payload/At58.Log.ps1','payload/esbada_Merits_AT_v58.ps1',

 'payload/Test-AT58.ps1','payload/Test-AT58LogViewer.ps1')

}

function Up-HostFailure($errorRecord){
 $e=$errorRecord.Exception
 while($e -and $e.InnerException){$e=$e.InnerException}
 $type=if($e){$e.GetType().FullName}else{'Unknown'}
 if($type -cnotmatch '^[A-Za-z0-9_.]{1,120}$'){$type='Unknown'}
 # Do not include exception messages, paths, arguments, account details or API bodies.
 return @{Schema='AVATA-HOST-ERROR-1';Utc=(Ops-Now).ToString('o');Code=(Up-Code $errorRecord);ExceptionType=$type;HResult=$(if($e){$e.HResult}else{0});Line=[int]$errorRecord.InvocationInfo.ScriptLineNumber}
}

function Up-WriteHostFailure([string]$manage,[string]$version,[string]$session,$errorRecord){
 $d=Up-HostFailure $errorRecord
 $kind=($d.ExceptionType -split '\.')[-1].ToUpperInvariant()
 $stage='HOST_'+$kind+'_L'+$d.Line+'_WIN32_'+($d.HResult -band 65535)
 if($stage -cnotmatch '^[A-Z0-9_]{1,100}$'){$stage='HOST_EXCEPTION'}
 Ops-WriteJson (Join-Path $manage 'bundle-status.json') @{Utc=$d.Utc;State='HOST_ERROR';Version=$version;HostSession=$session;Code=$d.Code;Stage=$stage}
}

function Up-Code($failure){$code=[string]$failure.Exception.Message;if($code -cnotmatch '^[A-Z][A-Z0-9_]{1,70}$'){$code='BUNDLE_ERROR'};return $code}

function Up-Version([string]$v){if($v -cnotmatch '^58\.[0-9]{1,4}\.[0-9]{1,4}$'){throw 'BUNDLE_VERSION'};return [version]$v}

function Up-Validate([string]$folder,[string]$manifestHash){

 if($manifestHash -cnotmatch '^[a-f0-9]{64}$'){throw 'BUNDLE_MANIFEST_HASH'}

 $manifestPath=Ops-Inside $folder (Join-Path $folder 'release.json')

 if((Ops-Hash $manifestPath) -cne $manifestHash){throw 'BUNDLE_MANIFEST_CHANGED'}

 $m=Ops-ReadJson $manifestPath

 if(!$m -or $m.Schema -cne 'AT58-BUNDLE-1' -or !(($m.Mode -ceq 'READ_ONLY' -and $m.HostProtocol -eq 1) -or ($m.Mode -ceq 'CONTROLLED_LIVE' -and $m.HostProtocol -eq 2))){throw 'BUNDLE_SCHEMA'}

 $null=Up-Version $m.Version

 if($m.Id -cnotmatch '^bundle-[a-f0-9]{24}$'){throw 'BUNDLE_ID'}

 $expected=@(Up-Files);$seen=@{};$length=0

 foreach($file in $m.Files){

  $name=[string]$file.Name

  if($name -cnotin $expected -or $seen.ContainsKey($name)){throw 'BUNDLE_FILE_LIST'}

  $seen[$name]=$true;$p=Ops-Inside $folder (Join-Path $folder $name)

  if(![IO.File]::Exists($p) -or $file.Hash -cnotmatch '^[a-f0-9]{64}$' -or (Ops-Hash $p) -cne $file.Hash){throw 'BUNDLE_FILE_HASH'}

  $size=(Get-Item -LiteralPath $p).Length;$length+=$size

  if($size -ne [long]$file.Size -or $size -gt 5000000 -or $length -gt 25000000){throw 'BUNDLE_FILE_SIZE'}

  $tokens=$null;$errors=$null;$null=[Management.Automation.Language.Parser]::ParseFile($p,[ref]$tokens,[ref]$errors)

  if($errors.Count){throw 'BUNDLE_SYNTAX'}

 }

 if($seen.Count -ne $expected.Count){throw 'BUNDLE_FILE_LIST'}

 # Fail closed on extra executable files or links, including nested directories.

 foreach($container in @($folder,(Join-Path $folder 'payload'))){

  foreach($f in Get-ChildItem -LiteralPath $container -Force){

   $null=Ops-Inside $folder $f.FullName

   $rel=$f.FullName.Substring($folder.TrimEnd('\').Length+1).Replace('\','/')

   if($f.PSIsContainer){if($rel -cne 'payload'){throw 'BUNDLE_EXTRA_DIRECTORY'}}elseif($rel -cne 'release.json' -and $rel -cnotin $expected){throw 'BUNDLE_EXTRA_FILE'}

  }

 }

 return $m

}

function Up-Offer([string]$channel){

 $path=Ops-Inside $channel (Join-Path $channel 'ready.json')

 if(![IO.File]::Exists($path)){return $null}

 $o=Ops-ReadJson $path

 if(!$o -or $o.Schema -cne 'AT58-OFFER-1' -or $o.Id -cnotmatch '^bundle-[a-f0-9]{24}$' -or $o.ManifestHash -cnotmatch '^[a-f0-9]{64}$'){throw 'BUNDLE_OFFER'}

 $null=Up-Version $o.Version

 $folder=Ops-Inside $channel (Join-Path $channel ('releases\'+$o.Id))

 $m=Up-Validate $folder $o.ManifestHash

 if($m.Id -cne $o.Id -or $m.Version -cne $o.Version){throw 'BUNDLE_OFFER_MISMATCH'}

 return [pscustomobject]@{Id=$m.Id;Version=$m.Version;ManifestHash=$o.ManifestHash;Folder=$folder}

}

function Up-Stage([string]$hostRoot,$offer){

 $dest=Ops-Inside $hostRoot (Join-Path $hostRoot ('bundles\'+$offer.Id))

 if([IO.Directory]::Exists($dest)){$null=Up-Validate $dest $offer.ManifestHash;return $dest}

 $temporary=Ops-Inside $hostRoot (Join-Path $hostRoot ('staging\'+[guid]::NewGuid().ToString('N')))

 [void][IO.Directory]::CreateDirectory($temporary)

 foreach($name in @('release.json')+@(Up-Files)){$target=Ops-Inside $temporary (Join-Path $temporary $name);[void][IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($target));Copy-Item -LiteralPath (Ops-Inside $offer.Folder (Join-Path $offer.Folder $name)) -Destination $target}

 $null=Up-Validate $temporary $offer.ManifestHash

 [void][IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($dest));[IO.Directory]::Move($temporary,$dest)

 return $dest

}

function Up-SnapshotPointer([string]$root){

 $saved=@{}

 foreach($n in @('active.json','transaction.json')){$p=Join-Path $root $n;$saved[$n]=if([IO.File]::Exists($p)){[IO.File]::ReadAllText($p,[Text.Encoding]::UTF8)}else{$null}}

 return $saved

}

function Up-RestorePointer([string]$root,$saved){

 foreach($n in @('active.json','transaction.json')){

  $value=if($saved -is [Collections.IDictionary]){$saved[$n]}else{Ops-Get $saved $n}

  $p=Ops-Inside $root (Join-Path $root $n)

  if($null -eq $value){if([IO.File]::Exists($p)){[IO.File]::Delete($p)}}else{Ops-WriteJson $p ($value|ConvertFrom-Json)}

 }

}

function Up-NewTrial($previous,$candidate,[string]$root,[bool]$desired){

 return [pscustomobject]@{Schema='AT58-TRIAL-1';Phase='PENDING';Previous=$previous;Candidate=$candidate;PreviousPointer=(Up-SnapshotPointer $root);DesiredRunning=$desired;Utc=(Ops-Now).ToString('o')}

}

function Up-NewProbe {return [pscustomobject]@{RunId='';Sequence=0;Consecutive=0}}

function Up-Observe($probe,$manager,$runtime,$status,[string]$session,[datetime]$started,[datetime]$now){

 if(!$manager -or (Ops-Get $manager 'HostSession') -cne $session){return 'WAIT'}

 try{$age=($now-(Ops-Utc $manager.Utc)).TotalSeconds}catch{return 'WAIT'}

 if($age -lt -5 -or $age -gt 15){return 'WAIT'}

 $id=[string](Ops-Get $manager 'RunId' '')

 if(!$runtime -or $runtime.RunId -cne $id){return 'WAIT'}

 try{$age=($now-(Ops-Utc $runtime.Utc)).TotalSeconds}catch{return 'WAIT'}

 if($age -lt -5 -or $age -gt 15){return 'WAIT'}

 if((Ops-Get $runtime 'HostProtocol' 1) -eq 2 -and ((Ops-Get $runtime 'LiveMode' '') -ceq 'LIVE' -or (Ops-Get $status 'Live'))){

  if($runtime.ExitReason -ceq 'USER_CLOSE'){return 'CLOSED'}

  $maintenance=Ops-LiveMaintenance $runtime $status $id $now

  if($maintenance -cne 'QUIESCENT'){return 'LIVE_HOLD'}

  if(!$runtime.DesiredRunning){return 'PAUSED'}

  return 'READY'

 }

 if((Ops-Get $runtime 'ExecutionEnabled' $true) -ne $false){return 'UNSAFE'}

 if($runtime.ExitReason -ceq 'USER_CLOSE'){return 'CLOSED'}

 if(!$runtime.DesiredRunning){$probe.Consecutive=0;return 'PAUSED'}

 if(!$status -or $status.RunId -cne $id){return 'WAIT'}

 if((Ops-Get $status 'ExecutionEnabled' $true) -ne $false -or (Ops-Get $status 'OrdersSent' -1) -ne 0){return 'UNSAFE'}

 try{$age=($now-(Ops-Utc $status.Utc)).TotalSeconds;if((Ops-Utc $status.Utc) -le $started){return 'WAIT'}}catch{return 'WAIT'}

 if($age -lt -5 -or $age -gt 90){return 'WAIT'}

 if($status.Code -cne 'OK' -or (Ops-Get $status 'Failures' -1) -ne 0){$probe.Consecutive=0;return 'ERROR'}

 $seq=[int](Ops-Get $status 'Sequence' 0)

 if($seq -le 0){return 'WAIT'}

 if($probe.RunId -cne $id){$probe.RunId=$id;$probe.Sequence=0;$probe.Consecutive=0}

 if($seq -lt $probe.Sequence){$probe.Consecutive=0}

 if($seq -ne $probe.Sequence){$probe.Consecutive++;$probe.Sequence=$seq}

 if($probe.Consecutive -ge 3){return 'READY'}

 return 'CHECKING'

}

function Up-WriteStatus([string]$manage,[string]$state,[string]$version,[string]$session,[string]$code=''){

 Ops-WriteJson (Join-Path $manage 'bundle-status.json') @{Utc=(Ops-Now).ToString('o');State=$state;Version=$version;HostSession=$session;Code=$code}

}

function Up-Notify([string]$manage,[string]$code,[string]$version){

 # Receiver and credentials remain in the existing program; only known event codes enter its queue.

 Ops-WriteJson (Join-Path $manage 'bundle-event.json') @{Id=[guid]::NewGuid().ToString('N');Code=$code;Version=$version}

}

function Up-WaitManagerFree([string]$manage,[int]$seconds=40){

 $until=(Ops-Now).AddSeconds($seconds)

 do{$lock=$null;try{$lock=[Threading.Mutex]::OpenExisting('Local\esbada-AT-manager-'+(Ops-Key $manage.ToLowerInvariant()).Substring(0,24))}catch [Threading.WaitHandleCannotBeOpenedException]{}catch{throw 'BUNDLE_MANAGER_STILL_RUNNING'}

  if(!$lock){return};$lock.Dispose();Start-Sleep -Milliseconds 250

 }while((Ops-Now) -lt $until)

 throw 'BUNDLE_MANAGER_STILL_RUNNING'

}

function Up-StopManager($job,[string]$manage,[string]$session){

 Ops-WriteJson (Join-Path $manage 'bundle-control.json') @{Session=$session;Action='STOP'}

 if($job -and !$job.Process.HasExited){if(!$job.Process.WaitForExit(40000)){throw 'BUNDLE_STOP_TIMEOUT'}}

 Up-WaitManagerFree $manage

}


function Up-PublicKey { return '<RSAKeyValue><Modulus>tolWc0YzKf5o5dRSppcS1r0og00QsGFj2DCss8qV0wHTinpHWnrviiQfc8z254s0S6Jn7siWqPI4jm/DLo+7sDX3vK+aA2UZ1W96QaI14wlvU5MRhMomsr/SbkDMhpginH68kztvftQLxt8KFlwE6MBYIfRCinV11R7P6CJXl3+KjteEOPTJN2HBDDSPYnrj0+RdCOsJi/hFzLiJdUMjDrWF5GvojxM3kz6QKvqHrxwlWvkjrdGC6C4gLcMETuvFzSKW+6+fU6cnXyCnlZSHc3ox60+uUIFeHNBwN4NKaChWRBNa7Eq/eAXdi/vYssDc0gOElAPpPGqN3bEbKv7EC7nAbX0l0fBWyjaEkbKGyQX9riyy3RZmT58vvzCLGTke3GvjWmWvPXXKu6EFE/xJ8tlSTYgpmsAGFquoDGxt4aRmIeHdA2CUsWpSCOTJ+dqx7eN6ygvw0VS/XIO6cWY/in4Z+tNllfHg7QdorFu2nHTtkpA5hIYU4+0Xzf9LPB01</Modulus><Exponent>AQAB</Exponent></RSAKeyValue>' }
function Up-Https([string]$url){
 $u=$null
 if(![uri]::TryCreate($url,[UriKind]::Absolute,[ref]$u) -or $u.Scheme -cne 'https' -or $u.UserInfo -or $u.Fragment -or $u.IsLoopback){throw 'UPDATE_HTTPS_REQUIRED'}
 return $u
}
function Up-Download([string]$url,[string]$path,[long]$limit){
 $uri=Up-Https $url;$deadline=(Ops-Now).AddSeconds(45)
 [Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12
 for($redirect=0;$redirect -le 5;$redirect++){
  if((Ops-Now) -gt $deadline){throw 'UPDATE_DOWNLOAD_TIMEOUT'}
  $request=[Net.HttpWebRequest]::Create($uri);$request.Method='GET';$request.AllowAutoRedirect=$false;$request.Timeout=10000;$request.ReadWriteTimeout=10000;$request.UserAgent='Avata-kor-updater/1';$request.UseDefaultCredentials=$false
  $response=$null;$input=$null;$output=$null
  try{
   $response=$request.GetResponse();$status=[int]$response.StatusCode
   if($status -in @(301,302,303,307,308)){
    $location=[string]$response.Headers['Location'];if(!$location){throw 'UPDATE_REDIRECT'}
    $uri=Up-Https ([uri]::new($uri,$location).AbsoluteUri);continue
   }
   if($status -ne 200){throw 'UPDATE_HTTP_STATUS'}
   if($response.ContentLength -gt $limit){throw 'UPDATE_DOWNLOAD_SIZE'}
   $input=$response.GetResponseStream();$output=[IO.File]::Open($path,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::None);$buffer=New-Object byte[] 65536;$total=0
   while(($n=$input.Read($buffer,0,$buffer.Length)) -gt 0){$total+=$n;if($total -gt $limit){throw 'UPDATE_DOWNLOAD_SIZE'};if((Ops-Now) -gt $deadline){throw 'UPDATE_DOWNLOAD_TIMEOUT'};$output.Write($buffer,0,$n)}
   return
  }finally{if($output){$output.Dispose()};if($input){$input.Dispose()};if($response){$response.Dispose()};$request.Abort()}
 }
 throw 'UPDATE_REDIRECT_LIMIT'
}
function Up-Envelope([string]$path){
 if(![IO.File]::Exists($path) -or (Get-Item -LiteralPath $path).Length -gt 65536){throw 'UPDATE_MANIFEST_SIZE'}
 $e=Ops-ReadJson $path
 if(!$e -or $e.Schema -cne 'AVATA-UPDATE-SIGNED-1'){throw 'UPDATE_MANIFEST_SCHEMA'}
 try{$bytes=[Convert]::FromBase64String([string]$e.Payload);$signature=[Convert]::FromBase64String([string]$e.Signature)}catch{throw 'UPDATE_SIGNATURE'}
 if($bytes.Length -gt 16384 -or $signature.Length -ne 384){throw 'UPDATE_SIGNATURE'}
 $rsa=[Security.Cryptography.RSACryptoServiceProvider]::new();$rsa.PersistKeyInCsp=$false
 try{$rsa.FromXmlString((Up-PublicKey));if(!$rsa.VerifyData($bytes,'SHA256',$signature)){throw 'UPDATE_SIGNATURE'}}finally{$rsa.Dispose()}
 try{$m=([Text.UTF8Encoding]::new($false,$true).GetString($bytes)|ConvertFrom-Json)}catch{throw 'UPDATE_MANIFEST_SCHEMA'}
 if($m.Schema -cne 'AVATA-UPDATE-1' -or $m.App -cne 'Avata_kor' -or $m.Id -cnotmatch '^bundle-[a-f0-9]{24}$' -or $m.ManifestHash -cnotmatch '^[a-f0-9]{64}$' -or $m.PackageSha256 -cnotmatch '^[a-f0-9]{64}$'){throw 'UPDATE_MANIFEST_SCHEMA'}
 $null=Up-Version $m.Version;$null=Up-Https $m.PackageUrl
 if($m.PackageBytes -isnot [long] -and $m.PackageBytes -isnot [int]){throw 'UPDATE_PACKAGE_SIZE'}
 if($m.PackageBytes -lt 1 -or $m.PackageBytes -gt 25000000){throw 'UPDATE_PACKAGE_SIZE'}
 try{$published=Ops-Utc $m.PublishedUtc}catch{throw 'UPDATE_MANIFEST_DATE'}
 if($published -gt (Ops-Now).AddMinutes(10)){throw 'UPDATE_MANIFEST_DATE'}
 return $m
}
function Up-Extract([string]$zipPath,[string]$destination,$m){
 if((Get-Item -LiteralPath $zipPath).Length -ne $m.PackageBytes -or (Ops-Hash $zipPath) -cne $m.PackageSha256){throw 'UPDATE_PACKAGE_HASH'}
 Add-Type -AssemblyName System.IO.Compression;Add-Type -AssemblyName System.IO.Compression.FileSystem
 $zip=[IO.Compression.ZipFile]::OpenRead($zipPath);$seen=@{};$total=0
 try{
  foreach($entry in $zip.Entries){
   $name=$entry.FullName
   if($name -cnotin (@('release.json')+@(Up-Files)) -or $seen.ContainsKey($name)){throw 'UPDATE_ARCHIVE_PATH'}
   $seen[$name]=$true;$total+=$entry.Length
   if($entry.Length -gt 5000000 -or $total -gt 25000000){throw 'UPDATE_ARCHIVE_SIZE'}
  }
  if($seen.Count -ne (1+@(Up-Files).Count)){throw 'UPDATE_ARCHIVE_INCOMPLETE'}
  foreach($entry in $zip.Entries){
   $target=Ops-Inside $destination (Join-Path $destination $entry.FullName);[void][IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($target))
   [IO.Compression.ZipFileExtensions]::ExtractToFile($entry,$target,$false)
  }
 }finally{$zip.Dispose()}
 $bundle=Up-Validate $destination $m.ManifestHash
 if($bundle.Id -cne $m.Id -or $bundle.Version -cne $m.Version -or $bundle.HostProtocol -ne 2){throw 'UPDATE_PACKAGE_IDENTITY'}
}
function Up-RemoteRefresh([string]$root){
 $config=Ops-ReadJson (Join-Path $root 'settings.json');$feed=[string](Ops-Get $config 'FeedUrl' '')
 if(!$config -or !$config.Enabled -or !$feed){return}
 $null=Up-Https $feed
 $channel=Ops-Inside $root (Join-Path $root 'remote-channel')
 $scratch=Ops-Inside $root (Join-Path $root ('downloads\'+[guid]::NewGuid().ToString('N')));[void][IO.Directory]::CreateDirectory($scratch)
 $result=@{Schema='AVATA-REMOTE-1';Utc=(Ops-Now).ToString('o');State='CHECK_FAILED';Version='';Code='UPDATE_NETWORK'}
 try{
  $manifestPath=Join-Path $scratch 'avata-update.json';Up-Download $feed $manifestPath 65536;$m=Up-Envelope $manifestPath
  $active=Ops-ReadJson (Join-Path $root 'active.json');$cached=Up-Offer $channel
  foreach($previous in @($active,$cached)){
   if($previous -and (Up-Version $m.Version) -lt (Up-Version $previous.Version)){throw 'UPDATE_DOWNGRADE'}
   if($previous -and $m.Version -ceq $previous.Version -and ($m.Id -cne $previous.Id -or $m.ManifestHash -cne $previous.ManifestHash)){throw 'UPDATE_VERSION_REUSED'}
  }
  if(!$active -or $m.Id -cne $active.Id){
   if(!$cached -or $cached.Id -cne $m.Id){
    $archive=Join-Path $scratch 'release.zip';Up-Download $m.PackageUrl $archive 25000000
    $expanded=Join-Path $scratch 'expanded';Up-Extract $archive $expanded $m
    $dest=Ops-Inside $channel (Join-Path $channel ('releases\'+$m.Id));[void][IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($dest))
    if([IO.Directory]::Exists($dest)){$null=Up-Validate $dest $m.ManifestHash}else{[IO.Directory]::Move($expanded,$dest)}
    Ops-WriteJson (Join-Path $channel 'ready.json') @{Schema='AT58-OFFER-1';Id=$m.Id;Version=$m.Version;ManifestHash=$m.ManifestHash}
   }
  }
  $result.State='CHECKED';$result.Version=$m.Version;$result.Code=''
 }catch{$result.Code=Up-Code $_}finally{
  $result.Utc=(Ops-Now).ToString('o');Ops-WriteJson (Join-Path $root 'remote-status.json') $result
  $safe=Ops-Inside $root $scratch;if([IO.Directory]::Exists($safe)){Remove-Item -LiteralPath $safe -Recurse -Force}
 }
 return [pscustomobject]$result
}
function Up-ApplyRequest($request,$offer,[string]$session,[string]$runId,[datetime]$now){
 if(!$request -or !$offer -or $request.Schema -cne 'AVATA-UPDATE-REQUEST-1' -or $request.Action -cne 'APPLY' -or $request.HostSession -cne $session -or $request.RunId -cne $runId -or $request.Id -cne $offer.Id -or $request.ManifestHash -cne $offer.ManifestHash){return $false}
 try{$age=($now-(Ops-Utc $request.Utc)).TotalSeconds}catch{return $false}
 return ($age -ge -5 -and $age -le 600)
}
function Up-UserStatus([string]$manage,[string]$session,[string]$runId,$active,$offer,[string]$state,[string]$code=''){
 Ops-WriteJson (Join-Path $manage 'update-status.json') @{Schema='AVATA-UPDATE-STATUS-1';Utc=(Ops-Now).ToString('o');HostSession=$session;RunId=$runId;Version=$active.Version;State=$state;Code=$code;Available=$offer}
}
function Up-AvailableState([bool]$enabled,$offer,[bool]$requested,[bool]$checking,[string]$feed,$remote,$active,[string]$rejected){
 if(!$enabled){return 'UNCONFIGURED'}
 if($offer){if($requested){return 'WAITING_FOR_ORDERS'};return 'AVAILABLE'}
 if($checking){return 'CHECKING'}
 if($rejected){return 'REJECTED'}
 if($feed){
  if(!$remote -or $remote.State -cne 'CHECKED'){return 'CHECK_FAILED'}
  if((Up-Version $remote.Version) -gt (Up-Version $active.Version)){return 'REJECTED'}
 }
 return 'CURRENT'
}
if($MyInvocation.InvocationName -ne '.' -and $RemoteHostRoot){
 . (Join-Path $PSScriptRoot 'At58.Ops.ps1')
 try{$null=Up-RemoteRefresh ([IO.Path]::GetFullPath($RemoteHostRoot));exit 0}catch{exit 1}
}
