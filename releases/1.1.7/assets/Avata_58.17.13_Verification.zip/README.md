# Avata 1.1.7 / 58.17.13

Bounded, change-aware Google Sheets publication with recoverable caches and lazy asset row growth.

See README_KO.md for behavior and limitations. Run Run-Checks.ps1 on Windows PowerShell 5.1, then Test-TrayRestore.ps1 -HostedRunner and Test-DesktopStartup.ps1. Tests use synthetic fixtures only.
