﻿function Convert-At58LogRecord([string]$line){

 try{

  $r=$line|ConvertFrom-Json

  if($r.Schema -cne 'AT-DIRECT-STATUS-1' -or $r.Source -cne 'MERITZ_DIRECT' -or $r.Version -cnotmatch '^\d+\.\d+$'){return $null}

  if($r.At -cnotmatch '^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$' -or $r.State -cnotin @('CLOSED','READ_OK','READ_ERROR','RETRY','STOPPED') -or $r.Code -cnotmatch '^[A-Z0-9_]{1,40}$'){return $null}

  if($r.Stage -cnotmatch '^[a-zA-Z0-9_/-]{1,100}$' -or [string]$r.ApiCode -cnotmatch '^(?:(?:EGW|IGW)[0-9]{5}|[0-9]{4,5}|[A-Z][A-Z0-9]{2,15})?$'){return $null}

  foreach($field in @('Failures','Calls','Sequence')){$n=0L;if(![long]::TryParse([string]$r.$field,[ref]$n) -or $n -lt 0){return $null}}

  $stamp=[datetime]::MinValue

  if(![datetime]::TryParse([string]$r.Utc,[Globalization.CultureInfo]::InvariantCulture,[Globalization.DateTimeStyles]::RoundtripKind,[ref]$stamp)){return $null}

  return $r

 }catch{return $null}

}

function Get-At58LogView([string]$root,[datetime]$utc=[datetime]::UtcNow){

 $kst=[TimeZoneInfo]::ConvertTimeBySystemTimeZoneId([datetime]::SpecifyKind($utc,[DateTimeKind]::Utc),'Korea Standard Time')

 $log=Join-Path $root ('read-'+$kst.ToString('yyyyMMdd')+'.jsonl')

 $status=$null;$rows=New-Object 'Collections.Generic.List[object]';$skipped=0;$age=$null;$stamp='';$io=$false

 try{

  $statusPath=Join-Path $root 'status.json'

  if([IO.File]::Exists($statusPath)){$status=Convert-At58LogRecord ([IO.File]::ReadAllText($statusPath,[Text.Encoding]::UTF8))}

  if([IO.File]::Exists($log)){

   $file=Get-Item -LiteralPath $log;$stamp=$file.Length.ToString()+'|'+$file.LastWriteTimeUtc.Ticks

   foreach($line in (Get-Content -LiteralPath $log -Encoding UTF8 -Tail 200)){

    if([string]::IsNullOrWhiteSpace($line)){continue}

    $r=Convert-At58LogRecord $line

    if($r){$rows.Add($r)}else{$skipped++}

   }

  }

  if($status){$age=[math]::Floor(($utc-([datetime]::Parse($status.Utc,$null,[Globalization.DateTimeStyles]::RoundtripKind)).ToUniversalTime()).TotalSeconds)}

 }catch{$io=$true}

 return [pscustomobject]@{Status=$status;Rows=$rows.ToArray();Skipped=$skipped;Age=$age;File=$log;Stamp=$stamp;IoError=$io;Day=$kst.ToString('yyyy-MM-dd')}

}



function New-At58LogPanel([string]$root){

 $panel=[Windows.Forms.TableLayoutPanel]::new();$panel.Dock='Fill';$panel.ColumnCount=1;$panel.RowCount=4

 foreach($h in @(32,28)){[void]$panel.RowStyles.Add([Windows.Forms.RowStyle]::new('Absolute',$h))}

 [void]$panel.RowStyles.Add([Windows.Forms.RowStyle]::new('Percent',100));[void]$panel.RowStyles.Add([Windows.Forms.RowStyle]::new('Absolute',24))

 $bar=[Windows.Forms.FlowLayoutPanel]::new();$bar.Dock='Fill';$bar.WrapContents=$false

 $title=[Windows.Forms.Label]::new();$title.Text='실시간 진단 로그';$title.AutoSize=$true;$title.Padding=[Windows.Forms.Padding]::new(0,5,10,0)

 $pause=[Windows.Forms.Button]::new();$pause.Text='로그 표시 일시정지';$pause.Width=155;$pause.Height=27

 $refresh=[Windows.Forms.Button]::new();$refresh.Text='새로고침';$refresh.Width=90;$refresh.Height=27

 $info=[Windows.Forms.Label]::new();$info.Text='오늘 최근 200건 · 1초마다 표시 갱신';$info.AutoSize=$true;$info.Padding=[Windows.Forms.Padding]::new(8,5,0,0)

 $bar.Controls.AddRange(@($title,$pause,$refresh,$info));$panel.Controls.Add($bar,0,0)

 $headline=[Windows.Forms.Label]::new();$headline.Dock='Fill';$headline.Text='AT58 기록 대기';$panel.Controls.Add($headline,0,1)

 $grid=[Windows.Forms.DataGridView]::new();$grid.Dock='Fill';$grid.ReadOnly=$true;$grid.AllowUserToAddRows=$false;$grid.AllowUserToDeleteRows=$false;$grid.RowHeadersVisible=$false;$grid.AutoSizeColumnsMode='Fill';$grid.BackgroundColor=[Drawing.Color]::White

 foreach($name in @('기록 시각(KST)','상태','진단 코드','API 코드','단계','실패 횟수','완료 횟수','요청 누적')){[void]$grid.Columns.Add($name,$name)}

 $grid.Columns[0].FillWeight=180;$grid.Columns[2].FillWeight=150;$grid.Columns[4].FillWeight=170;$panel.Controls.Add($grid,0,2)

 $foot=[Windows.Forms.Label]::new();$foot.Dock='Fill';$panel.Controls.Add($foot,0,3)

 $view=[pscustomobject]@{Root=$root;Panel=$panel;Headline=$headline;Grid=$grid;Foot=$foot;Pause=$pause;Refresh=$refresh;Paused=$false;Stamp='';Next=[datetime]::MinValue}

 $pause.Tag=$view;$refresh.Tag=$view

 $pause.Add_Click({

  $v=$this.Tag;$v.Paused=!$v.Paused;$this.Text=if($v.Paused){'로그 표시 재개'}else{'로그 표시 일시정지'}

  if($v.Paused){$v.Headline.Text='[로그 표시 일시정지] '+$v.Headline.Text}else{try{Update-At58LogPanel $v}catch{$v.Headline.Text='로그 읽기 대기'}}

 })

 $refresh.Add_Click({$v=$this.Tag;$v.Stamp='';try{Update-At58LogPanel $v}catch{$v.Headline.Text='로그 읽기 대기'}})

 try{Update-At58LogPanel $view}catch{$headline.Text='로그 읽기 대기'}

 return $view

}

function Update-At58LogPanel($view){

 $v=Get-At58LogView $view.Root

 $view.Foot.Text=$v.Day+' 기록 · 부분 기록·형식 불일치 제외 '+$v.Skipped+'건 · 로그 표시를 멈춰도 계좌 조회는 계속됩니다.'

 if($v.IoError){$view.Headline.Text='로그 파일 읽기 대기 · 다음 확인 때 다시 읽습니다.';$view.Headline.BackColor=[Drawing.Color]::LightGoldenrodYellow;return}

 if($v.Status){

  $r=$v.Status

  $view.Headline.Text='최근 기록 '+$r.At+' / '+$r.State+' / '+$r.Code+' / 실패 '+$r.Failures+'회 / '+$v.Age+'초 경과 / 실제 주문 전송 '+$r.OrdersSent+'건'

  $view.Headline.BackColor=if($r.Code -ne 'OK'){[Drawing.Color]::MistyRose}elseif($v.Age -gt 90 -or $v.Age -lt 0){[Drawing.Color]::LightGoldenrodYellow}else{[Drawing.Color]::Honeydew}

  if($v.Age -gt 90){$view.Headline.Text='기록 갱신 지연 또는 조회 정지 · '+$view.Headline.Text}

 }else{$view.Headline.Text='AT58 기록 대기 · 직접 조회를 시작하면 결과가 여기에 표시됩니다.';$view.Headline.BackColor=[Drawing.Color]::LightGoldenrodYellow}

 if($view.Paused){$view.Headline.Text='[로그 표시 일시정지] '+$view.Headline.Text}

 $key=$v.Day+'|'+$v.Stamp

 if($key -cne $view.Stamp){

  $view.Grid.Rows.Clear()

  foreach($r in $v.Rows){$index=$view.Grid.Rows.Add($r.At,$r.State,$r.Code,$r.ApiCode,$r.Stage,$r.Failures,$r.Sequence,$r.Calls);if($r.Code -ne 'OK'){$view.Grid.Rows[$index].DefaultCellStyle.BackColor=[Drawing.Color]::MistyRose}}

  if($view.Grid.Rows.Count){$view.Grid.FirstDisplayedScrollingRowIndex=$view.Grid.Rows.Count-1}

  $view.Stamp=$key

 }

}

