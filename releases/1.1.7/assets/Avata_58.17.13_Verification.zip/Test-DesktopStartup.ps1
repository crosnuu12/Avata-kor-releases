﻿param([string]$Root=$PSScriptRoot)
$ErrorActionPreference='Stop';Set-StrictMode -Version 2
if($env:GITHUB_ACTIONS -cne 'true' -or $env:RUNNER_ENVIRONMENT -cne 'github-hosted'){throw 'ISOLATED_HOSTED_WINDOWS_REQUIRED'}
. (Join-Path $Root 'bundle/At58.Ops.ps1')
$work=Join-Path ([IO.Path]::GetTempPath()) ('AvataDesktopTest-'+[guid]::NewGuid().ToString('N'))
$data=Join-Path $work 'data';$manage=Join-Path $work 'manage';$run=[guid]::NewGuid().ToString();$process=$null
[void][IO.Directory]::CreateDirectory($data);[void][IO.Directory]::CreateDirectory($manage)
try{
 Ops-WriteJson (Join-Path $data 'window-preferences.json') @{Schema='AT-WINDOW-2';UseTray=$false;StartInTray=$false}
 $exe=Join-Path $env:SystemRoot 'System32/WindowsPowerShell/v1.0/powershell.exe'
 $app=Join-Path $Root 'bundle/payload/esbada_Merits_AT_v58.ps1';$ops=Join-Path $Root 'bundle'
 $arguments=@('-NoProfile','-NonInteractive','-STA','-ExecutionPolicy','RemoteSigned','-File',('"'+$app+'"'),'-DataRoot',('"'+$data+'"'),'-ManagementRoot',('"'+$manage+'"'),'-OperationsRoot',('"'+$ops+'"'),'-HostProtocol','2','-RunId',$run)
 $process=Start-Process -FilePath $exe -ArgumentList $arguments -WindowStyle Hidden -PassThru -RedirectStandardOutput (Join-Path $work 'stdout.txt') -RedirectStandardError (Join-Path $work 'stderr.txt')
 $processHandle=$process.Handle
 $deadline=[datetime]::UtcNow.AddSeconds(30);$first='';$heartbeat=$false
 do{
  Start-Sleep -Milliseconds 250;$process.Refresh()
  if($process.HasExited){throw ('HIDDEN_STARTUP_EXIT: '+[IO.File]::ReadAllText((Join-Path $work 'stderr.txt')))}
  $runtime=Ops-ReadJson (Join-Path $manage 'runtime.json')
  if($runtime){
   if($runtime.RunId -cne $run -or $runtime.Fault -or $runtime.ExecutionEnabled -or $runtime.Running){throw 'HIDDEN_STARTUP_STATE'}
   if(!$first){$first=$runtime.Utc}elseif($runtime.Utc -cne $first){$heartbeat=$true;break}
  }
 }while([datetime]::UtcNow -lt $deadline)
 if(!$heartbeat){throw 'HIDDEN_STARTUP_NO_HEARTBEAT'}
 Write-Output 'PASS full desktop application starts and keeps its UI heartbeat running'
 $visibleDeadline=[datetime]::UtcNow.AddSeconds(10)
 do{$process.Refresh();if($process.MainWindowHandle -ne [IntPtr]::Zero){break};Start-Sleep -Milliseconds 100}while([datetime]::UtcNow -lt $visibleDeadline)
 if($process.MainWindowHandle -eq [IntPtr]::Zero){throw 'DESKTOP_STARTUP_WINDOW_MISSING'}
 Write-Output 'PASS full desktop application has a visible main window'
 if([IO.File]::Exists((Join-Path $data 'credentials.dpapi')) -or [IO.File]::Exists((Join-Path $data 'auto-start.dpapi'))){throw 'HIDDEN_STARTUP_UNEXPECTED_ACCOUNT'}
 Write-Output 'PASS idle desktop startup does not create credentials or auto-start consent'
 Ops-WriteJson (Join-Path $manage 'stop.request.json') @{RunId=$run;Action='RESTART'}
 if(!$process.WaitForExit(10000)){throw 'HIDDEN_STARTUP_CLOSE_TIMEOUT'}
 $process.Refresh()
 if($process.ExitCode -ne 0){throw ('HIDDEN_STARTUP_CLOSE_ERROR '+[string]$process.ExitCode+': '+[IO.File]::ReadAllText((Join-Path $work 'stderr.txt')))}
 Write-Output 'PASS managed restart closes desktop application without a foreground prompt'
 Write-Output 'DESKTOP STARTUP TESTS COMPLETE: 4 passed; no credentials or broker access.'
}finally{
 if($process){$process.Refresh();if(!$process.HasExited){$process.Kill();$process.WaitForExit()};$process.Dispose()}
 $safe=[IO.Path]::GetFullPath($work);$temp=[IO.Path]::GetFullPath([IO.Path]::GetTempPath()).TrimEnd('\')+'\'
 if(!$safe.StartsWith($temp,[StringComparison]::OrdinalIgnoreCase) -or [IO.Path]::GetFileName($safe) -cnotmatch '^AvataDesktopTest-[a-f0-9]{32}$'){throw 'TEST_CLEANUP_PATH'}
 if([IO.Directory]::Exists($safe)){Remove-Item -LiteralPath $safe -Recurse -Force}
}
