﻿#requires -Version 5.1
param([string]$Root,[string]$Data,[string]$Manage,[string]$Fixture)
$ErrorActionPreference='Stop'
# Only the isolated rollover fixture is accepted. No installed account paths.
$work=[IO.Path]::GetDirectoryName([IO.Path]::GetFullPath($Data))
if([IO.Path]::GetFileName($work) -cnotmatch '^AvataRolloverTest-[a-f0-9]{32}$' -or [IO.Path]::GetFullPath($Data) -ine (Join-Path $work 'data') -or [IO.Path]::GetFullPath($Manage) -ine (Join-Path $work 'manage') -or [IO.Path]::GetFullPath($Fixture) -ine (Join-Path $work 'fixture.json')){throw 'TEST_SCOPE_INVALID'}
$global:TestFixture=Get-Content -LiteralPath $Fixture -Raw -Encoding UTF8|ConvertFrom-Json
function global:Invoke-RestMethod {
 param($Method,$Uri,$Headers,$TimeoutSec,$MaximumRedirection,$ErrorAction,$ContentType,$Body)
 if([string]$Method -cne 'Get' -or !$Uri.StartsWith('https://sheets.googleapis.com/v4/spreadsheets/SYNTHETIC_SPREADSHEET_ONLY')){throw 'TEST_NETWORK_FORBIDDEN'}
 if($Uri.Contains('?fields=')){return $global:TestFixture.Meta}
 if($Uri.Contains('/values:batchGet?')){return $global:TestFixture.Rows}
 if($Uri.Contains('/values/')){return $global:TestFixture.Settings}
 throw 'TEST_NETWORK_FORBIDDEN'
}
& (Join-Path $Root 'bundle/At58.SheetWorker.ps1') -DataRoot $Data -ManagementRoot $Manage
exit $LASTEXITCODE
