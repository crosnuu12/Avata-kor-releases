﻿Add-Type -AssemblyName System.Security

function Tg-Protect([string]$value){$b=[Text.Encoding]::UTF8.GetBytes($value);try{return [Convert]::ToBase64String([Security.Cryptography.ProtectedData]::Protect($b,[Text.Encoding]::UTF8.GetBytes('AT58-TELEGRAM-1'),[Security.Cryptography.DataProtectionScope]::CurrentUser))}finally{[Array]::Clear($b,0,$b.Length)}}

function Tg-Load([string]$root){

 $b=$null

 try{$cipher=[IO.File]::ReadAllText((Join-Path $root 'telegram.dpapi'));$b=[Security.Cryptography.ProtectedData]::Unprotect([Convert]::FromBase64String($cipher),[Text.Encoding]::UTF8.GetBytes('AT58-TELEGRAM-1'),[Security.Cryptography.DataProtectionScope]::CurrentUser);return ([Text.Encoding]::UTF8.GetString($b)|ConvertFrom-Json)}catch{return $null}finally{if($b){[Array]::Clear($b,0,$b.Length)}}

}

function Tg-Save([string]$root,$config){

 [void][IO.Directory]::CreateDirectory($root);$path=Join-Path $root 'telegram.dpapi';$tmp=$path+'.tmp'

 try{[IO.File]::WriteAllText($tmp,(Tg-Protect ($config|ConvertTo-Json -Compress)),[Text.Encoding]::UTF8);if([IO.File]::Exists($path)){[IO.File]::Replace($tmp,$path,[Management.Automation.Language.NullString]::Value)}else{[IO.File]::Move($tmp,$path)}}finally{if([IO.File]::Exists($tmp)){[IO.File]::Delete($tmp)}}

}

function Tg-Call([string]$token,[string]$method,$body){

 if($token -cnotmatch '^[0-9]{5,20}:[A-Za-z0-9_-]{20,100}$' -or $method -cnotin @('getMe','getUpdates','getWebhookInfo','sendMessage')){throw 'TELEGRAM_INPUT'}

 [Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12

 try{$r=Invoke-RestMethod -Method Post -Uri ('https://api.telegram.org/bot'+$token+'/'+$method) -ContentType 'application/json; charset=utf-8' -Body ([Text.Encoding]::UTF8.GetBytes(($body|ConvertTo-Json -Depth 8 -Compress))) -TimeoutSec 8 -ErrorAction Stop;if(!$r.ok){throw 'TELEGRAM_RESPONSE'};return $r.result}catch{

  $retry=60;try{$raw=$_.ErrorDetails.Message|ConvertFrom-Json;$retry=[math]::Max(30,[math]::Min(3600,[int]$raw.parameters.retry_after))}catch{}

  $e=[InvalidOperationException]::new('TELEGRAM_SEND_FAILED');$e.Data['RetryAfter']=$retry;throw $e

 }

}

function Tg-PairCandidate($updates,[string]$nonce,[datetime]$created){

 $matches=@()

 foreach($u in $updates){$m=Ops-Get $u 'message';if(!$m){continue};$chat=Ops-Get $m 'chat';$from=Ops-Get $m 'from';if((Ops-Get $chat 'type') -cne 'private' -or (Ops-Get $m 'text') -cne ('/start '+$nonce)){continue}

  if([string](Ops-Get $chat 'id') -cne [string](Ops-Get $from 'id') -or (Ops-Get $from 'is_bot' $true)){continue}

  try{$at=[datetimeoffset]::FromUnixTimeSeconds([long]$m.date).UtcDateTime;if($at -lt $created.AddSeconds(-5) -or $at -gt $created.AddMinutes(10)){continue}}catch{continue}

  $matches+=[string]$chat.id

 }

 $ids=@($matches|Select-Object -Unique);if($ids.Count -gt 1){throw 'PAIR_AMBIGUOUS'};if($ids.Count -eq 1){return $ids[0]};return ''

}

function Tg-Notify($config,[string]$text){

 if(!$config -or !(Ops-Get $config 'Enabled' $false)){throw 'TELEGRAM_NOT_CONFIGURED'}

 if($text.Length -gt 1200){throw 'TELEGRAM_TOO_LONG'}

 $body=@{chat_id=$config.ChatId;text=$text;protect_content=$true;disable_notification=$false}

 $thread=[long](Ops-Get $config 'MessageThreadId' 0);if($thread -gt 0){$body.message_thread_id=$thread}

 $null=Tg-Call $config.Token 'sendMessage' $body

}

function Tg-OwnerId($config){

 $id=[string](Ops-Get $config 'OwnerUserId' '')

 if(!$id){$id=[string](Ops-Get $config 'ChatId' '')}

 if($id -cmatch '^[1-9][0-9]{0,15}$'){return $id};return ''

}

function Tg-GroupPairCandidate($updates,[string]$nonce,[datetime]$created,[string]$ownerId,[string]$botName){

 if($ownerId -cnotmatch '^[1-9][0-9]{0,15}$' -or $nonce -cnotmatch '^[a-f0-9]{32}$' -or $botName -cnotmatch '^[A-Za-z0-9_]{5,64}$'){throw 'PAIR_INPUT'}

 $candidates=@{}

 foreach($u in $updates){

  $m=Ops-Get $u 'message';if(!$m){continue};$chat=Ops-Get $m 'chat';$from=Ops-Get $m 'from'

  if((Ops-Get $chat 'type') -cnotin @('group','supergroup') -or [string](Ops-Get $chat 'id') -cnotmatch '^-[1-9][0-9]{0,15}$'){continue}

  if([string](Ops-Get $from 'id') -cne $ownerId -or (Ops-Get $from 'is_bot' $true) -or (Ops-Get $m 'sender_chat') -or (Ops-Get $m 'forward_origin') -or (Ops-Get $m 'forward_date')){continue}

  # An explicitly addressed command works with Telegram's default privacy mode.

  $command=[string](Ops-Get $m 'text');$expected='/start@'+$botName+' '+$nonce

  if(![string]::Equals($command,$expected,[StringComparison]::OrdinalIgnoreCase)){continue}

  try{$at=[datetimeoffset]::FromUnixTimeSeconds([long]$m.date).UtcDateTime;if($at -lt $created.AddSeconds(-5) -or $at -gt $created.AddMinutes(10)){continue}}catch{continue}

  $thread=[long](Ops-Get $m 'message_thread_id' 0);if($thread -lt 0){continue}

  $id=[string]$chat.id;$key=$id+':'+$thread

  $title=([string](Ops-Get $chat 'title' '단톡방') -replace '[\x00-\x1f\x7f]',' ');if($title.Length -gt 100){$title=$title.Substring(0,100)}

  $candidates[$key]=[pscustomobject]@{ChatId=$id;ChatType=[string]$chat.type;ChatTitle=$title;MessageThreadId=$thread}

 }

 if($candidates.Count -gt 1){throw 'PAIR_AMBIGUOUS'}

 if($candidates.Count -eq 1){return @($candidates.Values)[0]};return $null

}

function Tg-PreparePair([string]$root,[string]$token,[string]$mode){

 if($mode -cnotin @('private','group')){throw 'PAIR_INPUT'}

 $owner=''

 if($mode -ceq 'group'){

  $saved=Tg-Load $root;$owner=Tg-OwnerId $saved

  if(!$owner -or !$saved -or $saved.Token -cne $token){throw 'PRIVATE_PAIR_REQUIRED'}

 }

 $me=Tg-Call $token 'getMe' @{};$web=Tg-Call $token 'getWebhookInfo' @{}

 if($web.url){throw 'WEBHOOK_IN_USE'}

 if(!$me.is_bot -or $me.username -cnotmatch '^[A-Za-z0-9_]{5,64}$'){throw 'BOT_IDENTITY'}

 if($mode -ceq 'group' -and (Ops-Get $me 'can_join_groups' $true) -eq $false){throw 'GROUPS_DISABLED'}

 $nonce=[guid]::NewGuid().ToString('N');$parameter=if($mode -ceq 'group'){'startgroup'}else{'start'}

 $command=if($mode -ceq 'group'){'/start@'+$me.username+' '+$nonce}else{'/start '+$nonce}

 return [pscustomobject]@{Token=$token;Mode=$mode;OwnerId=$owner;BotName=[string]$me.username;Nonce=$nonce;Created=(Ops-Now);Link=('https://t.me/'+$me.username+'?'+$parameter+'='+$nonce);Command=$command;Offset=$null;Updates=@()}

}

function Tg-ReadPairUpdates($pair){

 $body=@{timeout=0;limit=100;allowed_updates=@('message')};if($null -ne $pair.Offset){$body.offset=$pair.Offset}

 $batch=@(Tg-Call $pair.Token 'getUpdates' $body)

 $pair.Updates=@($pair.Updates)+$batch

 if($pair.Updates.Count -gt 3000){throw 'PAIR_TOO_MANY'}

 if($batch.Count){$ids=@($batch|ForEach-Object {Ops-Get $_ 'update_id'}|Where-Object {$null -ne $_});if($ids.Count){$pair.Offset=[long]($ids|Measure-Object -Maximum).Maximum+1}}

 # One bounded request per click keeps the UI heartbeat responsive. Retain all

 # candidates until the queue is drained so two matching groups fail closed.

 if($batch.Count -eq 100){throw 'PAIR_MORE_UPDATES'}

 return $pair.Updates

}

function Tg-CompletePair([string]$root,$pair,[bool]$autoRepair,[string]$codexPath){

 if(!$pair){throw 'PAIR_REQUIRED'}

 $age=((Ops-Now)-$pair.Created).TotalSeconds;if($age -lt -5 -or $age -gt 600){throw 'PAIR_EXPIRED'}

 if($autoRepair -and ![IO.File]::Exists($codexPath)){throw 'CODEX_MISSING'}

 if($pair.Mode -ceq 'group'){

  $saved=Tg-Load $root

  if(!$saved -or $saved.Token -cne $pair.Token -or (Tg-OwnerId $saved) -cne $pair.OwnerId){throw 'PRIVATE_PAIR_REQUIRED'}

 }

 $updates=@(Tg-ReadPairUpdates $pair)

 if($pair.Mode -ceq 'group'){

  $candidate=Tg-GroupPairCandidate $updates $pair.Nonce $pair.Created $pair.OwnerId $pair.BotName

  if(!$candidate){throw 'PAIR_NOT_FOUND'};$owner=$pair.OwnerId

 }else{

  $id=Tg-PairCandidate $updates $pair.Nonce $pair.Created;if(!$id){throw 'PAIR_NOT_FOUND'}

  $owner=$id;$candidate=[pscustomobject]@{ChatId=$id;ChatType='private';ChatTitle='개인 채팅';MessageThreadId=0}

 }

 $config=[pscustomobject]@{Enabled=$true;Token=$pair.Token;ChatId=$candidate.ChatId;ChatType=$candidate.ChatType;ChatTitle=$candidate.ChatTitle;MessageThreadId=$candidate.MessageThreadId;OwnerUserId=$owner;PrivateChatId=$owner;BotUsername=$pair.BotName;AutoRepair=$autoRepair;CodexPath=$codexPath}

 Tg-Notify $config '[AT58] 알림 수신 테스트입니다. PC에서 저장 완료 표시를 확인하세요. 저장 후 이 대화로 장애·복구·업데이트 결과를 보냅니다.'

 Tg-Save $root $config

 return $config

}

function Tg-UsePrivate([string]$root){

 $saved=Tg-Load $root;$owner=Tg-OwnerId $saved;if(!$saved -or !$owner){throw 'PRIVATE_PAIR_REQUIRED'}

 $config=$saved|ConvertTo-Json -Depth 8|ConvertFrom-Json

 foreach($entry in @{Enabled=$true;ChatId=$owner;ChatType='private';ChatTitle='개인 채팅';MessageThreadId=0;OwnerUserId=$owner;PrivateChatId=$owner}.GetEnumerator()){$config|Add-Member NoteProperty $entry.Key $entry.Value -Force}

 Tg-Notify $config '[AT58] 개인 알림 복귀 테스트입니다. PC에서 저장 완료 표시를 확인하세요.'

 Tg-Save $root $config;return $config

}

function Tg-ConnectionLabel($config){

 if(!$config){return '현재 수신처: 연결 안 됨'}

 $kind=if([string]$config.ChatId -like '-*'){'단톡방'}else{'개인 채팅'}

 $title=[string](Ops-Get $config 'ChatTitle' '');$status=if($config.Enabled){'사용 중'}else{'꺼짐'}

 return ('현재 수신처: '+$kind+$(if($title -and $title -ne $kind){' · '+$title}else{''})+' ('+$status+')')

}

function Tg-PairError([string]$code){

 switch($code){

  'PRIVATE_PAIR_REQUIRED' {return '먼저 같은 봇으로 개인 채팅을 연결·저장하세요. 단톡방 연결은 확인된 본인 계정만 할 수 있습니다.'}

  'GROUPS_DISABLED' {return '이 봇은 그룹 참여가 꺼져 있습니다. BotFather의 /setjoingroups에서 허용한 뒤 다시 준비하세요.'}

  'WEBHOOK_IN_USE' {return '다른 서비스가 이 봇을 사용 중입니다. AT 전용 봇으로 연결하세요.'}

  'PAIR_EXPIRED' {return '연결 코드가 만료됐습니다. 연결 준비를 다시 누르고 새 명령을 보내세요.'}

  'PAIR_AMBIGUOUS' {return '같은 코드가 여러 대화방에서 확인됐습니다. 연결 준비를 다시 누르고 원하는 방 한 곳에만 새 명령을 보내세요.'}

  'PAIR_MORE_UPDATES' {return '이전 메시지를 확인했습니다. 연결 확인·저장을 다시 눌러 다음 메시지를 확인하세요.'}

  'PAIR_TOO_MANY' {return '대기 메시지가 너무 많습니다. 연결 준비부터 다시 진행하세요.'}

  'PAIR_NOT_FOUND' {return '연결 명령을 아직 찾지 못했습니다. 개인 연결에 사용한 본인 계정으로 원하는 방에 아래 연결 명령을 보내세요.'}

  'PAIR_REQUIRED' {return '연결 준비를 먼저 누르세요.'}

  'CODEX_MISSING' {return 'Codex 실행 경로를 찾지 못했습니다. 알림만 연결하려면 자동 수정 체크를 해제하세요.'}

  default {return '연결 또는 저장에 실패했습니다. 토큰·인터넷·봇의 메시지 전송 권한을 확인하세요. 기존 수신처 설정은 유지됩니다.'}

 }

}

function Tg-EventText([string]$code,[string]$detail=''){

 $labels=@{SIM_FAULT='통합 모의 운용 확인 필요 (5분 지속)';SIM_RECOVERED='통합 모의 운용 복구';FEED_FAULT='접수·체결 통보 확인 필요 (5분 지속)';FEED_RECOVERED='접수·체결 통보 연결 복구';BUNDLE_UPDATING='전체 버전 업데이트 시작';BUNDLE_UPDATED='전체 버전 업데이트 완료';BUNDLE_ROLLBACK='이전 전체 버전으로 복귀';BUNDLE_RECOVERED='이전 버전 정상 조회 확인';BUNDLE_FAILED='이전 버전 조회 확인 필요';FAULT='장애 감지';RECOVERED='정상 복귀';RESTART='자동 재시작';RESTART_LIMIT='재시작 한도 도달';REPAIR_STARTED='Codex 분석·수정 시작';REPAIR_FAILED='자동 수정 중단 · 기존 버전 유지';NO_CHANGE='코드 수정 없이 분석 완료';UPDATE='검증 통과 · 업데이트 후 재시작';UPDATED='업데이트 후 정상 조회 3회 확인';ROLLBACK='새 버전 확인 실패 · 이전 버전 복귀';ROLLBACK_RECOVERED='이전 버전 정상 조회 확인';ROLLBACK_FAILED='이전 버전도 정상 조회 미확인';CODEX_UNAVAILABLE='Codex 호출 경로 확인 필요';MANAGER_STARTED='감시 시작';MANAGER_STOPPED='사용자 종료 · 감시 종료';READONLY_GUARD='조회 전용 조건 위반 · 실행 중단'}

 if(!$labels.ContainsKey($code)){throw 'NOTIFY_EVENT'}

 if($code -clike 'BUNDLE_*'){if($detail -cnotmatch '^58\.[0-9]{1,4}\.[0-9]{1,4}$'){throw 'NOTIFY_DETAIL'}}elseif($detail -cnotmatch '^[A-Z0-9_ /-]{0,120}$'){throw 'NOTIFY_DETAIL'}

 $kst=[TimeZoneInfo]::ConvertTimeBySystemTimeZoneId((Ops-Now),'Korea Standard Time').ToString('MM/dd HH:mm:ss')

 return ('[AT58] '+$labels[$code]+[Environment]::NewLine+$kst+$(if($detail){[Environment]::NewLine+$detail}else{''}))

}

function Tg-ShowSettings($owner,[string]$root){

 $d=[Windows.Forms.Form]::new();$d.Text='AT58.2 · 텔레그램 개인 / 단톡방 알림';$d.ClientSize=[Drawing.Size]::new(740,640);$d.StartPosition='CenterParent';$d.Font=$owner.Font;$d.FormBorderStyle='FixedDialog';$d.MaximizeBox=$false;$d.MinimizeBox=$false

 function Tg-Label([string]$text,[int]$x,[int]$y,[int]$w,[int]$h){$v=[Windows.Forms.Label]::new();$v.Text=$text;$v.Location=[Drawing.Point]::new($x,$y);$v.Size=[Drawing.Size]::new($w,$h);$d.Controls.Add($v);return $v}

 function Tg-Button([string]$text,[int]$x,[int]$y,[int]$w){$v=[Windows.Forms.Button]::new();$v.Text=$text;$v.Location=[Drawing.Point]::new($x,$y);$v.Size=[Drawing.Size]::new($w,32);$d.Controls.Add($v);return $v}

 $tips=Tg-Label ('처음에는 개인 채팅을 연결하세요. 이후 단톡방으로 알림 수신처를 바꿀 수 있습니다.'+[Environment]::NewLine+'단톡방 연결 명령은 개인 연결에 사용한 본인 계정으로 보내세요.') 18 14 704 46

 $current=Tg-Label '현재 수신처: 연결 안 됨' 18 65 704 28

 $tokenLabel=Tg-Label '봇 토큰' 18 103 100 26

 $tokenInput=[Windows.Forms.TextBox]::new();$tokenInput.Location=[Drawing.Point]::new(120,100);$tokenInput.Width=590;$tokenInput.UseSystemPasswordChar=$true;$d.Controls.Add($tokenInput)

 $modeLabel=Tg-Label '새 수신처' 18 146 100 26

 $mode=[Windows.Forms.ComboBox]::new();$mode.Location=[Drawing.Point]::new(120,140);$mode.Width=310;$mode.DropDownStyle='DropDownList';$mode.Items.AddRange(@('개인 채팅','단톡방 (공동 알림)'));$mode.SelectedIndex=0;$d.Controls.Add($mode)

 $prepare=Tg-Button '연결 준비' 454 138 256

 $linkLabel=Tg-Label '텔레그램 연결 주소 (https://t.me/로 시작)' 18 180 692 25

 $link=[Windows.Forms.TextBox]::new();$link.Location=[Drawing.Point]::new(18,205);$link.Width=692;$link.ReadOnly=$true;$d.Controls.Add($link)

 $copy=Tg-Button '연결 주소 복사' 18 237 160;$copy.Enabled=$false

 $commandLabel=Tg-Label '연결 명령 · 주소 대신 원하는 텔레그램 채팅에 보내도 됩니다.' 18 279 692 25

 $command=[Windows.Forms.TextBox]::new();$command.Location=[Drawing.Point]::new(18,306);$command.Width=692;$command.ReadOnly=$true;$d.Controls.Add($command)

 $copyCommand=Tg-Button '연결 명령 복사' 18 341 200;$copyCommand.Enabled=$false

 $confirm=Tg-Button '연결 확인·저장' 454 341 256;$confirm.Enabled=$false

 $notice=Tg-Label '수신처 선택 → 연결 준비 → 텔레그램에 연결 명령 전송 → 연결 확인·저장. 코드는 10분간 유효합니다.' 18 386 692 78

 $repair=[Windows.Forms.CheckBox]::new();$repair.Text='오류 지속 시 Codex 분석·수정 및 검증된 수정본 자동 적용';$repair.Location=[Drawing.Point]::new(18,472);$repair.Size=[Drawing.Size]::new(692,28);$repair.Checked=$true;$d.Controls.Add($repair)

 $codexLabel=Tg-Label '자동 수정용 Codex 실행 경로 (텔레그램 연결 주소가 아닙니다)' 18 510 692 25

 $codex=[Windows.Forms.TextBox]::new();$codex.Location=[Drawing.Point]::new(18,537);$codex.Width=692;$codex.ReadOnly=$true;$codex.Text=Ops-FindCodex;$d.Controls.Add($codex)

 $disable=Tg-Button '알림·자동수정 끄기' 18 585 190

 $returnPrivate=Tg-Button '개인 알림으로 돌아가기' 230 585 230

 $state=@{Pair=$null;Root=$root;Input=$tokenInput;Mode=$mode;Link=$link;Command=$command;Copy=$copy;CopyCommand=$copyCommand;Prepare=$prepare;Confirm=$confirm;Repair=$repair;Codex=$codex;Notice=$notice;Current=$current;Form=$d}

 foreach($b in @($prepare,$copy,$copyCommand,$confirm,$disable,$returnPrivate,$mode,$tokenInput)){$b.Tag=$state}

 $existing=Tg-Load $root

 if($existing){$tokenInput.Text=$existing.Token;$repair.Checked=[bool]$existing.AutoRepair;$current.Text=Tg-ConnectionLabel $existing;if([string]$existing.ChatId -like '-*'){$mode.SelectedIndex=1}}

 $resetPair={

  $s=$this.Tag;$s.Pair=$null;$s.Link.Clear();$s.Command.Clear();$s.Copy.Enabled=$false;$s.CopyCommand.Enabled=$false;$s.Confirm.Enabled=$false

  $s.Notice.Text='선택한 수신처로 연결 준비를 누르세요. 저장하기 전까지 기존 알림 수신처가 유지됩니다.'

 }

 $mode.Add_SelectedIndexChanged($resetPair);$tokenInput.Add_TextChanged($resetPair)

 $prepare.Add_Click({

  $s=$this.Tag;$s.Pair=$null;$s.Link.Clear();$s.Command.Clear();$s.Copy.Enabled=$false;$s.CopyCommand.Enabled=$false;$s.Confirm.Enabled=$false;$s.Prepare.Enabled=$false

  try{

   $s.Notice.Text='텔레그램 연결 준비 중...';$s.Form.Refresh();$target=if($s.Mode.SelectedIndex -eq 1){'group'}else{'private'}

   $s.Pair=Tg-PreparePair $s.Root $s.Input.Text.Trim() $target;$s.Link.Text=$s.Pair.Link;$s.Command.Text=$s.Pair.Command

   $s.Copy.Enabled=$true;$s.CopyCommand.Enabled=$true;$s.Confirm.Enabled=$true

   $s.Notice.Text=if($target -eq 'group'){'단톡방에 가족과 봇을 초대하고, 본인 계정으로 연결 명령을 보내세요. 이어서 연결 확인·저장을 누르면 단톡방으로 테스트 알림을 보냅니다. (10분 이내)'}else{'연결 주소를 열고 시작을 누르거나, 봇과의 개인 채팅에 연결 명령을 보내세요. 이어서 연결 확인·저장을 누르세요. (10분 이내)'}

  }catch{$s.Notice.Text=Tg-PairError $_.Exception.Message}finally{$s.Prepare.Enabled=$true}

 })

 $copy.Add_Click({if($this.Tag.Pair){[Windows.Forms.Clipboard]::SetText($this.Tag.Pair.Link)}})

 $copyCommand.Add_Click({if($this.Tag.Pair){[Windows.Forms.Clipboard]::SetText($this.Tag.Pair.Command)}})

 $confirm.Add_Click({

  $s=$this.Tag;$s.Confirm.Enabled=$false;$s.Prepare.Enabled=$false

  try{$s.Notice.Text='연결 메시지 확인 및 테스트 알림 전송 중...';$s.Form.Refresh();$c=Tg-CompletePair $s.Root $s.Pair $s.Repair.Checked $s.Codex.Text;$s.Current.Text=Tg-ConnectionLabel $c;$s.Pair=$null;$s.Link.Clear();$s.Command.Clear();$s.Copy.Enabled=$false;$s.CopyCommand.Enabled=$false;$s.Notice.Text='저장 완료. 표시된 수신처로 테스트 알림을 보냈습니다. 단톡방은 참여한 가족이 함께 받으며, 개인 채팅에 중복 전송하지 않습니다.'}

  catch{$s.Notice.Text=Tg-PairError $_.Exception.Message}

  finally{$s.Prepare.Enabled=$true;$s.Confirm.Enabled=($null -ne $s.Pair)}

 })

 $returnPrivate.Add_Click({

  $s=$this.Tag

  try{$c=Tg-UsePrivate $s.Root;$s.Pair=$null;$s.Mode.SelectedIndex=0;$s.Link.Clear();$s.Command.Clear();$s.Copy.Enabled=$false;$s.CopyCommand.Enabled=$false;$s.Confirm.Enabled=$false;$s.Current.Text=Tg-ConnectionLabel $c;$s.Notice.Text='저장 완료. 기존 개인 채팅으로 알림 수신처를 되돌렸습니다.'}catch{$s.Notice.Text=Tg-PairError $_.Exception.Message}

 })

 $disable.Add_Click({

  $s=$this.Tag

  try{$c=Tg-Load $s.Root;if($c){$c.Enabled=$false;$c.AutoRepair=$false;Tg-Save $s.Root $c};$s.Current.Text=Tg-ConnectionLabel $c;$s.Notice.Text='알림·자동수정을 껐습니다. 프로그램 자체 조회와 기본 재시도는 계속됩니다.'}catch{$s.Notice.Text=Tg-PairError $_.Exception.Message}

 })

 try{[void]$d.ShowDialog($owner)}finally{$tokenInput.Clear();$state.Pair=$null;$d.Dispose()}

}

