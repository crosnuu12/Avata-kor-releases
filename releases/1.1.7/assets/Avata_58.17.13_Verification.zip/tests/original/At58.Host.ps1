﻿param([Parameter(Mandatory=$true)][string]$HostRoot)

. (Join-Path $PSScriptRoot 'At58.Ops.ps1')

. (Join-Path $PSScriptRoot 'At58.Update.ps1')

$HostRoot=[IO.Path]::GetFullPath($HostRoot);$created=$false

$mutex=[Threading.Mutex]::new($true,('Local\esbada-AT-host-'+(Ops-Key $HostRoot.ToLowerInvariant()).Substring(0,24)),[ref]$created)

if(!$created){$mutex.Dispose();exit}

$job=$null;$session='';$manage='';$trial=$null;$probe=Up-NewProbe;$stopped=$false;$recovering=$false

$pollSeconds=2;$trialSeconds=210;$remoteJob=$null;$nextRemote=[datetime]::MinValue

function Start-Bundle($bundle,[bool]$desired){

 $path=Ops-Inside $HostRoot (Join-Path $HostRoot ('bundles\'+$bundle.Id));$manifest=Up-Validate $path $bundle.ManifestHash

 $script:session=[guid]::NewGuid().ToString();$script:probe=Up-NewProbe;$script:started=Ops-Now

 $args=@('-NoProfile','-STA','-ExecutionPolicy','Bypass','-File',(Join-Path $path 'At58.Manager.ps1'),'-DataRoot',$data,'-ManagementRoot',$manage,'-HostSession',$script:session,'-BundleVersion',$bundle.Version)

 if($manifest.HostProtocol -eq 2){$args+=@('-HostProtocol','2')}

 if($desired){$args+='-AutoStart'}

 $script:job=Ops-StartProcess (Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe') $args $path

 Ops-WriteJson (Join-Path $HostRoot 'session.json') @{Session=$script:session;ManagerPid=$script:job.Process.Id;StartedUtc=$script:started.ToString('o')}

}

function Save-Trial {Ops-WriteJson (Join-Path $HostRoot 'trial.json') $script:trial}

function Rollback-Bundle([bool]$desired){

 Up-StopManager $script:job $manage $script:session

 if($script:job){$script:job.Process.Dispose();$script:job=$null}

 $script:trial.Phase='ROLLING_BACK';Save-Trial

 Up-RestorePointer $manage $script:trial.PreviousPointer

 $script:active=$script:trial.Previous;Ops-WriteJson (Join-Path $HostRoot 'active.json') $script:active

 $rejected=@($script:state.Rejected)+@($script:trial.Candidate.Id);$script:state.Rejected=@($rejected|Select-Object -Unique);Ops-WriteJson (Join-Path $HostRoot 'state.json') $script:state

 Start-Bundle $script:active $desired;$script:recovering=$true

 Up-Notify $manage 'BUNDLE_ROLLBACK' $script:active.Version

}

try{

 $config=Ops-ReadJson (Join-Path $HostRoot 'settings.json');if(!$config -or $config.Schema -cne 'AT58-HOST-1'){throw 'BUNDLE_HOST_SETTINGS'}

 $data=[IO.Path]::GetFullPath($config.DataRoot);$manage=[IO.Path]::GetFullPath($config.ManagementRoot);$channel=[IO.Path]::GetFullPath($config.ChannelRoot)

 $state=Ops-ReadJson (Join-Path $HostRoot 'state.json');if(!$state){$state=[pscustomobject]@{Rejected=@();Restarts=0}}

 $active=Ops-ReadJson (Join-Path $HostRoot 'active.json');if(!$active){throw 'BUNDLE_NO_ACTIVE'}

 $trial=Ops-ReadJson (Join-Path $HostRoot 'trial.json')

 # If a host died during a switch, ask its own manager to stop, then recover the prior bundle.

 $old=Ops-ReadJson (Join-Path $HostRoot 'session.json')

 if($old){Up-StopManager $null $manage $old.Session}else{Up-WaitManagerFree $manage}

 $desired=[bool](Ops-Get $config 'ResumeOnce' $false)

 if($old){$previousRuntime=Ops-ReadJson (Join-Path $manage 'runtime.json');if(!$previousRuntime -or $previousRuntime.ExitReason -cne 'USER_CLOSE'){$desired=[bool](Ops-Get $old 'DesiredRunning' $desired)}}

 if($trial -and $trial.Phase -cin @('PENDING','ROLLING_BACK')){

  Up-RestorePointer $manage $trial.PreviousPointer;$active=$trial.Previous;Ops-WriteJson (Join-Path $HostRoot 'active.json') $active

  $state.Rejected=@($state.Rejected)+@($trial.Candidate.Id);Ops-WriteJson (Join-Path $HostRoot 'state.json') $state

  # Fresh launch after the user closed the app stays paused. A crash retains the saved intent.

  $runtime=Ops-ReadJson (Join-Path $manage 'runtime.json')

  if(!$runtime -or $runtime.ExitReason -cne 'USER_CLOSE'){$desired=[bool]$trial.DesiredRunning}

  $trial.Phase='ROLLING_BACK';Save-Trial;$recovering=$true

 }

 $config.ResumeOnce=$false;Ops-WriteJson (Join-Path $HostRoot 'settings.json') $config

 # A fresh launch checks the signed feed before starting a reader. Offline failures retain the verified installed bundle.
 if($config.Enabled -and (Ops-Get $config 'FeedUrl' '')){try{$null=Up-RemoteRefresh $HostRoot}catch{};$nextRemote=(Ops-Now).AddMinutes(5);$channel=Join-Path $HostRoot 'remote-channel'}
 if($config.Enabled -and (Ops-Get $config 'ManualWhenRunning' $false) -and !$recovering){
  try{
   $startupOffer=Up-Offer $channel
   if($startupOffer -and $startupOffer.Id -cnotin @($state.Rejected) -and (Up-Version $startupOffer.Version) -gt (Up-Version $active.Version)){
    $null=Up-Stage $HostRoot $startupOffer
    $new=[pscustomobject]@{Id=$startupOffer.Id;Version=$startupOffer.Version;ManifestHash=$startupOffer.ManifestHash}
    $trial=Up-NewTrial $active $new $manage $desired;Save-Trial;$active=$new;Ops-WriteJson (Join-Path $HostRoot 'active.json') $active
   }
  }catch{Up-WriteStatus $manage 'REJECTED' $active.Version $session (Up-Code $_)}
 }
 Start-Bundle $active $desired

 $nextOffer=[datetime]::MinValue;$offer=$null;$lastRejected=''

 while($true){

  $now=Ops-Now;$manager=Ops-ReadJson (Join-Path $manage 'manager-status.json');$runtime=Ops-ReadJson (Join-Path $manage 'runtime.json');$status=Ops-ReadJson (Join-Path $data 'status.json')

  $health=Up-Observe $probe $manager $runtime $status $session $started $now

  # Downloads run in a separate process and never block account/order supervision.
  if($remoteJob -and $remoteJob.Process.HasExited){$remoteJob.Process.Dispose();$remoteJob=$null;$nextOffer=[datetime]::MinValue}
  if($config.Enabled -and (Ops-Get $config 'FeedUrl' '') -and !$remoteJob -and $now -ge $nextRemote){
   $nextRemote=$now.AddMinutes(5)
   try{$remoteJob=Ops-StartProcess (Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe') @('-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-File',(Join-Path $HostRoot 'At58.Update.ps1'),'-RemoteHostRoot',$HostRoot) $HostRoot}catch{}
  }

  $belongs=$manager -and $manager.HostSession -ceq $session -and $runtime -and $runtime.RunId -ceq $manager.RunId

  $desired=if($belongs){[bool]$runtime.DesiredRunning}else{$desired}

  $sessionState=Ops-ReadJson (Join-Path $HostRoot 'session.json')

  if($belongs -and $sessionState -and $sessionState.Session -ceq $session -and (Ops-Get $sessionState 'DesiredRunning') -ne $desired){$sessionState|Add-Member NoteProperty DesiredRunning $desired -Force;Ops-WriteJson (Join-Path $HostRoot 'session.json') $sessionState}

  $exitState=Ops-ReadJson (Join-Path $manage 'bundle-exit.json')

  if($health -ceq 'CLOSED' -or ($exitState -and $exitState.Session -ceq $session -and $exitState.Reason -ceq 'USER_CLOSE')){Up-WriteStatus $manage 'STOPPED' $active.Version $session;break}

  if($health -ceq 'UNSAFE'){Up-WriteStatus $manage 'BLOCKED' $active.Version $session 'READONLY_GUARD';Up-StopManager $job $manage $session;$stopped=$true;break}

  $pending=$trial -and $trial.Phase -cin @('PENDING','ROLLING_BACK')

  if($pending){

   if($health -ceq 'LIVE_HOLD'){$started=$now;Up-WriteStatus $manage 'LIVE_HOLD' $active.Version $session}

   elseif($health -ceq 'PAUSED'){$started=$now;Up-WriteStatus $manage 'WAITING_FOR_QUERY' $active.Version $session}

   elseif($health -ceq 'READY' -and !$job.Process.HasExited){

    $trial.Phase=if($recovering){'ROLLED_BACK'}else{'COMMITTED'};Save-Trial

    Up-Notify $manage $(if($recovering){'BUNDLE_RECOVERED'}else{'BUNDLE_UPDATED'}) $active.Version

    $recovering=$false;Up-WriteStatus $manage 'CURRENT' $active.Version $session

   }elseif($job.Process.HasExited -or ($now-$started).TotalSeconds -gt $trialSeconds){

    if(!$recovering){Rollback-Bundle $desired;continue}

    $trial.Phase='ROLLBACK_UNCONFIRMED';Save-Trial;Up-WriteStatus $manage 'ROLLBACK_UNCONFIRMED' $active.Version $session;Up-Notify $manage 'BUNDLE_FAILED' $active.Version

    # Keep the restored reader alive if it is merely awaiting the broker. Do not loop updates.

    $config.Enabled=$false;Ops-WriteJson (Join-Path $HostRoot 'settings.json') $config;$recovering=$false

   }else{Up-WriteStatus $manage $(if($recovering){'ROLLBACK_CHECK'}else{'VERIFYING'}) $active.Version $session}

  }elseif($job.Process.HasExited){

   Up-WriteStatus $manage 'MANAGER_EXIT' $active.Version $session;break

  }else{

   if($now -ge $nextOffer){

    $nextOffer=$now.AddSeconds(10);$offer=$null

    $fresh=Ops-ReadJson (Join-Path $HostRoot 'settings.json');if($fresh){$config.Enabled=[bool]$fresh.Enabled}

    if($config.Enabled){try{$candidate=Up-Offer $channel;if($candidate -and $candidate.Id -cne $active.Id -and $candidate.Id -cnotin @($state.Rejected) -and (Up-Version $candidate.Version) -gt (Up-Version $active.Version)){$offer=$candidate}}catch{$code=Up-Code $_;Up-WriteStatus $manage 'REJECTED' $active.Version $session $code;$lastRejected=$code}}

   }

   $request=Ops-ReadJson (Join-Path $manage 'update-request.json')
   $requested=Up-ApplyRequest $request $offer $session ([string](Ops-Get $runtime 'RunId' '')) $now
   $applyAllowed=!(Ops-Get $config 'ManualWhenRunning' $false) -or $requested
   if($offer -and $applyAllowed -and $health -ceq 'READY' -and $belongs -and !$runtime.Busy -and !$manager.RepairRunning -and !(Ops-Get $manager 'RepairTransaction' $false)){

    try{$null=Up-Stage $HostRoot $offer}catch{Up-WriteStatus $manage 'REJECTED' $active.Version $session (Up-Code $_);$offer=$null;continue}

    $new=[pscustomobject]@{Id=$offer.Id;Version=$offer.Version;ManifestHash=$offer.ManifestHash}

    $trial=Up-NewTrial $active $new $manage $desired;Save-Trial

    Up-WriteStatus $manage 'SWITCHING' $new.Version $session;Up-Notify $manage 'BUNDLE_UPDATING' $new.Version
    Up-UserStatus $manage $session $runtime.RunId $active $offer 'APPLYING'

    Up-StopManager $job $manage $session;$job.Process.Dispose();$job=$null

    # Re-snapshot only after the old manager has ended, so a completed repair is not lost.

    $trial.PreviousPointer=Up-SnapshotPointer $manage;Save-Trial

    $active=$new;Ops-WriteJson (Join-Path $HostRoot 'active.json') $active

    try{Start-Bundle $active $desired}catch{Rollback-Bundle $desired}

    $offer=$null;continue

   }

   # A detected update does not change the installed bundle's readiness or real-order approval.
   Up-WriteStatus $manage $(if($health -ceq 'LIVE_HOLD'){'LIVE_HOLD'}elseif(!$config.Enabled){'DISABLED'}elseif($offer -and !(Ops-Get $config 'ManualWhenRunning' $false)){'UPDATE_WAITING'}elseif($lastRejected){'REJECTED'}else{'CURRENT'}) $active.Version $session $lastRejected
   $remote=Ops-ReadJson (Join-Path $HostRoot 'remote-status.json')
   $updateState=Up-AvailableState $config.Enabled $offer $requested ([bool]$remoteJob) ([string](Ops-Get $config 'FeedUrl' '')) $remote $active $lastRejected
   Up-UserStatus $manage $session ([string](Ops-Get $runtime 'RunId' '')) $active $offer $updateState ([string](Ops-Get $remote 'Code' ''))

  }

  Start-Sleep -Seconds $pollSeconds

 }

}catch{

 if($manage){try{Up-WriteStatus $manage 'HOST_ERROR' $(if($active){$active.Version}else{''}) $session (Up-Code $_)}catch{}}

}finally{
 if($remoteJob){$remoteJob.Process.Dispose()}

 # Only our manager gets a stop request; never kill an unrelated process.

 if($job){try{if(!$job.Process.HasExited -and !$stopped){$rt=Ops-ReadJson (Join-Path $manage 'runtime.json');$st=Ops-ReadJson (Join-Path $data 'status.json');$safe=Ops-LiveMaintenance $rt $st ([string](Ops-Get $rt 'RunId')) (Ops-Now);if($safe -cin @('LEGACY','QUIESCENT')){Up-StopManager $job $manage $session}}}catch{};$job.Process.Dispose()}

 $mutex.ReleaseMutex();$mutex.Dispose()

}

