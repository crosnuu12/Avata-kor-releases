﻿function Cash-Matrix([int]$rows,[int]$cols){$v=New-Object 'Collections.Generic.List[object]';for($i=0;$i -lt $rows;$i++){$r=New-Object object[] $cols;for($j=0;$j -lt $cols;$j++){$r[$j]=''};$v.Add($r)};return ,$v.ToArray()}
function Cash-Fixture([string]$data){
 $now=[datetime]::SpecifyKind([datetime]'2026-11-02T01:00:00',[DateTimeKind]::Utc);$day='20261102'
 $owner=At58-Context $data '0210A0' ([pscustomobject]@{AppKey='synthetic-interest-key';AppSecret='synthetic-interest-secret'})
 $owner.LiveHostProtocol=2;$owner.Clock={return $script:cashClock};$script:cashClock=$now
 $owner.Transport={throw 'TEST_BROKER_FORBIDDEN'}
 $params=Cash-Matrix 28 5;$params[0][0]='항목'
 foreach($v in @(@(1,.01),@(2,.02),@(3,30),@(4,1),@(5,2),@(6,.25),@(7,.5),@(8,1),@(9,.8),@(10,.001),@(11,3),@(13,.001))){$params[[int]$v[0]][1]=$v[1]}
 foreach($v in @(@(19,1000000),@(20,.2),@(21,.9),@(22,.1),@(23,5),@(24,6000))){$params[[int]$v[0]][4]=$v[1]}
 $settings=Cash-Matrix 27 3
 foreach($v in @(@(0,'설정 항목',''),@(1,'종목코드','KRX:0210A0'),@(2,'수익 재투자','미사용'),@(3,'단기 이동평균 기간',5),@(4,'중기 이동평균 기간',20),@(5,'급등·급락 기준 배수',2),@(6,'변동성 계산 기간',20),@(8,'시장 상태',''))){$settings[[int]$v[0]][0]=$v[1];$settings[[int]$v[0]][1]=$v[2]}
 $regimes=@('급등','상승','하락','급락')
 for($i=0;$i -lt 4;$i++){$params[15+$i]=@($regimes[$i],1,1,1,1);$settings[9+$i]=@($regimes[$i],'허용','')}
 $params[27]=@('보합',.5,1,1,.5);$settings[13]=@('보합','허용','')
 $labels=@('보합 계산 기간','보합 추세효율 상한','보합 평균이격 배수','보합 매수구간','보합 매도구간','보합 일일 매수한도','보합 현금 유지비율','보합 비용 안전여유','보합 밴드 배수')
 $values=@(20,.2,.5,.25,.75,2,.3,.01,2)
 for($i=0;$i -lt 9;$i++){$settings[18+$i]=@($labels[$i],$values[$i],'')}
 $cycles=@(@('차수','기준','상태','종목'),@(1,6000,'운영중','0210A0'))
 $ledger=,@('날짜','차수','구분(매수/매도)','체결단가','수량','체결금액','AT 체결키')
 $raw=[pscustomobject]@{Schema='AT-STRATEGY-INPUT-1';Utc=$now.ToString('o');Scope=$owner.Scope;Symbol=$owner.Symbol;Day=$day;Params=$params;Cycles=$cycles;Ledger=$ledger;Settings=(Sheet-ImportSettings $settings)}
 $seed=At58S-Import $raw

 $s=[pscustomobject]@{Scope=$owner.Scope;Symbol=$owner.Symbol;Day=$day;CompletedUtc=$now.ToString('o');TargetQty=0D;TargetAverage=0D;Cash=[pscustomobject]@{D2=$seed.Ledger.Cash;Orderable=$seed.Ledger.Cash};Holdings=@();OrdersToday=@();OpenOrdersToday=@();PriorOrders=@();PriorDay='20261030';PriorUnresolved=@();Session=@{Live=$false;Close=[datetime]'2026-11-02T15:30:00';PreviousDay='20261030'};Quote=@{Price=6000D;Mode='CLOSED_DAILY';BasisDay=$day;ReceivedUtc=$now.ToString('o');Tick=5;Volume=10000D};Execution=@{Connected=$true;ReceiptAck=$true;FillAck=$true;Pending=0;Gaps=0}}
 $state=At58X-Initialize $owner $seed $s @()
 $book=At58T-Load (At58X-Context $owner)
 return @{Owner=$owner;State=$state;Source=$seed;Snapshot=$s;Book=$book;Raw=$raw}
}
