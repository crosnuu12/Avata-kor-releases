﻿#requires -Version 5.1
param([string]$Root=$PSScriptRoot)
$ErrorActionPreference='Stop';Set-StrictMode -Version 2
. (Join-Path $Root 'bundle/At58.Ops.ps1')
. (Join-Path $Root 'bundle/At58.Sheets.ps1')
. (Join-Path $Root 'bundle/payload/At58.Core.ps1')
. (Join-Path $Root 'bundle/payload/At58.Log.ps1')
. (Join-Path $Root 'tests/CashFixture.ps1')
$script:checks=0;$script:posts=0;$script:network=0;$script:reads=0
$script:originalError=${function:At58-Error}
function At58-Error($record){$v=& $script:originalError $record;if($v.Code -ceq 'UNEXPECTED'){Write-Host ('SYNTHETIC ERROR '+$record.Exception.Message+' '+$record.ScriptStackTrace)};return $v}
function Check($ok,[string]$name){if(!$ok){throw ('FAILED: '+$name)};$script:checks++;Write-Output ('PASS '+$name)}
function Reject($body,[string]$code,[string]$name){$found='';try{& $body|Out-Null}catch{$found=(At58-Error $_).Code};Check ($found -ceq $code) ($name+' ['+$found+']')}
function Invoke-RestMethod {$script:network++;throw 'NETWORK_FORBIDDEN'}
function At58T-Wire {$script:posts++;throw 'ORDER_FORBIDDEN'}
function Save-Input($o,$raw){At58-Atomic (Join-Path $o.Root 'strategy-input.dpapi') (At58-Protect ($raw|ConvertTo-Json -Depth 30 -Compress) 'AT58-STRATEGY-INPUT-1')}
$work=Join-Path ([IO.Path]::GetTempPath()) ('AvataDayTest-'+[guid]::NewGuid().ToString('N'))
[void][IO.Directory]::CreateDirectory($work)
try{
 Check ($null -ne (Get-Command At58X-RolloverInput -ErrorAction SilentlyContinue)) 'day-transition gate is available'
 $f=Cash-Fixture (Join-Path $work 'data');$o=$f.Owner;$raw=$f.Raw;$s=$f.Snapshot;$source=$f.Source
 $script:cashClock=([datetimeoffset]'2026-11-02T14:59:55Z').UtcDateTime
 $limits=[pscustomobject]@{MaxOrderQty=100;MaxOrderAmount=1000000;DailyBuyAmount=1000000;DailySubmissions=20}
 $session=At58X-NewSession $o $source.Hash $limits;At58X-Authorize $o $session $source.Hash
 $s.CompletedUtc=$script:cashClock.ToString('o');$null=At58X-Step $o $source $s @() $null $source.Policy.Regimes.PSObject.Properties.Name[0] '허용'
 $script:cashClock=$script:cashClock.AddSeconds(4);$s.CompletedUtc=$script:cashClock.ToString('o')
 $before=At58X-Step $o $source $s @() $null $source.Policy.Regimes.PSObject.Properties.Name[0] '허용'
 Check ($before.Reconciled -and $before.State -ceq 'ARMED') 'existing operator session is reconciled before midnight'
 $raw.Utc=$script:cashClock.ToString('o');Save-Input $o $raw;$o.LastSuccess=$raw.Utc
 $oldInput=[IO.File]::ReadAllText((Join-Path $o.Root 'strategy-input.dpapi'))
 $box=At58X-Mailbox $o.RunId;$box.Mode='LIVE';$script:cashClock=$script:cashClock.AddSeconds(1)
 $wait=At58X-ManagedCycle $o $box
 Check (!$wait.Ok -and $wait.Status.Code -ceq 'LIVE_ROLLOVER_WAIT' -and $wait.Status.State -ceq 'RETRY') 'midnight old-day input becomes an explicit transition wait'
 Check ($wait.Status.Failures -eq 0 -and !$wait.Status.Live.ExecutionEnabled -and !$wait.Status.Live.Reconciled -and $wait.Status.Live.Confirmations -eq 0) 'transition submits nothing and resets ledger proof without a false failure count'
 Check ($wait.Status.Live.State -ceq 'ARMED' -and $session.State -ceq 'ARMED' -and $wait.RetrySeconds -eq 5) 'same-process operator intent survives while new orders remain blocked'
 Check ([IO.File]::ReadAllText((Join-Path $o.Root 'strategy-input.dpapi')) -ceq $oldInput) 'old input is not relabelled as today'
 $disk=Ops-ReadJson (Join-Path $o.Root 'status.json')
 Check ($disk.Live.Rollover.Schema -ceq 'AT-LIVE-ROLLOVER-1' -and $disk.Live.Rollover.Phase -ceq 'INPUT') 'structured transition evidence survives JSON serialization'
 Check ($null -ne (Convert-At58LogRecord ([IO.File]::ReadAllText((Join-Path $o.Root 'status.json'))))) 'transition wait remains visible in diagnostic log viewer'
 $watch=[pscustomobject]@{};$run=$o.RunId
 Check (!(Ops-LiveAlert $watch $wait.Status $run $script:cashClock)) 'verified input transition does not send a fault alarm'
 $runtime=[pscustomobject]@{HostProtocol=2;RunId=$run;Utc=$script:cashClock.ToString('o');DesiredRunning=$true;LiveMode='LIVE';ExecutionEnabled=$false;Fault=''}
 Check ((Ops-Classify $runtime $wait.Status $run $script:cashClock.AddMinutes(-10) $false $script:cashClock) -ceq 'ROLLOVER_WAIT') 'manager recognizes transition rather than persistent failure'
 # Real read adapters are replaced by local fixtures; the actual cycle and
 # ledger/session state machine remain under test. Any order call is forbidden.
 $script:fixtureSnapshot=$s;$script:fixtureOwner=$o;$script:straddle=$false
 function At58I-Read($owner,$from,$to){return [pscustomobject]@{Schema='AT-CASH-INTEREST-1';Scope=$owner.Scope;From=$from;To=$to;Utc=$script:cashClock.ToString('o');Rows=@()}}
 function At58X-Costs {return @()}
 function At58-List {return @()}
 function At58-ReadSnapshot {
  $script:reads++
  if($script:straddle){$script:cashClock=$script:cashClock.AddSeconds(2);At58-Fail 'DATE_CHANGE'}
  $v=At58S-Clone $script:fixtureSnapshot;$v.Day=(At58-Kst $script:cashClock).ToString('yyyyMMdd');$v.PriorDay='20261102';$v.CompletedUtc=$script:cashClock.ToString('o');$v.PSObject.Properties.Remove('Execution');$v|Add-Member ExecutionEnabled $false -Force;return $v
 }
 function At58E-Run {return [pscustomobject]@{Connected=$true;ReceiptAck=$true;FillAck=$true;Pending=0;Gaps=0}}
 function At58S-Market {return [pscustomobject]@{Name='하락'}}
 $script:cashClock=$script:cashClock.AddSeconds(23);$raw.Day='20261103';$raw.Utc=$script:cashClock.ToString('o');Save-Input $o $raw
 $first=At58X-ManagedCycle $o $box
 Check ($first.Ok -and $first.Status.Live.Confirmations -eq 1 -and !$first.Status.Live.Reconciled -and $first.Status.Live.Rollover.Phase -ceq 'RECONCILE') 'fresh new-day input advances to first actual account reconciliation'
 Check ($first.Status.Live.State -ceq 'ARMED' -and $script:posts -eq 0) 'one new-day confirmation cannot submit an order'
 $script:cashClock=$script:cashClock.AddSeconds(5);$second=At58X-ManagedCycle $o $box
 Check ($second.Ok -and $second.Status.Live.Reconciled -and $second.Status.Live.Confirmations -eq 2 -and $second.Status.Live.Rollover.Phase -ceq 'COMPLETE') 'two actual fresh account reads complete transition immediately'
 Check ($second.Status.Live.State -ceq 'ARMED' -and $session.Day -ceq '20261103' -and $script:posts -eq 0) 'existing enabled session reaches normal market wait without reauthorization or an order'
 Check ((Ops-RolloverState $second.Status.Live $run $script:cashClock) -ceq 'COMPLETE') 'completed transition is explicit in status'
 # Reproduce an in-flight request that started before midnight.
 $script:cashClock=([datetimeoffset]'2026-11-02T14:59:59Z').UtcDateTime;$raw.Day='20261102';$raw.Utc=$script:cashClock.ToString('o');Save-Input $o $raw
 $o.LiveRollover=$null;$script:straddle=$true;$crossed=At58X-ManagedCycle $o $box;$script:straddle=$false
 Check (!$crossed.Ok -and $crossed.Status.Code -ceq 'LIVE_ROLLOVER_WAIT' -and $null -eq $crossed.Snapshot) 'in-flight midnight read discards mixed-day snapshot and requests new input'
 # Missing, stale, changed-identity and long-running waits must not be hidden.
 $script:cashClock=([datetimeoffset]'2026-11-02T15:00:30Z').UtcDateTime
 $raw.Utc=$script:cashClock.AddMinutes(-3).ToString('o');Save-Input $o $raw
 Reject {At58X-Input $o} 'LIVE_INPUT_WAIT' 'stale input is a real input fault during the transition window'
 $raw.Utc=([datetimeoffset]'2026-11-02T14:59:59Z').UtcDateTime.ToString('o');$raw.Scope='different-account';Save-Input $o $raw
 Reject {At58X-Input $o} 'LIVE_SOURCE_IDENTITY' 'another account cannot create a benign date transition'
 $raw.Scope=$o.Scope;Save-Input $o $raw
 $script:cashClock=([datetimeoffset]'2026-11-02T15:02:01Z').UtcDateTime
 Reject {At58X-Input $o} 'LIVE_INPUT_WAIT' 'input still unavailable after watchdog remains an error'
 $stalled=At58S-Clone $wait.Status;$stalled.Utc=$script:cashClock.ToString('o');$stalled.Live.Utc=$stalled.Utc
 $alert=Ops-LiveAlert $watch $stalled $run $script:cashClock
 Check ($alert.Event -ceq 'FAULT' -and $alert.Code -ceq 'LIVE LIVE_ROLLOVER_STALLED') 'watchdog escalates unchanged transition instead of suppressing indefinitely'
 Check (!(Ops-LiveAlert $watch $stalled $run $script:cashClock.AddSeconds(1))) 'stalled transition alarm is deduplicated'
 $recovered=At58S-Clone $second.Status;$recovered.Utc=$script:cashClock.ToString('o');$recovered.Live.Utc=$recovered.Utc
 Check ((Ops-LiveAlert $watch $recovered $run $script:cashClock).Event -ceq 'RECOVERED') 'recovery after an alerted transition emits a recovery notice'
 foreach($case in @('REVIEW','UNCERTAIN','MISSING_PROOF','WRONG_RUN','NETWORK')){
  $bad=At58S-Clone $wait.Status;$clock=([datetimeoffset]'2026-11-02T15:00:01Z').UtcDateTime
  switch($case){'REVIEW'{$bad.Live.State='REVIEW'} 'UNCERTAIN'{$bad.Live.UncertainOrders=1} 'MISSING_PROOF'{$bad.Live.PSObject.Properties.Remove('Rollover')} 'WRONG_RUN'{$bad.Live.Rollover.RunId='other'} 'NETWORK'{$bad.Live.Code='NETWORK'}}
  Check ((Ops-LiveAlert ([pscustomobject]@{}) $bad $run $clock).Event -ceq 'FAULT') ($case+' cannot hide behind date-transition wait')
 }
 # Disarmed starts and restarted processes cannot acquire operator authorization.
 $o.Remove('LiveSession');$o.LiveRollover=$null;$script:cashClock=([datetimeoffset]'2026-11-02T15:00:40Z').UtcDateTime;Save-Input $o $raw
 $disarmed=At58X-ManagedCycle $o $box
 Check ($disarmed.Status.Live.State -ceq 'DISARMED' -and !$o.ContainsKey('LiveSession')) 'transition never creates approval for a disarmed program'
 $raw.Day='20261103';$raw.Utc=$script:cashClock.ToString('o');Save-Input $o $raw
 $null=At58X-ManagedCycle $o $box;$script:cashClock=$script:cashClock.AddSeconds(5);$off=At58X-ManagedCycle $o $box
 Check ($off.Status.Live.State -ceq 'DISARMED' -and $off.Status.Live.Reconciled) 'disarmed program remains disarmed after successful transition'
 # An input worker may have already refreshed today before the account cycle.
 $ready=Cash-Fixture (Join-Path $work 'already-ready');$ro=$ready.Owner;$rr=$ready.Raw;$rs=$ready.Snapshot
 $script:cashClock=([datetimeoffset]'2026-11-02T14:59:59Z').UtcDateTime;$rs.CompletedUtc=$script:cashClock.ToString('o')
 $null=At58X-Step $ro $ready.Source $rs @() $null '하락' '허용'
 $script:cashClock=([datetimeoffset]'2026-11-02T15:00:05Z').UtcDateTime;$rr.Day='20261103';$rr.Utc=$script:cashClock.ToString('o');Save-Input $ro $rr
 $rb=At58X-Mailbox $ro.RunId;$rb.Mode='LIVE';$script:fixtureSnapshot=$rs
 $ready1=At58X-ManagedCycle $ro $rb
 Check ($ready1.Ok -and $ready1.Status.Live.Rollover.Phase -ceq 'RECONCILE' -and $ready1.Status.Live.Confirmations -eq 1) 'already-refreshed input goes straight to fresh reconciliation without a timed pause'
 $script:cashClock=$script:cashClock.AddSeconds(5);$ready2=At58X-ManagedCycle $ro $rb
 Check ($ready2.Status.Live.Rollover.Phase -ceq 'COMPLETE' -and $ready2.Status.Live.Reconciled -and $ready2.Status.Live.State -ceq 'DISARMED') 'already-refreshed path finishes as soon as two confirmations exist'
 $newRun=[guid]::NewGuid().ToString();$ro.RunId=$newRun;$rb=At58X-Mailbox $newRun;$rb.Mode='LIVE';$script:cashClock=$script:cashClock.AddSeconds(5)
 $restarted=At58X-ManagedCycle $ro $rb
 Check ($restarted.Status.Live.State -ceq 'DISARMED' -and $restarted.Status.Live.Confirmations -eq 1 -and !$ro.ContainsKey('LiveSession')) 'restart discards previous-run transition and requires fresh proof without authorizing trades'
 # Dates are calendar-based, including month/year boundaries.
 foreach($date in @('2026-12-01T00:00:01+09:00','2027-01-01T00:00:01+09:00')){
  $script:cashClock=([datetimeoffset]$date).UtcDateTime;$kst=At58-Kst $script:cashClock
  $raw.Day=$kst.AddDays(-1).ToString('yyyyMMdd');$raw.Utc=$script:cashClock.AddSeconds(-2).ToString('o');Save-Input $o $raw;$o.LiveRollover=$null
  Reject {At58X-Input $o} 'LIVE_ROLLOVER_WAIT' ('calendar boundary '+$date+' enters transition')
 }
 # Real pump function: one worker, immediate refresh once, then existing backoff.
 $script:pumpClock=([datetimeoffset]'2026-11-02T15:00:01Z').UtcDateTime;$script:starts=0
 function Ops-Now {return $script:pumpClock}
 function Sheet-Config {return [pscustomobject]@{Enabled=$true}}
 function Ops-StartProcess {
  $script:starts++;$p=[pscustomobject]@{HasExited=$false;ExitCode=0};$p|Add-Member ScriptMethod Dispose {};$p|Add-Member ScriptMethod Kill {$this.HasExited=$true}
  return [pscustomobject]@{Process=$p;Started=$script:pumpClock}
 }
 $script:At58SheetPump=@{Job=$null;Next=$script:pumpClock.AddSeconds(40);Failures=0}
 Sheet-Pump $Root (Join-Path $work 'data') $work $wait.Status $run
 Check ($script:starts -eq 1) 'verified date change wakes the input worker immediately'
 Sheet-Pump $Root (Join-Path $work 'data') $work $wait.Status $run
 Check ($script:starts -eq 1) 'pending worker is never duplicated'
 $script:At58SheetPump.Job.Process.HasExited=$true;$script:At58SheetPump.Job.Process.ExitCode=1
 Sheet-Pump $Root (Join-Path $work 'data') $work $wait.Status $run
 Check ($script:starts -eq 1 -and $script:At58SheetPump.Next -gt $script:pumpClock) 'real worker failure retains bounded retry backoff'
 $script:At58SheetPump=@{Job=$null;Next=$script:pumpClock.AddSeconds(40);Failures=0}
 Sheet-Pump $Root (Join-Path $work 'data') $work $wait.Status 'other-run'
 Check ($script:starts -eq 1) 'unrelated run cannot force an input refresh'
 Ops-Event $work 'FAULT' '' 'LIVE LIVE_INPUT_WAIT'
 Ops-Event $work 'FAULT' '' 'secret token=not-a-real-token account=1234'
 $records=@(Get-Content -LiteralPath (Join-Path $work 'manager-20261103.jsonl') -Encoding UTF8 | ForEach-Object {$_|ConvertFrom-Json})
 Check ($records[0].Stage -ceq 'LIVE_INPUT_WAIT' -and $records[0].State -ceq 'LIVE') 'manager log preserves safe diagnostic identifiers for remote diagnosis'
 Check (!$records[1].PSObject.Properties['Stage']) 'arbitrary diagnostic text is excluded from manager logs'
 $errorRecord=At58S-Clone $wait.Status;$errorRecord.State='READ_ERROR';$errorRecord.Code='LIVE_INPUT_WAIT'
 Check ($null -ne (Convert-At58LogRecord ($errorRecord|ConvertTo-Json -Depth 8 -Compress))) 'real live-read errors are no longer dropped by the log viewer'
 Check ($script:posts -eq 0 -and $script:network -eq 0 -and $script:reads -ge 4) 'all transition checks used local fixtures and zero network or order calls'
 Write-Output ('DAY TRANSITION TESTS COMPLETE: '+$script:checks+' passed; synthetic state only; no real network or orders.')
}finally{
 $safe=[IO.Path]::GetFullPath($work);$temp=[IO.Path]::GetFullPath([IO.Path]::GetTempPath()).TrimEnd('\')+'\'
 if(!$safe.StartsWith($temp,[StringComparison]::OrdinalIgnoreCase) -or [IO.Path]::GetFileName($safe) -cnotmatch '^AvataDayTest-[a-f0-9]{32}$'){throw 'TEST_CLEANUP_PATH'}
 if([IO.Directory]::Exists($safe)){Remove-Item -LiteralPath $safe -Recurse -Force}
}
