﻿#requires -Version 5.1
param([string]$LocalBase=([Environment]::GetFolderPath('LocalApplicationData')))
Set-StrictMode -Version 2
$ErrorActionPreference='Stop'
$script:RIPhase='READY'
$script:RIHashes=@{
 'At58.Ops.ps1'='42D6058E91B68E15E5FA14953BEE6C129EE171C69F02DD5B9ED26CD1F3864A44'
 'At58.Sheets.ps1'='13538FE9FD7EF1C7A3C302F5F52514FBBA18B688CD13C80400135639BF797404'
 'At58.SheetsJwt.ps1'='EC8AEB47702CF7512371420A10D0AA827DBF821119366F6A277519134380353F'
 'payload\At58.Core.ps1'='2B8133693926CAE3ED26C25185527F8D5178BE9ED4CD28C62253D87173DD13D9'
}
function RI-Read([string]$path){
 if(![IO.File]::Exists($path) -or ([IO.FileInfo]$path).Length -gt 1000000){throw 'RECOVERY_FILE_MISSING'}
 return ([IO.File]::ReadAllText($path,[Text.Encoding]::UTF8)|ConvertFrom-Json)
}
function RI-Bundle([string]$localRoot){
 $a=RI-Read (Join-Path $localRoot 'esbada_AT_host\active.json')
 if($a.Version -cne '58.17.0' -or $a.Id -cnotmatch '^bundle-[a-f0-9]{24}$'){throw 'RECOVERY_VERSION'}
 $bundle=Join-Path $localRoot ('esbada_AT_host\bundles\'+$a.Id)
 foreach($name in $script:RIHashes.Keys){
  if((Get-FileHash -LiteralPath (Join-Path $bundle $name) -Algorithm SHA256).Hash -cne $script:RIHashes[$name]){throw 'RECOVERY_VERSION'}
 }
 $active=RI-Read (Join-Path $localRoot 'esbada_AT_manage\active.json')
 if($active.Active -cnotmatch '^(base|fix)-[a-f0-9]{20,32}$'){throw 'RECOVERY_VERSION'}
 $core=Join-Path $localRoot ('esbada_AT_manage\releases\'+$active.Active+'\At58.Core.ps1')
 if((Get-FileHash -LiteralPath $core -Algorithm SHA256).Hash -cne $script:RIHashes['payload\At58.Core.ps1']){throw 'RECOVERY_VERSION'}
 return $bundle
}
function RI-Http([string]$method,[string]$uri,$headers=$null,$body=$null){
 if($method -ceq 'Post' -and $uri -ceq 'https://oauth2.googleapis.com/token'){
  return (Invoke-RestMethod -Method Post -Uri $uri -ContentType 'application/x-www-form-urlencoded' -Body $body -TimeoutSec 20 -MaximumRedirection 0 -ErrorAction Stop)
 }
 if($method -cne 'Get' -or !$script:RIBaseUrl -or !($uri.StartsWith($script:RIBaseUrl+'?', [StringComparison]::Ordinal) -or $uri.StartsWith($script:RIBaseUrl+'/', [StringComparison]::Ordinal))){throw 'RECOVERY_ROUTE_BLOCKED'}
 return (Invoke-RestMethod -Method Get -Uri $uri -Headers $headers -TimeoutSec 20 -MaximumRedirection 0 -ErrorAction Stop)
}
function RI-Token([string]$keyPath){
 $key=$null;$jwt='';$auth=$null;$keyText=''
 try{
  $keyText=[IO.File]::ReadAllText($keyPath);$key=$keyText|ConvertFrom-Json;$keyText=''
  if($key.type -cne 'service_account' -or $key.client_email -notmatch '^[^\s@]+@[^\s@]+\.gserviceaccount\.com$' -or !$key.private_key.StartsWith('-----BEGIN PRIVATE KEY-----')){throw 'RECOVERY_SHEET_KEY'}
  $epoch=[DateTimeOffset]::UtcNow.ToUnixTimeSeconds()
  $claims=@{iss=$key.client_email;scope='https://www.googleapis.com/auth/spreadsheets.readonly';aud='https://oauth2.googleapis.com/token';iat=$epoch;exp=($epoch+600)}|ConvertTo-Json -Compress
  $unsigned=[At58SheetsJwt]::B64([Text.Encoding]::UTF8.GetBytes('{"alg":"RS256","typ":"JWT"}'))+'.'+[At58SheetsJwt]::B64([Text.Encoding]::UTF8.GetBytes($claims))
  $jwt=[At58SheetsJwt]::Sign($unsigned,$key.private_key)
  $auth=RI-Http 'Post' 'https://oauth2.googleapis.com/token' $null @{grant_type='urn:ietf:params:oauth:grant-type:jwt-bearer';assertion=$jwt}
  if(!$auth.access_token){throw 'RECOVERY_SHEET_AUTH'}
  return [string]$auth.access_token
 }finally{$key=$null;$jwt='';$auth=$null;$keyText=''}
}
function RI-Guard($owner,[string]$managementRoot){
 $status=RI-Read (Join-Path $owner.Root 'status.json')
 $runtime=RI-Read (Join-Path $managementRoot 'runtime.json')
 $live=$status.Live;$now=[datetime]::UtcNow
 $statusAge=($now-(At58S-Utc $status.Utc)).TotalSeconds
 $runtimeAge=($now-(At58S-Utc $runtime.Utc)).TotalSeconds
 if($status.RunId -cne $runtime.RunId -or $status.HostProtocol -ne 2 -or $runtime.HostProtocol -ne 2 -or $statusAge -lt -5 -or $statusAge -gt 90 -or $runtimeAge -lt -5 -or $runtimeAge -gt 90){throw 'RECOVERY_STATUS_STALE'}
 $intent=Ops-Get $runtime 'ExecutionEnabled';$runtimeState=[string](Ops-Get $runtime 'LiveState' '')
 if($intent -isnot [bool] -or $runtimeState -cne $live.State -or ($live.State -ceq 'DISARMED' -and $intent) -or ($live.State -ceq 'STOPPING' -and !$intent) -or (Ops-Get $runtime 'LiveCommandPending' $true) -ne $false -or $status.Code -cne 'LIVE_INPUT_WAIT' -or $live.Code -cne 'LIVE_INPUT_WAIT' -or $live.RunId -cne $status.RunId -or $live.State -cnotin @('DISARMED','STOPPING') -or $live.ExecutionEnabled -ne $false -or $status.ExecutionEnabled -ne $false -or $live.OpenOrders -ne 0 -or $live.UncertainOrders -ne 0){throw 'RECOVERY_STATE_UNSUITABLE'}
 $state=At58X-Load $owner
 if(!$state -or $state.TestOnly -ne $false){throw 'RECOVERY_LEDGER_REQUIRED'}
 $book=At58T-Load (At58X-Context $owner)
 if(@($book.Orders|Where-Object {$_.State -cin @('SUBMITTING','UNKNOWN','WARNING_REVIEW','REVIEW','ACKNOWLEDGED','OPEN','PARTIAL')}).Count){throw 'RECOVERY_UNFINISHED_ORDERS'}
 # Both native and transferred installations use the verified live ledger itself.
 # A historic import report cannot prove current order state.
 return [pscustomobject]@{State=$state;Book=$book;RunId=$status.RunId;Journal=(Sheet-JournalCatalog $state $book)}
}
function RI-FetchInput($headers,[string]$base,$snapshot,$journal){
 $meta=RI-Http 'Get' ($base+'?fields=sheets(properties(sheetId,title,gridProperties(rowCount,columnCount)))') $headers
 foreach($item in @(@('매매기준',2026102807),@('사이클관리',2026102806),@('매매일지',1136811970),@('운영설정',2026110202))){
  if(@($meta.sheets|Where-Object {$_.properties.title -ceq $item[0] -and $_.properties.sheetId -eq $item[1]}).Count -ne 1){throw 'STRATEGY_SHEET_STRUCTURE'}
 }
 $layout=Sheet-JournalLayout $meta
 $query='?valueRenderOption=UNFORMATTED_VALUE&dateTimeRenderOption=SERIAL_NUMBER'
 foreach($range in @("'매매기준'!A1:E28","'사이클관리'!A1:E100",$layout.Range)){$query+='&ranges='+[uri]::EscapeDataString($range)}
 $rows=RI-Http 'Get' ($base+'/values:batchGet'+$query) $headers
 if($rows.valueRanges.Count -ne 3){throw 'STRATEGY_SHEET_STRUCTURE'}
 $settings=RI-Http 'Get' ($base+'/values/'+[uri]::EscapeDataString("'운영설정'!A1:C27")+'?valueRenderOption=UNFORMATTED_VALUE') $headers
 $raw=[pscustomobject]@{Schema='AT-STRATEGY-INPUT-1';Utc=[datetime]::UtcNow.ToString('o');Scope=$snapshot.Scope;Day=$snapshot.Day;Symbol=$snapshot.Symbol;Params=$rows.valueRanges[0].values;Cycles=$rows.valueRanges[1].values;Ledger=(Sheet-JournalFilter $rows.valueRanges[2].values $journal).Rows;Settings=(Sheet-ImportSettings $settings.values)}
 $source=At58S-Import $raw
 if($source.Hash -cne $journal.State.SourceHash){throw 'RECOVERY_SOURCE_CHANGED'}
 $modes=@{}
 foreach($i in 17..21){$name=At58S-Cell $raw.Settings $i 0;$mode=At58S-Cell $raw.Settings $i 1;if($name -cnotin @('급등','상승','보합','하락','급락') -or $modes.ContainsKey($name) -or $mode -cnotin @('허용','모의','중단')){throw 'LIVE_REGIME'};$modes[$name]=$mode}
 return $raw
}
function RI-Repair([string]$localRoot){
 $script:RIPhase='INSTALL_CHECK';$bundle=RI-Bundle $localRoot
 . (Join-Path $bundle 'At58.Ops.ps1')
 . (Join-Path $bundle 'At58.Sheets.ps1')
 . (Join-Path $bundle 'At58.SheetsJwt.ps1')
 . (Join-Path $bundle 'payload\At58.Core.ps1')
 $managementRoot=Join-Path $localRoot 'esbada_AT_manage'
 $script:RIPhase='LOCAL_CHECK';$owner=At58-Context (Join-Path $localRoot 'esbada_AT_direct')
 $guard=RI-Guard $owner $managementRoot
 $cfg=Sheet-Config $managementRoot
 if(!$cfg.Enabled){throw 'RECOVERY_ENABLE_SHEET'}
 $sheetId=Sheet-Id ([string]$cfg.SheetId)
 if(![IO.File]::Exists($cfg.KeyPath)){throw 'RECOVERY_SHEET_KEY'}
 $token='';$headers=$null;$raw=$null
 try{
  $script:RIPhase='GOOGLE_AUTH';$token=RI-Token $cfg.KeyPath
  $headers=@{Authorization=('Bearer '+$token)};$script:RIBaseUrl='https://sheets.googleapis.com/v4/spreadsheets/'+$sheetId
  $snapshot=[pscustomobject]@{Scope=$owner.Scope;Symbol=$owner.Symbol;Day=(At58-Kst ([datetime]::UtcNow)).ToString('yyyyMMdd')}
  $script:RIPhase='READ_SHEET';$raw=RI-FetchInput $headers $script:RIBaseUrl $snapshot $guard.Journal
  $script:RIPhase='RECHECK';$fresh=RI-Guard $owner $managementRoot
  if($fresh.RunId -cne $guard.RunId -or $fresh.State.SourceHash -cne $guard.State.SourceHash -or ($fresh.Book|ConvertTo-Json -Depth 60 -Compress) -cne ($guard.Book|ConvertTo-Json -Depth 60 -Compress)){throw 'RECOVERY_LOCAL_CHANGED'}
  if($raw.Day -cne (At58-Kst ([datetime]::UtcNow)).ToString('yyyyMMdd')){throw 'RECOVERY_DAY_CHANGED'}
  $raw.Utc=[datetime]::UtcNow.ToString('o')
  $sealed=At58-Protect ($raw|ConvertTo-Json -Depth 30 -Compress) 'AT58-STRATEGY-INPUT-1'
  $roundtrip=(At58-Unprotect $sealed 'AT58-STRATEGY-INPUT-1')|ConvertFrom-Json
  if((At58S-Import $roundtrip).Hash -cne $fresh.State.SourceHash){throw 'RECOVERY_CACHE_VERIFICATION'}
  $script:RIPhase='WRITE_INPUT'
  $inputPath=Join-Path $owner.Root 'strategy-input.dpapi'
  if([IO.File]::Exists($inputPath)){
   $backupRoot=Ops-Inside $owner.Root (Join-Path $owner.Root 'input-recovery-backups')
   [void][IO.Directory]::CreateDirectory($backupRoot)
   $backupPath=Ops-Inside $backupRoot (Join-Path $backupRoot ([guid]::NewGuid().ToString('N')+'.dpapi'))
   Copy-Item -LiteralPath $inputPath -Destination $backupPath
   if((Ops-Hash $backupPath) -cne (Ops-Hash $inputPath)){throw 'RECOVERY_BACKUP_CHANGED'}
  }
  At58-Atomic $inputPath $sealed
  $script:RIPhase='COMPLETE'
  return [pscustomobject]@{Code='RECOVERY_INPUT_READY';Orders=@($fresh.Book.Orders).Count;Fills=@($fresh.Book.Fills).Count}
 }finally{$token='';$headers=$null;$raw=$null;$owner=$null}
}
function RI-Message($errorRecord){
 $code=$errorRecord.Exception.Message
 if($code -cnotmatch '^[A-Z0-9_]{1,80}$'){$code='RECOVERY_LOCAL_ERROR'}
 $messages=@{
  RECOVERY_VERSION='설치 버전이 이 복구 도구의 대상과 다릅니다.'
  RECOVERY_STATUS_STALE='현재 프로그램의 진단 상태를 확인할 수 없습니다. 프로그램을 그대로 두고 오류 코드를 알려주세요.'
  RECOVERY_STATE_UNSUITABLE='현재 상태가 입력 대기·실주문 꺼짐 조건과 다릅니다. 자동 복구를 중단했습니다.'
  RECOVERY_UNFINISHED_ORDERS='미체결 또는 미확정 주문이 있어 입력을 변경하지 않았습니다.'
  RECOVERY_LEDGER_REQUIRED='이 PC의 실전 원장을 확인해야 합니다.'
  RECOVERY_ENABLE_SHEET='Avata의 시트 연동에서 자동 반영을 켜고 설정을 저장하세요.'
  RECOVERY_SHEET_KEY='저장된 Google JSON 키 파일을 확인해야 합니다.'
  RECOVERY_SOURCE_CHANGED='시트 매매기준이 이 PC의 원장과 다릅니다. 기존 입력을 덮어쓰지 않았습니다.'
  SHEET_JOURNAL_UNKNOWN='시트에 현재 원장에서 확인할 수 없는 체결 기록이 있습니다.'
  SHEET_JOURNAL_CHANGED='시트 체결 기록과 이 PC의 원장 값이 다릅니다.'
  RECOVERY_LOCAL_CHANGED='확인 중 프로그램 또는 원장이 변경됐습니다. 입력을 덮어쓰지 않았습니다.'
 }
 $message='입력 복구를 완료하지 못했습니다.'
 if($messages.ContainsKey($code)){$message=$messages[$code]}
 return ($message+[Environment]::NewLine+'단계: '+$script:RIPhase+[Environment]::NewLine+'오류 코드: '+$code)
}
if($MyInvocation.InvocationName -eq '.'){return}
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
$form=[Windows.Forms.Form]::new();$form.Text='Avata 58.17.0 · 날짜 전환 입력 복구';$form.ClientSize=[Drawing.Size]::new(620,320);$form.StartPosition='CenterScreen';$form.Font=[Drawing.Font]::new('Malgun Gothic',10);$form.FormBorderStyle='FixedDialog';$form.MaximizeBox=$false
$intro=[Windows.Forms.Label]::new();$intro.SetBounds(20,15,580,85);$intro.Text=(@('복구할 PC에서 Avata를 켜둔 채 실행하세요.','이 PC의 원장과 시트의 기준을 대조하고, 이 PC의 입력 캐시만 복구합니다.','시트 내용·원장·실주문 승인·설치 프로그램은 변경하지 않습니다.') -join [Environment]::NewLine)
$button=[Windows.Forms.Button]::new();$button.SetBounds(20,105,260,40);$button.Text='입력 연결 복구'
$info=[Windows.Forms.TextBox]::new();$info.SetBounds(20,160,580,140);$info.Multiline=$true;$info.ReadOnly=$true;$info.ScrollBars='Vertical';$info.Text='복구 대기 · Google 시트는 읽기 권한으로만 조회합니다.'
$button.Add_Click({
 $button.Enabled=$false;$form.UseWaitCursor=$true
 try{
  $info.Text='확인 중… 최대 1분 정도 걸릴 수 있습니다.';$form.Refresh()
  $r=RI-Repair $LocalBase
  $info.Text=(@("입력 연결 복구 완료 · 주문 $($r.Orders)건 / 체결 $($r.Fills)건",'Avata에서 30~60초 안에 조회가 재개되는지 확인하세요.','계좌 대조가 완료된 뒤 종료 버튼을 다시 누를 수 있습니다.','실주문 시작은 아직 누르지 마세요.') -join [Environment]::NewLine)
  [void][Windows.Forms.MessageBox]::Show($form,$info.Text,'입력 복구 완료','OK','Information')
 }catch{
  $info.Text=RI-Message $_
  [void][Windows.Forms.MessageBox]::Show($form,$info.Text,'입력 복구 확인 필요','OK','Warning')
 }finally{$button.Enabled=$true;$form.UseWaitCursor=$false}
})
$form.Controls.AddRange(@($intro,$button,$info))
try{[void]$form.ShowDialog()}finally{$form.Dispose()}

