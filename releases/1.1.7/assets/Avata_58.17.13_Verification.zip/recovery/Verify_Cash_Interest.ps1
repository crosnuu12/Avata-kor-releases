﻿# Read-only recovery proof; this script never changes ledger balances or status.
function IP-CashProbe($owner,$state,$book){
 $today=(At58-Kst (At58-Now $owner)).ToString('yyyyMMdd')
 $e=At58I-Read $owner $state.StartDay $today
 $costs=At58X-Costs $owner $state.StartDay $today
 $s=At58-ReadSnapshot $owner
 if($s.Day -cne $today -or @($s.OpenOrdersToday).Count -or @($s.PriorUnresolved).Count){throw 'CASH_RECOVERY_OPEN_ORDERS'}
 $age=((At58-Now $owner)-(At58S-Utc $s.CompletedUtc)).TotalSeconds
 if($age -lt -2 -or $age -gt 15){throw 'CASH_RECOVERY_STALE'}
 $s|Add-Member CashInterestEvidence $e -Force
 $p=At58X-Reconcile $owner $state $book $s $costs
 if($p.InterestNet -le 0){throw 'CASH_RECOVERY_NO_INTEREST'}
 return [pscustomobject]@{Utc=$s.CompletedUtc;Net=$p.InterestNet;Proof=(At58-Hash (@($s.Day,$s.TargetQty,$s.TargetAverage,$s.Cash.D2,$p.Cash,$p.ActualCosts,$p.InterestProof) -join '|'))}
}
function IP-CashQuorum($first,$second){
 if($first.Proof -cne $second.Proof -or $first.Net -ne $second.Net -or (At58S-Utc $second.Utc) -le (At58S-Utc $first.Utc)){throw 'CASH_RECOVERY_NOT_STABLE'}
 return $true
}
function IP-VerifyInterestRecovery($paths,[string]$package){
 . (Join-Path $package 'bundle/payload/At58.Core.ps1')
 # These operations are forbidden even if a future read helper starts using them.
 function At58-Atomic {throw 'CASH_RECOVERY_WRITE_FORBIDDEN'}
 function At58X-Save {throw 'CASH_RECOVERY_WRITE_FORBIDDEN'}
 function At58T-Save {throw 'CASH_RECOVERY_WRITE_FORBIDDEN'}
 function At58T-Wire {throw 'CASH_RECOVERY_ORDER_FORBIDDEN'}
 $owner=$null
 try{
  $owner=At58-Context $paths.Data '0210A0';$owner.LiveHostProtocol=2
  $statePath=At58X-Path $owner;$bookPath=Join-Path (At58X-Context $owner).Root 'order-book.dpapi'
  $beforeState=IP-Hash $statePath;$beforeBook=IP-Hash $bookPath
  $state=At58X-Load $owner;$book=At58T-Load (At58X-Context $owner)
  if(!$state -or $state.TestOnly -ne $false -or @($book.Orders|Where-Object {$_.State -cnotin @('FILLED','CANCELLED','REJECTED')}).Count){throw 'CASH_RECOVERY_LEDGER_UNSAFE'}
  $a=IP-CashProbe $owner $state $book
  $b=IP-CashProbe $owner $state $book
  $null=IP-CashQuorum $a $b
  if((IP-Hash $statePath) -cne $beforeState -or (IP-Hash $bookPath) -cne $beforeBook){throw 'CASH_RECOVERY_LEDGER_CHANGED'}
  return $true
 }finally{if($owner){$owner.Token='';$owner.Credential=$null}}
}
