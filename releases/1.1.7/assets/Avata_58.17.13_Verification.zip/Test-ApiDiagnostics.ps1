﻿#requires -Version 5.1
param([string]$Root=$PSScriptRoot)
$ErrorActionPreference='Stop'
. (Join-Path $Root 'bundle/At58.Sheets.ps1')
. (Join-Path $Root 'bundle/payload/At58.Core.ps1')
. (Join-Path $Root 'tests/CashFixture.ps1')
$script:passed=0
function Check($ok,[string]$name){if(!$ok){throw ('FAILED: '+$name)};$script:passed++;'PASS '+$name}
$dir=Join-Path ([IO.Path]::GetTempPath()) ('avata-api-test-'+[guid]::NewGuid().ToString('N'))
$f=Cash-Fixture $dir;$o=$f.Owner
$script:api='9999';$script:stage='/trading/v1/orders/history'
function At58X-Input($owner){At58-Fail 'API_ERROR' $script:stage $script:api}
function At58X-Commands($owner,$box){}
function At58T-Wire {throw 'TEST_ORDER_FORBIDDEN'}
$r=At58X-Cycle $o
Check ($r.Status.Code -ceq 'API_ERROR' -and $r.Status.ApiCode -ceq '9999') 'live API error preserves numeric response code'
Check ($r.Status.Stage -ceq '/trading/v1/orders/history') 'live API error preserves request stage'
Check ($r.Status.State -ceq 'DISARMED' -and !$r.Status.ExecutionEnabled -and $r.Status.OrdersSent -eq 0) 'diagnostics do not authorize an order'
$box=At58X-Mailbox $o.RunId;$box.Mode='LIVE'
$null=At58X-ManagedCycle $o $box
$s=Get-Content -LiteralPath (Join-Path $dir 'status.json') -Raw | ConvertFrom-Json
Check ($s.ApiCode -ceq '9999' -and $s.Stage -ceq $script:stage -and $s.State -ceq 'READ_ERROR') 'remote-relay source status retains API details'
$log=Get-Content -LiteralPath (Join-Path $dir ('read-'+(At58-Kst (At58-Now $o)).ToString('yyyyMMdd')+'.jsonl')) -Tail 1 | ConvertFrom-Json
Check ($log.ApiCode -ceq '9999') 'persistent read log retains error code'
$script:api='secret token';$script:stage='https://example.invalid?account=123456'
$r=At58X-Cycle $o;$json=$r.Status|ConvertTo-Json -Compress
Check ($r.Status.ApiCode -ceq '' -and $r.Status.Stage -ceq 'UNKNOWN' -and $json -notmatch 'secret|123456|example.invalid') 'invalid metadata is redacted'
'API DIAGNOSTIC TESTS COMPLETE: '+$script:passed+' passed; no broker connection.'
