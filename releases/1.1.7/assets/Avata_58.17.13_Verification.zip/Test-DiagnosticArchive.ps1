﻿#requires -Version 5.1
param([string]$Root=$PSScriptRoot)
$ErrorActionPreference='Stop';Set-StrictMode -Version 2
. (Join-Path $Root 'bundle/At58.Ops.ps1')
. (Join-Path $Root 'bundle/At58.Sheets.ps1')
$script:checks=0
function Check($ok,[string]$message){if(!$ok){throw ('FAILED: '+$message)};$script:checks++;Write-Output ('PASS '+$message)}
$root=Join-Path ([IO.Path]::GetTempPath()) ('avata-archive-test-'+[guid]::NewGuid().ToString('N'))
[void][IO.Directory]::CreateDirectory($root)
$stamp=[datetime]::Parse('2026-11-05T01:00:00Z').ToUniversalTime().ToString('o')
$device='11111111-1111-4111-8111-111111111111'
$secret='ARCHIVE_PRIVATE_CANARY'
try{
 $faultRecord=[ordered]@{Utc=$stamp;State='REVIEW';Code='LIVE_ORDER_REVIEW';ApiCode='S607';Stage='LIVE_LEDGER';Detail='BROKER_REJECT_S607';Incident='22222222-2222-4222-8222-222222222222';Token=$secret;Account=$secret;Balance=99000;Orders=@($secret)}
 $items=@(
  [pscustomobject]@{File='read-20261105.jsonl';Data=(SheetDiag-Clean @{Utc=([datetime]$stamp).AddMinutes(-6).ToString('o');Code='OK';Stage='READ'});Context=$false},
  [pscustomobject]@{File='read-20261105.jsonl';Data=(SheetDiag-Clean @{Utc=([datetime]$stamp).AddMinutes(-4).ToString('o');Code='OK';Stage='READ'});Context=$false},
  [pscustomobject]@{File='read-20261105.jsonl';Data=(SheetDiag-Clean @{Utc=$stamp;Code='LISTENING';Stage='EXECUTION'});Context=$false},
  [pscustomobject]@{File='execution-20261105.jsonl';Data=(SheetDiag-Clean $faultRecord);Context=$false},
  [pscustomobject]@{File='read-20261105.jsonl';Data=(SheetDiag-Clean @{Utc=([datetime]$stamp).AddMinutes(1).ToString('o');Code='OK';Stage='READ'});Context=$false},
  [pscustomobject]@{File='read-20261105.jsonl';Data=(SheetDiag-Clean @{Utc=([datetime]$stamp).AddMinutes(3).ToString('o');Code='OK';Stage='READ'});Context=$false}
 )
 $selected=SheetDiag-SelectIncidentLogs $items ([datetime]$stamp)
 Check ($selected.Count -eq 4) 'only the diagnostic event and normal records inside the bounded context window are selected'
 Check (@($selected|Where-Object Context).Count -eq 3) 'normal context is labelled separately from the incident'
 Check ((SheetDiag-Clean @{ApiCode='S607'}).ApiCode -ceq 'S607') 'broker/API rejection code is retained'
 $snapshot=[pscustomobject]@{ArchiveLogs=@([pscustomobject]@{File='execution-20261105.jsonl';Data=(SheetDiag-Clean $faultRecord);Context=$false})}
 $script:failConfig=$true;$script:postCount=0;$script:postBodies=@()
 function SheetDiag-ArchiveConfig($headers,[string]$mainBase){if($script:failConfig){throw 'network unavailable'};return 'ARCHIVE_TEST_SHEET'}
 function SheetDiag-ArchiveTarget($headers,[string]$archiveId){return [pscustomobject]@{SpreadsheetId='ARCHIVE_TEST_SHEET';SheetId=77;Rows=1000}}
 function Invoke-RestMethod {param($Method,$Uri,$Headers,$ContentType,$Body,$TimeoutSec,$MaximumRedirection)
  if($Method -ceq 'Get'){return @{values=@()}}
  $bodyText=[Text.Encoding]::UTF8.GetString($Body);$script:postBodies+=,$bodyText;$script:postCount++
  if($bodyText.Contains($secret)){throw 'secret reached transport'}
  if($script:postCount -eq 1){throw 'simulated lost acknowledgement after write'}
  return @{spreadsheetId='ARCHIVE_TEST_SHEET';replies=@(@{})}
 }
 $failed=SheetDiag-ArchiveRun $snapshot @{} 'https://sheets.googleapis.com/v4/spreadsheets/MAIN_TEST' $device $root
 Check ($failed.Code -ceq 'DIAG_ARCHIVE_TRANSPORT_OR_STORAGE' -and @($failed.Pending).Count -eq 1) 'sanitized event stays in the local outbox while offline'
 $stateText=[IO.File]::ReadAllText((Join-Path $root 'diagnostics-archive-state.json'))
 Check (!$stateText.Contains($secret) -and !$stateText.Contains('99000')) 'local outbox excludes credentials and financial values'
 $script:failConfig=$false
 $uncertain=SheetDiag-ArchiveRun $snapshot @{} 'https://sheets.googleapis.com/v4/spreadsheets/MAIN_TEST' $device $root
 Check ($uncertain.Code -ceq 'DIAG_ARCHIVE_TRANSPORT_OR_STORAGE' -and @($uncertain.Pending).Count -eq 1) 'uncertain remote result remains queued with a fixed row ID'
 $retry=SheetDiag-ArchiveRun $snapshot @{} 'https://sheets.googleapis.com/v4/spreadsheets/MAIN_TEST' $device $root
 Check ($retry.Code -ceq 'OK' -and @($retry.Pending).Count -eq 0 -and $retry.NextSequence -eq 1) 'retry succeeds without allocating a duplicate row'
 $firstBody=ConvertFrom-Json $script:postBodies[0];$retryBody=ConvertFrom-Json $script:postBodies[1]
 Check ($script:postBodies.Count -eq 2 -and $firstBody.requests[-1].updateCells.start.rowIndex -eq $retryBody.requests[-1].updateCells.start.rowIndex -and $firstBody.requests[-1].updateCells.rows[0].values[0].userEnteredValue.stringValue -ceq $retryBody.requests[-1].updateCells.rows[0].values[0].userEnteredValue.stringValue) 'retry resends the same sanitized row to the same fixed destination'
 Check (!$script:postBodies[0].Contains($secret) -and $script:postBodies[0].Contains('S607')) 'remote payload keeps API rejection code and excludes private canary'
 Write-Output ('DIAGNOSTIC ARCHIVE TEST PASSED: '+$script:checks+' checks; local queue and mocked transport only')
}finally{Remove-Item -LiteralPath $root -Recurse -Force}
