﻿param([string]$Root=$PSScriptRoot)
$ErrorActionPreference='Stop';Set-StrictMode -Version 2
. (Join-Path $Root 'bundle/At58.Ops.ps1')
. (Join-Path $Root 'bundle/At58.Sheets.ps1')
. (Join-Path $Root 'bundle/payload/At58.Core.ps1')
. (Join-Path $Root 'tests/CashFixture.ps1')
. (Join-Path $Root 'recovery/Verify_Cash_Interest.ps1')
$script:checks=0;$script:network=0
function Check($ok,[string]$name){if(!$ok){throw ('FAILED: '+$name)};$script:checks++;Write-Output ('PASS '+$name)}
function Reject($body,[string]$code,[string]$name){$found='';try{& $body|Out-Null}catch{$found=(At58-Error $_).Code;if($found -ceq 'UNEXPECTED'){$found=$_.Exception.Message}};Check ($found -ceq $code) ($name+' ['+$found+']')}
function Invoke-RestMethod {$script:network++;throw 'NETWORK_FORBIDDEN'}
function At58T-Wire {$script:network++;throw 'ORDER_FORBIDDEN'}
function Interest([string]$day='20261103',[string]$id='61',[decimal]$gross=401,[decimal]$tax=50){return [pscustomobject]@{tr_date=$day;tran_srno=$id;smcd_name='예탁금이용료';cncl_yn='N';iscd='';tr_amt=$gross;intx=$tax;rstx=0;frcr_tr_amt='0.000';deal_fee=0;fee=0;trtx=0;srtx=0}}
function Evidence($owner,$rows,[string]$from='20261102',[string]$to='20261103'){$parsed=At58I-Rows $rows $from $to;return [pscustomobject]@{Schema='AT-CASH-INTEREST-1';Scope=$owner.Scope;From=$from;To=$to;Utc=$script:cashClock.ToString('o');Rows=@($parsed)}}
$work=Join-Path ([IO.Path]::GetTempPath()) ('ACI-'+[guid]::NewGuid().ToString('N').Substring(0,12))
[void][IO.Directory]::CreateDirectory($work)
try{
 $f=Cash-Fixture (Join-Path $work 'legacy');$o=$f.Owner;$st=$f.State;$s=$f.Snapshot;$b=$f.Book;$source=$f.Source
 $basis=$st.BaselineD2;$seedHash=At58-Hash ($st.Seed|ConvertTo-Json -Depth 50 -Compress)
 $script:cashClock=$script:cashClock.AddDays(1);$s.Day='20261103';$s.PriorDay='20261102';$s.CompletedUtc=$script:cashClock.ToString('o');$s.Cash.D2+=351
 Reject {At58X-Reconcile $o $st $b $s @()} 'LIVE_CASH_WAIT' 'original cash comparison reproduces verified interest-only discrepancy'
 $r=At58I-Rows @((Interest)) '20261102' '20261103'
 Check ($r.Count -eq 1 -and $r[0].Gross -eq 401 -and $r[0].IncomeTax -eq 50 -and $r[0].Net -eq 351) 'gross 401 less recorded tax 50 yields net 351 without a tax-rate estimate'
 $s|Add-Member CashInterestEvidence (Evidence $o @((Interest))) -Force
 $p=At58X-Reconcile $o $st $b $s @()
 Check ($p.Cash -eq $source.Ledger.Cash+351 -and $p.InterestNet -eq 351) 'broker-backed interest reconciles exact cash difference'
 Check ($p.Realized -eq $source.Ledger.Realized -and $p.ActualCosts -eq 0) 'interest is not recorded as trading profit or trading fee'
 $again=At58X-Reconcile $o $st $b $s @()
 Check ($again.Cash -eq $p.Cash -and $st.BaselineD2 -eq $basis -and (At58-Hash ($st.Seed|ConvertTo-Json -Depth 50 -Compress)) -ceq $seedHash) 'repeat reconciliation preserves frozen baseline and cannot accumulate interest'
 $s.Cash.D2+=500
 Reject {At58X-Reconcile $o $st $b $s @()} 'LIVE_CASH_WAIT' 'unexplained additional deposit remains blocked'
 $s.Cash.D2-=500
 Reject {At58I-Rows @((Interest),(Interest)) '20261102' '20261103'} 'LIVE_INTEREST_DUPLICATE' 'duplicate transaction identity cannot double credit cash'
 $bad=Interest;$bad.intx=402
 Reject {At58I-Rows @($bad) '20261102' '20261103'} 'LIVE_INTEREST_AMOUNT' 'tax greater than interest is rejected'
 $bad=Interest;$bad.PSObject.Properties.Remove('intx')
 Reject {At58I-Rows @($bad) '20261102' '20261103'} 'LIVE_INTEREST_SCHEMA' 'missing tax is not interpreted as zero'
 $bad=Interest;$bad.frcr_tr_amt='1.000'
 Reject {At58I-Rows @($bad) '20261102' '20261103'} 'LIVE_INTEREST_UNSUPPORTED' 'foreign currency does not enter KRW interest'
 $bad=Interest;$bad.fee=1
 Reject {At58I-Rows @($bad) '20261102' '20261103'} 'LIVE_INTEREST_UNSUPPORTED' 'unreviewed additional fee blocks automatic credit'
 $bad=Interest;$bad.smcd_name='입금';Check ((At58I-Rows @($bad) '20261102' '20261103').Count -eq 0) 'manual transfer is not classified as interest'
 $bad.smcd_name='예탁금이용료환급';Check ((At58I-Rows @($bad) '20261102' '20261103').Count -eq 0) 'unrecognized reversal description is not guessed'
 $bad=Interest '20261104'
 Reject {At58I-Rows @($bad) '20261102' '20261103'} 'LIVE_INTEREST_DATES' 'future transaction rejected'
 $old=At58S-Clone $s.CashInterestEvidence;$s.CashInterestEvidence.Scope='wrong'
 Reject {At58X-Reconcile $o $st $b $s @()} 'LIVE_INTEREST_IDENTITY' 'another account evidence cannot reconcile cash'
 $s.CashInterestEvidence=$old;$s.CashInterestEvidence.Utc=$script:cashClock.AddMinutes(-2).ToString('o')
 Reject {At58X-Reconcile $o $st $b $s @()} 'LIVE_INTEREST_STALE' 'stale interest evidence cannot authorize reconciliation'
 $s.CashInterestEvidence=Evidence $o @((Interest))
 $st|Add-Member InterestAccepted @($p.InterestAccepted) -Force
 $s.CashInterestEvidence=Evidence $o @()
 Reject {At58X-Reconcile $o $st $b $s @()} 'LIVE_INTEREST_CHANGED' 'missing previously accepted interest forces review'
 $bad=Interest;$bad.cncl_yn='Y';$s.CashInterestEvidence=Evidence $o @($bad)
 Reject {At58X-Reconcile $o $st $b $s @()} 'LIVE_INTEREST_CHANGED' 'cancelled previously accepted credit cannot disappear silently'
 $s.CashInterestEvidence=Evidence $o @((Interest '20261103' '61' 402 50))
 Reject {At58X-Reconcile $o $st $b $s @()} 'LIVE_INTEREST_CHANGED' 'changed previously accepted amount blocks reconciliation'
 $st.PSObject.Properties.Remove('InterestAccepted');$s.CashInterestEvidence=Evidence $o @((Interest '20261102'))
 Reject {At58X-Reconcile $o $st $b $s @()} 'LIVE_CASH_WAIT' 'legacy same-day uncertainty is not repaired by assuming a baseline'
 $s.CashInterestEvidence=Evidence $o @((Interest))
 At58X-Save $o $st
 $r1=At58X-Step $o $source $s @() $null '하락' '허용'
 Check ($r1.State -ceq 'DISARMED' -and !$r1.ExecutionEnabled -and $r1.Confirmations -eq 1 -and $r1.OrdersSent -eq 0) 'first verified interest snapshot remains disarmed at one confirmation'
 $script:cashClock=$script:cashClock.AddSeconds(5);$s.CompletedUtc=$script:cashClock.ToString('o');$s.CashInterestEvidence=Evidence $o @((Interest))
 $r2=At58X-Step $o $source $s @() $null '하락' '허용'
 Check ($r2.Reconciled -and $r2.Confirmations -eq 2 -and $r2.Portfolio.InterestNet -eq 351 -and $r2.OrdersSent -eq 0) 'two fresh reads confirm interest without submitting an order'
 $saved=At58X-Load $o
 Check ($saved.InterestAccepted.Count -eq 1 -and $saved.BaselineD2 -eq $basis) 'accepted evidence persists separately from original cash baseline'
 $o.RunId=[guid]::NewGuid().ToString();$script:cashClock=$script:cashClock.AddSeconds(5);$s.CompletedUtc=$script:cashClock.ToString('o');$s.CashInterestEvidence=Evidence $o @((Interest))
 $restart=At58X-Step $o $source $s @() $null '하락' '허용'
 Check ($restart.State -ceq 'DISARMED' -and $restart.Confirmations -eq 1 -and $restart.Portfolio.Cash -eq $p.Cash) 'restart neither rearms nor credits interest twice'
 # A new baseline must exclude interest already reflected in its captured D+2.
 $newOwner=At58-Context (Join-Path $work 'new') '0210A0' ([pscustomobject]@{AppKey='synthetic-interest-key';AppSecret='synthetic-interest-secret'});$newOwner.LiveHostProtocol=2;$newOwner.Clock={return $script:cashClock}
 $script:cashClock=[datetime]::SpecifyKind([datetime]'2026-11-02T01:00:00',[DateTimeKind]::Utc)
 $ns=At58S-Clone $s;$ns.Day='20261102';$ns.CompletedUtc=$script:cashClock.ToString('o');$ns.CashInterestEvidence=Evidence $newOwner @((Interest '20261102')) '20261102' '20261102'
 $newState=At58X-Initialize $newOwner $source $ns @();$nb=At58T-Load (At58X-Context $newOwner)
 $np=At58X-Reconcile $newOwner $newState $nb $ns @()
 Check ($np.InterestNet -eq 0 -and $np.Cash -eq $source.Ledger.Cash -and $newState.InterestBaseline.Count -eq 1) 'initialization captures existing interest without double-counting baseline cash'
 $ns.Cash.D2+=100;$ns.CashInterestEvidence=Evidence $newOwner @((Interest '20261102'),(Interest '20261102' '62' 100 0)) '20261102' '20261102'
 $np=At58X-Reconcile $newOwner $newState $nb $ns @()
 Check ($np.InterestNet -eq 100) 'new same-day interest after an explicit baseline is recognized once'
 # Real read/pagination adapter is tested with synthetic broker responses.
 $o.Transport={param($method,$path,$query,$body,$token)
  if($method -cne 'GET' -or $path -cne '/accounts/v1/me/transactions'){throw 'UNEXPECTED_READ'}
  if(!$query.ContainsKey('tr_cont')){return @{rsp_cd='5762';rsp_sub_msg='';data=@();tr_cont='1';tr_cont_key='padded  '}}
  if($query.tr_cont_key -cne 'padded  '){throw 'CURSOR_TRIMMED'}
  return @{rsp_cd='5766';rsp_sub_msg='';data=@((Interest));tr_cont='0'}
 };$o.Token='synthetic';$o.TokenUntil=$script:cashClock.AddHours(1);$o.Mac='001122334455';$o.NoWait=$true
 $ev=At58I-Read $o '20261102' '20261103'
 Check ($ev.Rows.Count -eq 1 -and $ev.Rows[0].Net -eq 351) 'complete paginated read preserves continuation token and returns exact net interest'
 $o.Transport={return @{rsp_cd='5762';rsp_sub_msg='';data=@();tr_cont='1';tr_cont_key='same'}}
 Reject {At58I-Read $o '20261102' '20261103'} 'PAGE_INCOMPLETE' 'incomplete pagination cannot produce an accepted interest total'
 # Read-only installation proof uses the same full reconciliation as the program.
 $script:cashClock=[datetime]::SpecifyKind([datetime]'2026-11-03T01:00:00',[DateTimeKind]::Utc)
 $s.CompletedUtc=$script:cashClock.ToString('o');$script:probeSnapshot=$s;$script:probeRows=@((Interest));$script:probeOwner=$o
 function At58-List($owner,$path,$query){if($path -ceq '/accounts/v1/me/transactions'){return ,$script:probeRows};if($path -ceq '/accounts/v1/me/profit-loss'){return ,@()};throw 'UNEXPECTED_READ'}
 function At58-ReadSnapshot($owner){$script:cashClock=$script:cashClock.AddSeconds(1);$x=At58S-Clone $script:probeSnapshot;$x.PSObject.Properties.Remove('Execution');$x.CompletedUtc=$script:cashClock.ToString('o');return $x}
 $a=IP-CashProbe $o $saved $b;$z=IP-CashProbe $o $saved $b
 Check ((IP-CashQuorum $a $z) -eq $true -and $a.Net -eq 351) 'installer obtains two independent matching cash and holdings proofs'
 Reject {IP-CashQuorum $a $a} 'CASH_RECOVERY_NOT_STABLE' 'reusing one snapshot is not a recovery quorum'
 $z.Proof='changed';Reject {IP-CashQuorum $a $z} 'CASH_RECOVERY_NOT_STABLE' 'unstable cash recovery proof is rejected'
 $script:probeSnapshot.Cash.D2+=7
 Reject {IP-CashProbe $o $saved $b} 'LIVE_CASH_WAIT' 'installer cannot waive an unexplained residual cash difference'
 $script:probeSnapshot.Cash.D2-=7;$script:probeSnapshot.OpenOrdersToday=@(@{Id='synthetic'})
 Reject {IP-CashProbe $o $saved $b} 'CASH_RECOVERY_OPEN_ORDERS' 'broker open orders block recovery even if old status claimed zero'
 $script:probeSnapshot.OpenOrdersToday=@()
 # Exercise the production cycle wiring: no separately invoked repair script.
 function At58X-Input($owner){return [pscustomobject]@{Source=$script:cycleSource;Modes=@{'하락'='허용'}}}
 function At58S-Market($candles,$snapshot,$policy){return [pscustomobject]@{Name='하락'}}
 function At58E-Run($owner,$snapshot){return [pscustomobject]@{Connected=$true;ReceiptAck=$true;FillAck=$true;Pending=0;Gaps=0}}
 function At58-List($owner,$path,$query){
  if($path -ceq '/accounts/v1/me/transactions'){return ,$script:probeRows}
  if($path -cin @('/accounts/v1/me/profit-loss','/market/v1/candles/days')){return ,@()}
  throw 'UNEXPECTED_READ'
 }
 $script:cycleSource=$source;$script:probeSnapshot|Add-Member ExecutionEnabled $false -Force
 $cycle=At58X-Cycle $o
 Write-Output ('CYCLE RESULT: '+($cycle.Result|Select-Object State,Code,Confirmations|ConvertTo-Json -Compress))
 Check ($cycle.Result.State -ceq 'DISARMED' -and $cycle.Result.Portfolio.InterestNet -eq 351 -and $cycle.Result.OrdersSent -eq 0) 'production cycle automatically fetches and reconciles interest while disarmed'
 $script:cashClock=$script:cashClock.AddDays(1);$script:probeSnapshot.Day='20261104';$script:probeSnapshot.Cash.D2+=100
 $script:probeRows=@((Interest),(Interest '20261104' '62' 100 0))
 $cycle=At58X-Cycle $o
 Write-Output ('CYCLE RESULT: '+($cycle.Result|Select-Object State,Code,Confirmations|ConvertTo-Json -Compress))
 Check ($cycle.Result.Portfolio.InterestNet -eq 451 -and $cycle.Result.Portfolio.Cash -eq $source.Ledger.Cash+451 -and !$cycle.Result.ExecutionEnabled) 'next-day cycle adds only the newly verified net interest and retains order-off state'
 # No-trade day used to throw under StrictMode and freeze historical asset detail.
 $rows=@(@('날짜','차수','구분','가격','수량','금액'),@(46328,1,'매수',100,3,300))
 $ledger=Asset-Ledger $rows;$report=Asset-CostReport $ledger @()
 $asset=[pscustomobject]@{Day='20261103';TargetQty=3;Cash=[pscustomobject]@{};Valuation=[pscustomobject]@{}}
 $payload=Asset-Payload $asset $ledger $report $null
 $daily=@($payload.Requests|Where-Object {$_.ContainsKey('updateCells') -and $_.updateCells.start.rowIndex -eq 24 -and $_.updateCells.start.columnIndex -eq 4})[0]
 Check ($daily.updateCells.rows[0].values[0].userEnteredValue.numberValue -eq 0) 'no-trade day produces zero daily realized gain instead of ASSET_REPORT_RETRY'
 Check ($script:network -eq 0) 'all cash tests used synthetic fixtures and made zero network or broker order calls'
 Write-Output ('CASH INTEREST TESTS COMPLETE: '+$script:checks+' passed; synthetic local state only.')
}finally{
 $full=[IO.Path]::GetFullPath($work);$parent=[IO.Path]::GetFullPath([IO.Path]::GetTempPath()).TrimEnd('\')+'\'
 if(!$full.StartsWith($parent,[StringComparison]::OrdinalIgnoreCase) -or [IO.Path]::GetFileName($full) -cnotmatch '^ACI-[a-f0-9]{12}$'){throw 'CLEANUP_PATH'}
 if(Test-Path -LiteralPath $full){Remove-Item -LiteralPath $full -Recurse -Force}
}
