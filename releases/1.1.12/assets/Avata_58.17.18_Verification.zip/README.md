# Avata 1.1.12 / 58.17.18

Allow normal slash-leading API stages in diagnostic archives and resume already-sequenced pending rows without resetting the queue. Report unknown queue state explicitly. Preserve sanitized worker exception provenance for remote diagnosis while retaining existing REVIEW and stop behavior. The initiating worker exception in the reported incident is not yet identified.

Run Run-Checks.ps1 under Windows PowerShell 5.1, then Test-TrayRestore.ps1 -HostedRunner, Test-DesktopStartup.ps1, and Test-RecoveryDialog.ps1 -HostedRunner. Tests use synthetic data only. This source archive is not an installer; the runtime update package contains only bundle/. Archived host scripts are test/source material and must not overwrite installed trust keys.

Final validation and publication evidence lives in releases/1.1.12/STATUS.md and the release-worker-diagnostics GitHub Actions workflow. PC installation and recovery require independent confirmation.
