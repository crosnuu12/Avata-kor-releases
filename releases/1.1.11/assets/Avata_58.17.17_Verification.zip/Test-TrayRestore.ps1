﻿#requires -Version 5.1
param([string]$Root=$PSScriptRoot,[switch]$HostedRunner)
$ErrorActionPreference='Stop';Set-StrictMode -Version 2
if(!$HostedRunner -or $env:GITHUB_ACTIONS -cne 'true' -or $env:RUNNER_ENVIRONMENT -cne 'github-hosted'){throw 'ISOLATED_HOSTED_WINDOWS_REQUIRED'}
Add-Type -AssemblyName System.Windows.Forms,System.Drawing
. (Join-Path $Root 'bundle/payload/At58.Core.ps1')
At58Window-Native
$script:checks=0
$script:At58TrayEnabled=$true;$script:At58WindowChanging=$false
function Check([bool]$ok,[string]$name){if(!$ok){throw ('FAIL '+$name)};$script:checks++;Write-Output ('PASS '+$name)}
function IsRestored {return $form.Visible -and !$form.TrayHidden -and $form.ShowInTaskbar -and $form.WindowState -eq [Windows.Forms.FormWindowState]::Normal}
function Minimize { $form.WindowState=[Windows.Forms.FormWindowState]::Minimized;[Windows.Forms.Application]::DoEvents() }
$DataRoot=Join-Path $env:RUNNER_TEMP ('AvataTrayRestore-'+[guid]::NewGuid().ToString('N'))
[void][IO.Directory]::CreateDirectory($DataRoot)
$form=[AvataTrayWindow]::new();$form.TrayHidden=$true;$form.ShowInTaskbar=$false
$trayMenu=[Windows.Forms.ContextMenuStrip]::new();$trayOpen=$trayMenu.Items.Add('Open');$tray=[Windows.Forms.NotifyIcon]::new();$tray.Icon=[Drawing.SystemIcons]::Application
$trayMode=[Windows.Forms.CheckBox]::new();$trayMode.Checked=$true
try{
 $tokens=$null;$errors=$null
 $app=Join-Path $Root 'bundle/payload/esbada_Merits_AT_v58.ps1'
 $ast=[Management.Automation.Language.Parser]::ParseFile($app,[ref]$tokens,[ref]$errors)
 if($errors.Count){throw 'APPLICATION_PARSE'}
 foreach($name in @('Tray-Restore','Tray-Minimize','Tray-SetMode')){
  $definition=$ast.Find({param($n) $n -is [Management.Automation.Language.FunctionDefinitionAst] -and $n.Name -ceq $name},$true)
  if(!$definition){throw 'TRAY_FUNCTION_MISSING'}
  . ([scriptblock]::Create($definition.Extent.Text))
 }
 $source=[IO.File]::ReadAllLines($app)
 foreach($prefix in @('$trayOpen.Add_Click(','$tray.Add_MouseDoubleClick(','$form.Add_Resize(','$trayMode.Add_CheckedChanged(')){
  $lines=@($source|Where-Object {$_.TrimStart().StartsWith($prefix,[StringComparison]::Ordinal)})
  if($lines.Count -ne 1){throw 'TRAY_EVENT_MISSING'}
  . ([scriptblock]::Create($lines[0]))
 }
 $raise=$tray.GetType().GetMethod('OnMouseDoubleClick',[Reflection.BindingFlags]'NonPublic,Instance')
 if(!$raise){throw 'TRAY_MOUSE_EVENT_MISSING'}
 function DoubleClick([Windows.Forms.MouseButtons]$button=[Windows.Forms.MouseButtons]::Left){
  $args=[Windows.Forms.MouseEventArgs]::new($button,2,0,0,0)
  $null=$raise.Invoke($tray,[object[]]@($args));[Windows.Forms.Application]::DoEvents()
 }
 $form.Show();[Windows.Forms.Application]::DoEvents()
 Check (!$form.Visible -and $form.TrayHidden -and !$form.ShowInTaskbar) 'first startup stays hidden'
 DoubleClick ([Windows.Forms.MouseButtons]::Right)
 Check (!$form.Visible -and $form.TrayHidden) 'right mouse event does not unexpectedly restore the window'
 DoubleClick
 Check (IsRestored) 'actual double-click event restores the initially hidden form'
 Minimize
 Check (!$form.Visible -and $form.TrayHidden -and !$form.ShowInTaskbar) 'actual resize event minimizes to tray'
 $trayOpen.PerformClick();[Windows.Forms.Application]::DoEvents()
 Check (IsRestored) 'actual Open menu event restores a minimized form'
 Minimize;DoubleClick
 Check (IsRestored) 'actual double-click event restores a minimized form'
 $cyclesOk=$true
 for($i=0;$i -lt 10;$i++){
  Minimize
  if($form.Visible -or !$form.TrayHidden -or $form.ShowInTaskbar){$cyclesOk=$false;break}
  if(($i%2) -eq 0){DoubleClick}else{$trayOpen.PerformClick();[Windows.Forms.Application]::DoEvents()}
  if(!(IsRestored)){$cyclesOk=$false;break}
 }
 Check $cyclesOk 'ten alternating minimize/menu/double-click cycles restore correctly'
 Minimize;$form.Show();$form.BringToFront();[Windows.Forms.Application]::DoEvents()
 Check (!$form.Visible -and $form.TrayHidden -and !$form.ShowInTaskbar) 'unsolicited Show and BringToFront still cannot expose a hidden window'
 $trayOpen.PerformClick();[Windows.Forms.Application]::DoEvents()
 Check (IsRestored) 'explicit Open still works after an unsolicited display attempt'
 Check (At58Window-LoadTray $DataRoot) 'minimize preference remains tray startup for the next run'
 $trayMode.Checked=$false;[Windows.Forms.Application]::DoEvents()
 Check (!$script:At58TrayEnabled -and !$tray.Visible -and (IsRestored)) 'turning off tray mode keeps the main-PC window visible and removes its tray icon'
 Check (!(At58Window-UseTray $DataRoot) -and !(At58Window-LoadTray $DataRoot)) 'desktop mode is saved for the next restart and update'
 Minimize
 Check ($form.Visible -and !$form.TrayHidden -and $form.ShowInTaskbar -and $form.WindowState -eq [Windows.Forms.FormWindowState]::Minimized) 'desktop minimize stays on the taskbar instead of entering tray'
 $form.WindowState=[Windows.Forms.FormWindowState]::Normal;[Windows.Forms.Application]::DoEvents()
 Check (IsRestored) 'desktop taskbar restore returns to a normal window'
 $trayMode.Checked=$true;[Windows.Forms.Application]::DoEvents()
 Check ($script:At58TrayEnabled -and $tray.Visible -and (At58Window-UseTray $DataRoot)) 'explicitly enabling tray mode restores mini-PC behavior'
 Minimize;DoubleClick
 Check (IsRestored) 'tray restoration still works after changing modes'
 $trayMode.Checked=$false;[Windows.Forms.Application]::DoEvents();$form.Dispose()
 $initial=@($source|Where-Object {$_.TrimStart().StartsWith('$form=[AvataTrayWindow]::new();',[StringComparison]::Ordinal)})
 if($initial.Count -ne 1){throw 'FORM_INITIALIZER_MISSING'}
 . ([scriptblock]::Create($initial[0]))
 $form.Show();[Windows.Forms.Application]::DoEvents()
 Check (IsRestored) 'actual application initializer opens a fresh desktop-mode window'
  Check ($form.Text -match '^Avata 1\.1\.11(?:\s|$)') 'application title shows official version 1.1.11'
 Write-Output ('TRAY RESTORE TESTS COMPLETE: '+$script:checks+' passed; isolated hosted Windows; actual application event handlers; no credentials, network or orders.')
}finally{
 $trayMode.Dispose();$tray.Dispose();$trayMenu.Dispose();$form.Dispose()
 $safe=[IO.Path]::GetFullPath($DataRoot);$temp=[IO.Path]::GetFullPath($env:RUNNER_TEMP).TrimEnd('\')+'\'
 if(!$safe.StartsWith($temp,[StringComparison]::OrdinalIgnoreCase) -or [IO.Path]::GetFileName($safe) -cnotmatch '^AvataTrayRestore-[a-f0-9]{32}$'){throw 'TEST_CLEANUP_PATH'}
 Remove-Item -LiteralPath $safe -Recurse -Force
}
