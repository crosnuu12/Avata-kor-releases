﻿#requires -Version 5.1
param([string]$Root=$PSScriptRoot)
$ErrorActionPreference='Stop';Set-StrictMode -Version 2
. (Join-Path $Root 'bundle/At58.Ops.ps1')
. (Join-Path $Root 'bundle/At58.Sheets.ps1')
$script:checks=0
function Check($ok,[string]$message){if(!$ok){throw ('FAILED: '+$message)};$script:checks++;Write-Output ('PASS '+$message)}
function Throws([scriptblock]$action,[string]$code){$actual='';try{$null=& $action}catch{$actual=$_.Exception.Message};Check ($actual -ceq $code) $code}
$root=Join-Path ([IO.Path]::GetTempPath()) ('avata-archive-test-'+[guid]::NewGuid().ToString('N'))
[void][IO.Directory]::CreateDirectory($root)
$stamp=[datetime]::Parse('2026-11-05T01:00:00Z').ToUniversalTime().ToString('o')
$device='11111111-1111-4111-8111-111111111111'
$secret='ARCHIVE_PRIVATE_CANARY'
try{
 $faultRecord=[ordered]@{Utc=$stamp;State='REVIEW';Code='LIVE_ORDER_REVIEW';ApiCode='S607';Stage='LIVE_LEDGER';Detail='BROKER_REJECT_S607';Incident='22222222-2222-4222-8222-222222222222';Token=$secret;Account=$secret;Balance=99000;Orders=@($secret)}
 $items=@(
  [pscustomobject]@{File='read-20261105.jsonl';Data=(SheetDiag-Clean @{Utc=([datetime]$stamp).AddMinutes(-6).ToString('o');Code='OK';Stage='READ'});Context=$false},
  [pscustomobject]@{File='read-20261105.jsonl';Data=(SheetDiag-Clean @{Utc=([datetime]$stamp).AddMinutes(-4).ToString('o');Code='OK';Stage='READ'});Context=$false},
  [pscustomobject]@{File='read-20261105.jsonl';Data=(SheetDiag-Clean @{Utc=$stamp;Code='LISTENING';Stage='EXECUTION'});Context=$false},
  [pscustomobject]@{File='execution-20261105.jsonl';Data=(SheetDiag-Clean $faultRecord);Context=$false},
  [pscustomobject]@{File='read-20261105.jsonl';Data=(SheetDiag-Clean @{Utc=([datetime]$stamp).AddMinutes(1).ToString('o');Code='OK';Stage='READ'});Context=$false},
  [pscustomobject]@{File='read-20261105.jsonl';Data=(SheetDiag-Clean @{Utc=([datetime]$stamp).AddMinutes(3).ToString('o');Code='OK';Stage='READ'});Context=$false}
 )
 $selected=SheetDiag-SelectIncidentLogs $items ([datetime]$stamp)
 Check ($selected.Count -eq 4) 'only the diagnostic event and normal records inside the bounded context window are selected'
 Check (@($selected|Where-Object Context).Count -eq 3) 'normal context is labelled separately from the incident'
 Check ((SheetDiag-Clean @{ApiCode='S607'}).ApiCode -ceq 'S607') 'broker/API rejection code is retained'
 $snapshot=[pscustomobject]@{ArchiveLogs=@([pscustomobject]@{File='execution-20261105.jsonl';Data=(SheetDiag-Clean $faultRecord);Context=$false})}
 $script:failConfig=$true;$script:postCount=0;$script:postBodies=@();$script:loseNextAck=$true
 $script:remoteResponse=@{range="'진단로그'!A2:A1000";majorDimension='ROWS'}
 function SheetDiag-ArchiveConfig($headers,[string]$mainBase){if($script:failConfig){throw 'network unavailable'};return 'ARCHIVE_TEST_SHEET'}
 function SheetDiag-ArchiveTarget($headers,[string]$archiveId){return [pscustomobject]@{SpreadsheetId='ARCHIVE_TEST_SHEET';SheetId=77;Rows=1000}}
 function Invoke-RestMethod {param($Method,$Uri,$Headers,$ContentType,$Body,$TimeoutSec,$MaximumRedirection)
  if($Method -ceq 'Get'){return $script:remoteResponse}
  $bodyText=[Text.Encoding]::UTF8.GetString($Body);$script:postBodies+=,$bodyText;$script:postCount++
  if($bodyText.Contains($secret)){throw 'secret reached transport'}
  if($script:loseNextAck){$script:loseNextAck=$false;throw 'simulated lost acknowledgement after write'}
  $parsed=$bodyText|ConvertFrom-Json
  return @{spreadsheetId='ARCHIVE_TEST_SHEET';replies=@($parsed.requests|ForEach-Object {@{}})}
 }
 $failed=SheetDiag-ArchiveRun $snapshot @{} 'https://sheets.googleapis.com/v4/spreadsheets/MAIN_TEST' $device $root
 Check ($failed.Code -ceq 'DIAG_ARCHIVE_TRANSPORT_OR_STORAGE' -and @($failed.Pending).Count -eq 1) 'sanitized event stays in the local outbox while offline'
 $stateText=[IO.File]::ReadAllText((Join-Path $root 'diagnostics-archive-state.json'))
 Check (!$stateText.Contains($secret) -and !$stateText.Contains('99000')) 'local outbox excludes credentials and financial values'
 $script:failConfig=$false
 $uncertain=SheetDiag-ArchiveRun $snapshot @{} 'https://sheets.googleapis.com/v4/spreadsheets/MAIN_TEST' $device $root
 Check ($uncertain.Code -ceq 'DIAG_ARCHIVE_TRANSPORT_OR_STORAGE' -and @($uncertain.Pending).Count -eq 1) 'uncertain remote result remains queued with a fixed row ID'
 $retry=SheetDiag-ArchiveRun $snapshot @{} 'https://sheets.googleapis.com/v4/spreadsheets/MAIN_TEST' $device $root
 Check ($retry.Code -ceq 'OK' -and @($retry.Pending).Count -eq 0 -and $retry.NextSequence -eq 1) 'retry succeeds without allocating a duplicate row'
 $firstBody=ConvertFrom-Json $script:postBodies[0];$retryBody=ConvertFrom-Json $script:postBodies[1]
 Check ($script:postBodies.Count -eq 2 -and $firstBody.requests[-1].updateCells.start.rowIndex -eq $retryBody.requests[-1].updateCells.start.rowIndex -and $firstBody.requests[-1].updateCells.rows[0].values[0].userEnteredValue.stringValue -ceq $retryBody.requests[-1].updateCells.rows[0].values[0].userEnteredValue.stringValue) 'retry resends the same sanitized row to the same fixed destination'
 Check (!$script:postBodies[0].Contains($secret) -and $script:postBodies[0].Contains('S607')) 'remote payload keeps API rejection code and excludes private canary'
 # The real empty Sheets response omits values; strict mode must also accept it.
 $target=SheetDiag-ArchiveTarget @{} 'ARCHIVE_TEST_SHEET'
 $emptyResponses=@(
  [pscustomobject]@{range="'진단로그'!A2:A1000";majorDimension='ROWS'},
  [pscustomobject]@{range="'진단로그'!A2:A1000";majorDimension='ROWS';values=$null},
  [pscustomobject]@{range="'진단로그'!A2:A1000";majorDimension='ROWS';values=@()}
 )
 foreach($response in $emptyResponses){
  $script:remoteResponse=$response
  $empty=SheetDiag-ArchiveReadState (Join-Path $root ([guid]::NewGuid().ToString('N')))
  $empty=SheetDiag-ArchiveRecoverRemote $empty $target @{}
  Check ($empty.Ready -and $empty.NextSequence -eq 0 -and @($empty.Seen).Count -eq 0) 'empty remote range initializes with no invented event'
 }
 $script:remoteResponse=$null
 Throws {SheetDiag-ArchiveRecoverRemote (SheetDiag-ArchiveReadState (Join-Path $root 'null-response')) $target @{}} 'DIAG_ARCHIVE_STATE_RECOVERY'

 $firstKey=Ops-Key 'existing-event';$newKey=Ops-Key 'new-event'
 $script:remoteResponse=@{values=@(,@('0000000001-'+$firstKey))}
 $resume=SheetDiag-ArchiveReadState (Join-Path $root 'resume')
 $resume.Pending=@(
  [pscustomobject]@{Key=$firstKey;File='execution-20261105.jsonl';Data=(SheetDiag-Clean $faultRecord);Context=$false;Device=$device},
  [pscustomobject]@{Key=$newKey;File='execution-20261105.jsonl';Data=(SheetDiag-Clean $faultRecord);Context=$false;Device=$device}
 )
 $resume=SheetDiag-ArchiveRecoverRemote $resume $target @{}
 Check ($resume.Ready -and $resume.NextSequence -eq 2 -and @($resume.Pending).Count -eq 1 -and $resume.Pending[0].Sequence -eq 2 -and $resume.Pending[0].Key -ceq $newKey) 'remote replay removes only acknowledged duplicates and resumes at the next row'

 $invalidResponses=@(
  @{values=@(,@('malformed'))},
  @{values=@(,@('0000000002-'+$firstKey))},
  @{values=@(@('0000000001-'+$firstKey),@('0000000003-'+$newKey))},
  @{values=@(@('0000000001-'+$firstKey),@())}
 )
 foreach($response in $invalidResponses){
  $badRoot=Join-Path $root ([guid]::NewGuid().ToString('N'));[void][IO.Directory]::CreateDirectory($badRoot)
  $script:remoteResponse=$response;$beforePosts=$script:postCount
  $bad=SheetDiag-ArchiveRun $snapshot @{} 'https://sheets.googleapis.com/v4/spreadsheets/MAIN_TEST' $device $badRoot
  $disk=SheetDiag-ArchiveReadState $badRoot
  Check ($bad.Code -ceq 'DIAG_ARCHIVE_STATE_RECOVERY' -and !$disk.Ready -and $disk.NextSequence -eq 0 -and @($disk.Pending).Count -eq 1 -and $script:postCount -eq $beforePosts) 'malformed or noncontiguous remote rows block writes and preserve the local queue'
 }

 $manyRows=New-Object 'Collections.Generic.List[object]'
 for($i=1;$i -le 12001;$i++){$manyRows.Add(@(('{0:D10}-{1}' -f $i,(Ops-Key ('remote-'+$i)))))}
 $script:remoteResponse=@{values=$manyRows.ToArray()}
 $many=SheetDiag-ArchiveRecoverRemote (SheetDiag-ArchiveReadState (Join-Path $root 'many')) $target @{}
 Check ($many.Ready -and $many.NextSequence -eq 12001 -and @($many.Seen).Count -eq 12000 -and $many.Seen[0] -ceq (Ops-Key 'remote-2')) 'remote recovery beyond 12000 events retains the bounded deduplication tail'

 $backlogRoot=Join-Path $root 'backlog';[void][IO.Directory]::CreateDirectory($backlogRoot)
 $events=New-Object 'Collections.Generic.List[object]'
 for($i=0;$i -lt 250;$i++){$events.Add([pscustomobject]@{File='read-20261105.jsonl';Data=(SheetDiag-Clean @{Utc=([datetime]$stamp).AddSeconds($i).ToString('o');Code='TIMEOUT';Stage='READ'});Context=$false})}
 $backlogSnapshot=[pscustomobject]@{ArchiveLogs=$events.ToArray()}
 $script:remoteResponse=@{range="'진단로그'!A2:A1000";majorDimension='ROWS'};$script:postBodies=@();$script:postCount=0
 for($pass=1;$pass -le 3;$pass++){
  $beforePosts=$script:postCount
  $backlog=SheetDiag-ArchiveRun $backlogSnapshot @{} 'https://sheets.googleapis.com/v4/spreadsheets/MAIN_TEST' $device $backlogRoot
  $expectedPending=[math]::Max(0,250-100*$pass);$expectedCode=if($expectedPending){'DIAG_ARCHIVE_CATCHING_UP'}else{'OK'}
  Check ($script:postCount -eq ($beforePosts+1) -and @($backlog.Pending).Count -eq $expectedPending -and $backlog.NextSequence -eq 250 -and $backlog.Code -ceq $expectedCode) 'each pass sends one bounded batch and persists the remaining catch-up queue'
 }
 $sentIds=@();$starts=@()
 foreach($body in $script:postBodies){$parsed=$body|ConvertFrom-Json;$starts+=,$parsed.requests[-1].updateCells.start.rowIndex;foreach($row in $parsed.requests[-1].updateCells.rows){$sentIds+=,[string]$row.values[0].userEnteredValue.stringValue}}
 Check (($starts -join ',') -ceq '1,101,201' -and $sentIds.Count -eq 250 -and @($sentIds|Select-Object -Unique).Count -eq 250) 'catch-up resumes fixed consecutive rows without duplicates or gaps'

 $recovery=SheetDiag-Clean @{RecoveryCode='LIVE_RECOVERY_READY';RecoveryPending=$false;RecoveryReady=$true;RecoveryCount=2;Token=$secret;Account=$secret}
 Check ($recovery.RecoveryCode -ceq 'LIVE_RECOVERY_READY' -and !$recovery.RecoveryPending -and $recovery.RecoveryReady -and $recovery.RecoveryCount -eq 2 -and !(($recovery|ConvertTo-Json).Contains($secret))) 'recovery progress diagnostics contain only safe typed fields'
 $invalidRecovery=SheetDiag-Clean @{RecoveryCode='=IMPORTXML("https://example.invalid")';RecoveryPending='true';RecoveryReady='false';RecoveryCount=-1}
 Check ($invalidRecovery.Count -eq 0) 'invalid recovery diagnostic fields are rejected'

 # Exercise the production coordinator with independent summary and archive failures.
 $coordRoot=Join-Path $root 'coordinator';[void][IO.Directory]::CreateDirectory($coordRoot)
 $script:order=New-Object 'Collections.Generic.List[string]';$script:summaryFails=$false;$script:archiveFails=$true;$script:coordinatorSnapshot=$snapshot
 function Sheet-Config($root){return @{Enabled=$true;SheetId='MAIN_TEST'}}
 function Sheet-Id($value){return 'MAIN_TEST'}
 function SheetDiag-Identity($root){return '11111111-1111-4111-8111-111111111111'}
 function SheetDiag-Auth($cfg,$root){return 'SYNTHETIC_TOKEN'}
 function SheetDiag-Snapshot($data,$manage,$hostRoot){return $script:coordinatorSnapshot}
 function SheetDiag-Send($snapshot,$headers,$base,$device,$seq){$script:order.Add('summary');if($script:summaryFails){throw 'DIAG_SUMMARY_TEST'}}
 function SheetDiag-ArchiveConfig($headers,[string]$mainBase){
  $script:order.Add('archive')
  if(!$script:summaryFails){
   $published=SheetDiag-Json (Join-Path $coordRoot 'diagnostics-status.json')
   if(!$published -or $published.Code -cne 'OK' -or !$published.LastSuccessUtc){throw 'DIAG_ARCHIVE_SUMMARY_NOT_PERSISTED'}
  }
  if($script:archiveFails){throw 'archive transport unavailable'}
  return 'ARCHIVE_TEST_SHEET'
 }
 Check ((SheetDiag-Run $root $coordRoot) -eq 0) 'archive failure cannot turn a successful rolling summary into a failure'
 $result=SheetDiag-Json (Join-Path $coordRoot 'diagnostics-status.json')
 Check (($script:order -join ',') -ceq 'summary,archive' -and $result.Code -ceq 'OK' -and $result.ArchiveCode -ceq 'DIAG_ARCHIVE_TRANSPORT_OR_STORAGE' -and $result.ArchivePending -eq 1) 'current summary is persisted before archive work and archive failure remains visible'
 $script:order.Clear();$script:summaryFails=$true;$script:archiveFails=$false
 Check ((SheetDiag-Run $root $coordRoot) -eq 1) 'summary failure is not hidden by successful archival'
 $result=SheetDiag-Json (Join-Path $coordRoot 'diagnostics-status.json')
 Check (($script:order -join ',') -ceq 'summary,archive' -and $result.Code -ceq 'DIAG_SUMMARY_TEST' -and $result.ArchiveCode -ceq 'OK' -and $result.ArchivePending -eq 0 -and $result.LastSuccessUtc) 'archive still drains when the independent rolling summary fails'
 Write-Output ('DIAGNOSTIC ARCHIVE TEST PASSED: '+$script:checks+' checks; local queue and mocked transport only')
}finally{Remove-Item -LiteralPath $root -Recurse -Force}
