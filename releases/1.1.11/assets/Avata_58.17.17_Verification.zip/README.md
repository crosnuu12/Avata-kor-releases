# Avata 1.1.11 / 58.17.17

Fix diagnostic archival bootstrap for empty Google Sheets responses, preserve pending evidence, and send bounded batches after publishing the live summary. Include synthetic verification of read-timeout recovery and ambiguous-order handling without changing order authorization or retry policy. Reusable rejection recovery remains available from 1.1.10.

Run Run-Checks.ps1 under Windows PowerShell 5.1, then Test-TrayRestore.ps1 -HostedRunner, Test-DesktopStartup.ps1, and Test-RecoveryDialog.ps1 -HostedRunner. Tests use synthetic data only. This source archive is not an installer; the runtime update package contains only bundle/. Archived host scripts are test/source material and must not overwrite the installed trust key.

Final validation and publication evidence lives in releases/1.1.11/STATUS.md and the release-diagnostic-archive GitHub Actions workflow. PC installation requires independent confirmation.
