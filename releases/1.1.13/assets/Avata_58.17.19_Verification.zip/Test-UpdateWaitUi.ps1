﻿#requires -Version 5.1
param([string]$Root=$PSScriptRoot)
$ErrorActionPreference='Stop';Set-StrictMode -Version 2
. (Join-Path $Root 'bundle/At58.Ops.ps1')
. (Join-Path $Root 'bundle/payload/At58.Core.ps1')
. (Join-Path $Root 'host/At58.Update.ps1')
Add-Type -AssemblyName System.Drawing
$script:checks=0;$script:sideEffects=0
function Check([bool]$ok,[string]$name){if(!$ok){throw ('FAILED: '+$name)};$script:checks++;Write-Output ('PASS '+$name)}
function Invoke-RestMethod {$script:sideEffects++;throw 'NETWORK_FORBIDDEN'}
function At58T-Wire {$script:sideEffects++;throw 'ORDER_FORBIDDEN'}
function At58X-Queue {$script:sideEffects++;throw 'COMMAND_FORBIDDEN'}
function Ops-WriteJson {$script:sideEffects++;throw 'WRITE_FORBIDDEN'}
$tokens=$null;$errors=$null
$ast=[Management.Automation.Language.Parser]::ParseFile((Join-Path $Root 'bundle/payload/esbada_Merits_AT_v58.ps1'),[ref]$tokens,[ref]$errors)
if($errors.Count){throw 'APPLICATION_PARSE'}
foreach($name in @('Update-Fresh','Update-WaitReason','Update-RequestView','Update-Render','Update-SubmitRequest','Live-RequestRead','Live-StopComplete','Tray-Tick','Live-RecoveryBlocked','Live-RecoveryCanRequest')){
 $fn=$ast.Find({param($n) $n -is [Management.Automation.Language.FunctionDefinitionAst] -and $n.Name -ceq $name},$true)
 if(!$fn){throw ('FUNCTION_MISSING '+$name)}
 . ([scriptblock]::Create($fn.Extent.Text))
}
$run='11111111-1111-4111-8111-111111111111';$session='synthetic-update-host'
function Fresh {
 $now=[datetime]::UtcNow
 $live=[pscustomobject]@{Schema='AT-LIVE-STATUS-1';HostProtocol=2;RunId=$run;Utc=$now.ToString('o');State='DISARMED';ExecutionEnabled=$false;OrdersSent=1;OpenOrders=0;UncertainOrders=0;Reconciled=$true;Confirmations=2;TestOnly=$false;Code='OK'}
 $runtime=[pscustomobject]@{HostProtocol=2;RunId=$run;Utc=$now.ToString('o');LiveMode='LIVE';LiveCommandPending=$false;ExecutionEnabled=$false;DesiredRunning=$true;Running=$true;Fault='';Busy=$false;ExitReason=''}
 $manager=[pscustomobject]@{HostSession=$session;RunId=$run;Utc=$now.ToString('o');RepairRunning=$false;RepairTransaction=$false}
 $account=[pscustomobject]@{HostProtocol=2;RunId=$run;Utc=$now.ToString('o');ExecutionEnabled=$false;OrdersSent=1;Live=$live}
 return [pscustomobject]@{Manager=$manager;Runtime=$runtime;Account=$account;Live=$live;Now=$now}
}
function Reason($f){return (Update-WaitReason $f.Manager $f.Runtime $f.Account $session $run $f.Now)}
$cases=@(
 @{Name='input wait with REVIEW and no open orders';Expected='WAIT_INPUT';Change={$args[0].Live.State='REVIEW';$args[0].Live.Code='LIVE_INPUT_WAIT';$args[0].Live.Reconciled=$false;$args[0].Live.Confirmations=0}},
 @{Name='rollover input wait';Expected='WAIT_INPUT';Change={$args[0].Live.Code='LIVE_ROLLOVER_WAIT'}},
 @{Name='unresolved review with no open orders';Expected='BLOCKED_REVIEW';Change={$args[0].Live.State='REVIEW'}},
 @{Name='actual open orders';Expected='WAIT_ORDERS';Change={$args[0].Live.OpenOrders=2}},
 @{Name='uncertain orders take priority over input wait';Expected='BLOCKED_UNCERTAIN';Change={$args[0].Live.UncertainOrders=1;$args[0].Live.Code='LIVE_INPUT_WAIT'}},
 @{Name='reconciliation has not completed twice';Expected='WAIT_RECONCILE';Change={$args[0].Live.Confirmations=1}},
 @{Name='stopping without open orders';Expected='WAIT_STOP';Change={$args[0].Live.State='STOPPING'}},
 @{Name='pending stop command';Expected='WAIT_COMMAND';Change={$args[0].Runtime.LiveCommandPending=$true}},
 @{Name='busy reader after reconciliation';Expected='WAIT_IDLE';Change={$args[0].Runtime.Busy=$true}},
 @{Name='repair worker';Expected='WAIT_REPAIR';Change={$args[0].Manager.RepairRunning=$true}},
 @{Name='repair transaction';Expected='WAIT_REPAIR';Change={$args[0].Manager.RepairTransaction=$true}},
 @{Name='fatal reader exception';Expected='BLOCKED_READER';Change={$args[0].Runtime.Fault='WORKER_FAILED';$args[0].Runtime.Running=$false}},
 @{Name='paused reader';Expected='WAIT_READER';Change={$args[0].Runtime.Running=$false}},
 @{Name='reader resume still required';Expected='WAIT_READER';Change={$args[0].Runtime.DesiredRunning=$false}},
 @{Name='terminal rejected order already reconciled';Expected='WAIT_SWITCH';Change={$args[0].Live.Code='LIVE_ORDER_REJECTED'}},
 @{Name='normal stopped and reconciled state';Expected='WAIT_SWITCH';Change={}}
)
foreach($case in $cases){
 $f=Fresh;& $case.Change $f;$before=$f|ConvertTo-Json -Depth 6 -Compress
 $reason=Reason $f;$view=Update-RequestView 'WAITING_FOR_ORDERS' $true $f.Now.AddSeconds(-30) $false $reason $f.Now
 Check ($reason -ceq $case.Expected -and !$view.Enabled -and $view.Queued) ('specific waiting reason: '+$case.Name)
 Check (($f|ConvertTo-Json -Depth 6 -Compress) -ceq $before) ('presentation does not change account/runtime state: '+$case.Name)
 if($case.Expected -cne 'WAIT_ORDERS'){Check (!$view.Text.Contains('미체결') -and $view.Text -cne '주문 정리 후 업데이트') ('does not invent pending orders: '+$case.Name)}
}
$stopCodes=@{LIVE_STOP_ACCOUNT_WAIT='WAIT_RECONCILE';LIVE_STOP_OPEN_ORDERS='WAIT_ORDERS';LIVE_STOP_FEED='WAIT_FEED';LIVE_STOP_RECEIPTS='WAIT_FEED';LIVE_STOP_BASELINE='BLOCKED_BASELINE';LIVE_STOP_IDENTITY='BLOCKED_IDENTITY';LIVE_STOP_ACCOUNT='BLOCKED_ACCOUNT';LIVE_SNAPSHOT_IDENTITY='BLOCKED_IDENTITY'}
foreach($code in $stopCodes.Keys){
 $f=Fresh;$f.Live.Code=$code;$f.Live.State='REVIEW';$f.Live.Reconciled=$false;$f.Live.Confirmations=0
 $reason=Reason $f;$view=Update-RequestView 'WAITING_FOR_ORDERS' $true $f.Now.AddSeconds(-30) $false $reason $f.Now
 Check ($reason -ceq $stopCodes[$code] -and !$view.Enabled -and $view.Queued) ('specific stop verification reason overrides generic REVIEW: '+$code)
 if($code -ceq 'LIVE_STOP_OPEN_ORDERS'){Check ($f.Live.OpenOrders -eq 0 -and $view.Text.Contains('미체결')) 'fresh broker-level open-order proof is displayed even when no local AT order is open'}
 else{Check (!$view.Text.Contains('미체결')) ('stop verification does not invent open orders: '+$code)}
}
$invalid=@(
 @{Name='wrong manager host';Change={$args[0].Manager.HostSession='other'}},
 @{Name='wrong manager run';Change={$args[0].Manager.RunId='other'}},
 @{Name='wrong runtime run';Change={$args[0].Runtime.RunId='other'}},
 @{Name='wrong account run';Change={$args[0].Account.RunId='other'}},
 @{Name='wrong live run';Change={$args[0].Live.RunId='other'}},
 @{Name='stale manager';Change={$args[0].Manager.Utc=$args[0].Now.AddSeconds(-16).ToString('o')}},
 @{Name='stale runtime';Change={$args[0].Runtime.Utc=$args[0].Now.AddSeconds(-16).ToString('o')}},
 @{Name='stale live result';Change={$args[0].Live.Utc=$args[0].Now.AddSeconds(-21).ToString('o')}},
 @{Name='stale account result';Change={$args[0].Account.Utc=$args[0].Now.AddSeconds(-21).ToString('o')}},
 @{Name='future live result';Change={$args[0].Live.Utc=$args[0].Now.AddSeconds(3).ToString('o')}},
 @{Name='malformed order count';Change={$args[0].Live.OpenOrders='unknown'}},
 @{Name='missing live state';Change={$args[0].Account.Live=$null}}
)
foreach($case in $invalid){$f=Fresh;$f.Live.OpenOrders=2;& $case.Change $f;Check ((Reason $f) -ceq 'WAIT_STATUS') ('untrusted status cannot claim pending orders: '+$case.Name)}
$f=Fresh;$now=$f.Now
$edge=Update-RequestView 'AVAILABLE' $true $now.AddSeconds(-600) $false 'WAIT_INPUT' $now
Check ($edge.Queued -and !$edge.Expired -and !$edge.Enabled) 'request remains locked through the host 600-second boundary'
$expired=Update-RequestView 'AVAILABLE' $true $now.AddSeconds(-601) $false 'WAIT_INPUT' $now $now.ToString('o')
Check (!$expired.Queued -and $expired.Expired -and $expired.Enabled -and $expired.Text.Contains('만료')) 'confirmed expiry enables retry in the same presentation result'
$oldAck=Update-RequestView 'AVAILABLE' $true $now.AddSeconds(-601) $false 'WAIT_INPUT' $now $now.AddSeconds(-2).ToString('o')
Check ($oldAck.Queued -and $oldAck.Expired -and !$oldAck.Enabled) 'fresh AVAILABLE published before request expiry cannot release an in-flight update lock'
$edgeAck=Update-RequestView 'AVAILABLE' $true $now.AddSeconds(-601) $false 'WAIT_INPUT' $now $now.AddSeconds(-1).ToString('o')
Check ($edgeAck.Queued -and !$edgeAck.Enabled) 'host acknowledgement must be strictly after the request TTL boundary'
$still=Update-RequestView 'AVAILABLE' $false $now.AddSeconds(-620) $true 'WAIT_INPUT' $now
Check ($still.Expired -and $still.Enabled -and $still.Text.Contains('다시')) 'expiry explanation persists until a new request'
foreach($state in @('WAITING_FOR_ORDERS','')){$held=Update-RequestView $state $true $now.AddSeconds(-601) $false 'WAIT_INPUT' $now;Check ($held.Queued -and $held.Expired -and !$held.Enabled) 'expiry waits for host acknowledgement instead of racing an accepted switch'}
$applying=Update-RequestView 'APPLYING' $true $now.AddSeconds(-601) $true 'WAIT_INPUT' $now
Check ($applying.Queued -and !$applying.Expired -and !$applying.Enabled -and $applying.Text -ceq '업데이트 적용 중') 'an accepted update remains locked after the original request timeout'
$retry=Update-RequestView 'WAITING_FOR_ORDERS' $true $now $false 'WAIT_INPUT' $now
Check ($retry.Queued -and !$retry.Expired -and !$retry.Enabled -and $retry.Text -ceq '전략 입력 갱신 대기') 'new request starts a fresh timeout and displays its real blocker'

# Run the actual renderer against in-memory controls and JSON readers, with no UI or disk changes.
$managed=$true;$HostProtocol=2;$RunId=$run;$ManagementRoot=[IO.Path]::GetTempPath();$DataRoot=$ManagementRoot
$updateButton=[pscustomobject]@{Text='';Enabled=$false;BackColor=$null};$liveRecover=[pscustomobject]@{Enabled=$false};$liveArm=[pscustomobject]@{Enabled=$false}
$script:At58Auto=[pscustomobject]@{Enabled=$true;Suspended=$true}
$script:At58LiveBox=[pscustomobject]@{Mode='LIVE';Command=$null;Busy=$false;SourceHash=('a'*64);StopRequested=$true;State='DISARMED';Last=[pscustomobject]@{State='DISARMED';Code='LIVE_ORDER_REJECTED';RecoveryCode='LIVE_RECOVERY_REQUIRED';RecoveryPending=$false;RecoveryReady=$false;RecoveryCount=1;OpenOrders=0;UncertainOrders=0}}
function Setup-Render([string]$state){
 $f=Fresh
 $script:records=@{'update-status.json'=[pscustomobject]@{Schema='AVATA-UPDATE-STATUS-1';HostSession=$session;RunId=$run;Utc=$f.Now.ToString('o');State=$state;Available=[pscustomobject]@{Id='synthetic-bundle';Version='58.17.19';ManifestHash=('a'*64)}};'manager-status.json'=$f.Manager;'runtime.json'=$f.Runtime;'status.json'=$f.Account}
 $script:At58Update=$null;$script:At58UpdateQueued=$true;$script:At58UpdateQueuedAt=$f.Now.AddSeconds(-601);$script:At58UpdateExpired=$false;$liveRecover.Enabled=$false
}
function Ops-ReadJson([string]$path){$name=[IO.Path]::GetFileName($path);if(!$script:records.ContainsKey($name)){throw 'UNEXPECTED_READ'};return $script:records[$name]}
Setup-Render 'AVAILABLE'
Check (!(Live-RecoveryCanRequest $script:At58LiveBox)) 'pending update blocks recovery before expiry is acknowledged'
Update-Render
Check (!$script:At58UpdateQueued -and $script:At58UpdateExpired -and $updateButton.Enabled -and $updateButton.Text.Contains('만료')) 'actual render releases expired request before setting retry button state'
Check ($liveRecover.Enabled -and (Live-RecoveryCanRequest $script:At58LiveBox)) 'actual render restores eligible recovery immediately after confirmed expiry'
Check ($script:At58Auto.Suspended -and $script:At58LiveBox.StopRequested -and !$liveArm.Enabled -and !$script:At58LiveBox.Command) 'expiry never clears stop intent, unsuspends auto-start, or arms trading'
Update-Render
Check ($updateButton.Enabled -and $updateButton.Text.Contains('만료')) 'next render preserves the retry explanation'
Setup-Render 'WAITING_FOR_ORDERS';Update-Render
Check ($script:At58UpdateQueued -and !$updateButton.Enabled -and !$liveRecover.Enabled -and $updateButton.Text.Contains('만료')) 'actual render keeps recovery locked while the host still owns the request'
Setup-Render 'APPLYING';Update-Render
Check ($script:At58UpdateQueued -and !$script:At58UpdateExpired -and !$liveRecover.Enabled) 'actual render cannot expire an applying update'
Setup-Render 'AVAILABLE';$script:records['manager-status.json'].RunId='other';Update-Render
Check ($script:At58UpdateQueued -and !$updateButton.Enabled -and !$liveRecover.Enabled -and !$script:At58Update) 'different manager run cannot acknowledge expiry or enable retry'
Setup-Render 'AVAILABLE';$script:records['update-status.json'].HostSession='';$script:records['manager-status.json'].HostSession='';Update-Render
Check ($script:At58UpdateQueued -and !$updateButton.Enabled -and !$liveRecover.Enabled -and !$script:At58Update) 'empty host identities cannot acknowledge expiry'
Setup-Render 'AVAILABLE';$script:records['update-status.json'].Utc=[datetime]::UtcNow.AddSeconds(-21).ToString('o');Update-Render
Check ($script:At58UpdateQueued -and !$updateButton.Enabled -and !$liveRecover.Enabled) 'stale host status cannot acknowledge expiry'
Setup-Render 'AVAILABLE';$script:At58UpdateQueuedAt=[datetime]::UtcNow.AddSeconds(-610);$script:records['update-status.json'].Utc=[datetime]::UtcNow.AddSeconds(-15).ToString('o');Update-Render
Check ($script:At58UpdateQueued -and $script:At58UpdateExpired -and !$updateButton.Enabled -and !$liveRecover.Enabled) 'actual renderer rejects a still-fresh AVAILABLE timestamp from before expiry'
$script:records['update-status.json'].Utc=[datetime]::UtcNow.ToString('o');Update-Render
Check (!$script:At58UpdateQueued -and $updateButton.Enabled -and $liveRecover.Enabled) 'actual renderer releases retry and recovery on the first post-expiry host acknowledgement'
Setup-Render 'AVAILABLE';$script:At58LiveBox.Last.OpenOrders=1;Update-Render
Check (!$script:At58UpdateQueued -and !$liveRecover.Enabled) 'expiry preserves the existing open-order recovery guard'
Check ($script:sideEffects -eq 0) 'rendering and expiry perform no writes, commands, network calls, or orders'
# Execute the real accepted-request helper, deferred pause clause, and tray tick.
$pauseNode=$ast.Find({param($n) $n -is [Management.Automation.Language.IfStatementAst] -and $n.Extent.Text.StartsWith('if($script:At58Ui.PauseAfterLiveStop -and (Live-StopComplete $box))')},$true)
if(!$pauseNode){throw 'PAUSE_AFTER_STOP_CLAUSE_MISSING'}
$pauseClause=[scriptblock]::Create($pauseNode.Extent.Text)
$start=[pscustomobject]@{Enabled=$true};$import=[pscustomobject]@{Enabled=$true};$manual=[pscustomobject]@{Enabled=$true}
$tray=[pscustomobject]@{Text=''};$form=[pscustomobject]@{}
$form|Add-Member ScriptMethod Close {$script:closeCalls++}
$script:requestWriteFails=$false;$script:requestWrites=@();$script:runtimeSaves=0;$script:closeCalls=0
function Ops-WriteJson([string]$path,$value){
 if([IO.Path]::GetFileName($path) -cne 'update-request.json'){throw 'UNEXPECTED_WRITE'}
 if($script:requestWriteFails){throw 'SYNTHETIC_REQUEST_WRITE'}
 $script:requestWrites+=,$value
}
function Save-At58Runtime {$script:runtimeSaves++}
function Pending-PauseClose {
 $f=Fresh
 $script:At58Ui=[pscustomobject]@{CredentialReady=$true;PauseAfterLiveStop=$true;RequestedRunning=$false;Running=$false;Fault='';Next=$f.Now}
 $script:At58LiveBox=[pscustomobject]@{Mode='LIVE';State='DISARMED';StopRequested=$true;Busy=$false;Command=$null;Last=$f.Live}
 $script:At58TrayClosePending=$true;$script:At58UpdateQueued=$false;$script:At58UpdateExpired=$false;$script:closeCalls=0
 return $f
}
$f=Pending-PauseClose;$box=$script:At58LiveBox;$l=$f.Live
$l.Reconciled=$false;$l.Confirmations=0
Live-RequestRead
. $pauseClause
Tray-Tick
Check ($script:At58Ui.Running -and $script:At58Ui.RequestedRunning -and $script:At58Ui.PauseAfterLiveStop -and $script:closeCalls -eq 0) 'failed first stop proof keeps the reader alive and prevents deferred tray close'
$l.Reconciled=$true;$l.Confirmations=2
. $pauseClause;Tray-Tick
Check ($script:At58Ui.Running -and $script:closeCalls -eq 0) 'two confirmations cannot complete pause or close while stop intent is still pending'
$box.StopRequested=$false
. $pauseClause;Tray-Tick
Check (!$script:At58Ui.Running -and !$script:At58Ui.RequestedRunning -and $script:closeCalls -eq 1) 'verified completed stop honors the original pause and tray-close request'
$f.Runtime.DesiredRunning=$script:At58Ui.RequestedRunning;$f.Runtime.Running=$script:At58Ui.Running
Check ((Up-Observe (Up-NewProbe) $f.Manager $f.Runtime $f.Account $session $f.Now.AddMinutes(-5) $f.Now) -ceq 'PAUSED') 'preexisting pause intent would otherwise leave the installed host unable to update'

$f=Pending-PauseClose;Setup-Render 'AVAILABLE';$script:At58UpdateQueued=$false
$u=$script:records['update-status.json'];$box=$script:At58LiveBox
Live-RequestRead
Update-SubmitRequest $u ([datetime]::UtcNow)
Check (!$script:At58Ui.PauseAfterLiveStop -and !$script:At58TrayClosePending -and $script:At58UpdateQueued -and $script:requestWrites.Count -eq 1) 'persisted update request supersedes earlier deferred pause and tray-close intent'
Check ($script:At58Auto.Suspended -and $box.StopRequested -and !$liveArm.Enabled -and !$box.Command) 'accepted update retains STOP and automatic-start suspension'
$box.StopRequested=$false;$l=$box.Last
. $pauseClause;Tray-Tick
Check ($script:At58Ui.Running -and $script:At58Ui.RequestedRunning -and $script:closeCalls -eq 0) 'actual pause and tray clauses leave a verified stopped reader running for update'
$f.Runtime.DesiredRunning=$script:At58Ui.RequestedRunning;$f.Runtime.Running=$script:At58Ui.Running
Check ((Up-Observe (Up-NewProbe) $f.Manager $f.Runtime $f.Account $session $f.Now.AddMinutes(-5) ([datetime]::UtcNow)) -ceq 'READY') 'accepted update reaches existing host READY after quiescent reconciliation'

$f=Pending-PauseClose;$box=$script:At58LiveBox;$script:requestWriteFails=$true;Live-RequestRead
$actual='';try{Update-SubmitRequest $u ([datetime]::UtcNow)}catch{$actual=$_.Exception.Message}
Check ($actual -ceq 'SYNTHETIC_REQUEST_WRITE' -and $script:At58Ui.PauseAfterLiveStop -and $script:At58TrayClosePending -and !$script:At58UpdateQueued -and $script:requestWrites.Count -eq 1) 'failed request persistence preserves both original pause and close intents'
$box.StopRequested=$false;$l=$box.Last
. $pauseClause;Tray-Tick
Check (!$script:At58Ui.RequestedRunning -and !$script:At58Ui.Running -and $script:closeCalls -eq 1) 'failed update request still honors prior pause and close after verified stop'
Check ($script:sideEffects -eq 0) 'update-intent tests send no order, activation command, or network request'
Write-Output ('UPDATE WAIT UI TEST PASSED: '+$script:checks+' checks; synthetic objects and mocked reads only')
