# Avata 1.1.13 / 58.17.19

Fix the reproduced REVIEW-after-worker-failure stop dead end and separate explicit stop reconciliation from fresh strategy input. Require two new post-stop broker/account observations with no outstanding or uncertain orders before DISARMED. A review stop sends no orders; existing trading approval, rejection acknowledgement and host maintenance guards remain in force.

Run Run-Checks.ps1 under Windows PowerShell 5.1, then Test-TrayRestore.ps1 -HostedRunner, Test-DesktopStartup.ps1, and Test-RecoveryDialog.ps1 -HostedRunner. Tests use synthetic data only. This source archive is not an installer; the runtime update package contains only bundle/. Archived host scripts are test/source material and must not overwrite installed trust keys.

Final validation and publication evidence lives in releases/1.1.13/STATUS.md and the release-update-quiescence GitHub Actions workflow. PC installation and recovery require independent confirmation. The initiating worker exception in the older incident remains unconfirmed; sanitized worker evidence added in 1.1.12 is retained.
