# Avata 1.1.8 / 58.17.14

Terminal zero-fill rejected orders are now distinguished from unresolved orders. They stop live execution and surface `LIVE_ORDER_REJECTED`, while two fresh reconciled account reads and zero open/uncertain orders allow a requested update to continue. Uncertain orders and rejected orders with fills remain blocked for manual review.

See README_KO.md for behavior and limitations. Run Run-Checks.ps1 on Windows PowerShell 5.1, then Test-TrayRestore.ps1 -HostedRunner and Test-DesktopStartup.ps1. Tests use synthetic fixtures only.
