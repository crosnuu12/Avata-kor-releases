# Avata 1.1.10 / 58.17.16

Reusable confirmed-rejection recovery adds a distinct UI action with three human confirmations. The worker waits for two fresh matching account reads and an exact current journal readback receipt, persists scoped encrypted approval, and remains disarmed. A separate local manual ARM is required. New rejections never reuse old approval; uncertain/partial/open orders remain blocked.

Run Run-Checks.ps1 under Windows PowerShell 5.1, then Test-TrayRestore.ps1 -HostedRunner, Test-DesktopStartup.ps1, and Test-RecoveryDialog.ps1 -HostedRunner. Tests use synthetic data only. This source archive is not an installer; runtime update package contains only bundle/. Archived host scripts are test/source material and must not overwrite the installed trust key.

Final validation and publication evidence lives in releases/1.1.10/STATUS.md and the release-recovery-button GitHub Actions workflow. PC installation remains independently unconfirmed.
