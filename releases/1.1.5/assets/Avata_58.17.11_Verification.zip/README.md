# Avata 1.1.5 / 58.17.11

Main-PC-only Telegram market attendance and settlement checkout notifications.

See README_KO.md for behavior, operating requirements and validation.

Run Run-Checks.ps1 in Windows PowerShell 5.1, followed by Test-TrayRestore.ps1 -HostedRunner and Test-DesktopStartup.ps1. All account, broker and Telegram tests use synthetic fixtures.
