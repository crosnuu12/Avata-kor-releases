# Avata 1.1.4 verification kit

Run Run-Checks.ps1 on Windows PowerShell 5.1, then Test-TrayRestore.ps1 -HostedRunner and Test-DesktopStartup.ps1. All fixtures are synthetic. Test-BuyTable.ps1 covers 49 checks for table-priced limit buys, staged gap-down execution, exact broker fill accounting and daily price bounds. Existing desktop, update, diagnostics and journal regression suites remain included.
